1) BRIEF DESCRIPTION
SaQAI (Saturation based Query Answering under Inconsistencies) is a prototypical tool for meaningful conjunctive
 query answering over inconsistent DL-Lite_R KBs. In particular, SaQAI computes meaningful answers under both ICAR
 and IAR semantics. Regarding the ICAR semantics, SaQAI computes the answers "on-line", without affecting the 
 initial dataset. In particular it performs the following process: a. computes the set cr(A,T) by removing from 
 the abox the assertions a s.t. T\cup \{a\}\models \bot, b. computes all the disjointness axioms implied from the ontology,
 c. it uses Rapid to compute the set R_\Q and d. reformulates the set R_\Q by using step b. 
 
 For the IAR semantics, SaQAI first "repairs" the abox (constucting the db_name_iar.owl dataset) by removing from 
 abox all the assertions that violate the disjointness axioms implied from the ontology. Then it computes the answers
  over the new abox which is consistent to the ontology. 
 
In both cases answers are computed using Hydrowl (http://www.image.ece.ntua.gr/~gstoil/hydrowl/).
   
For technical details about the techniques used by SaQAI and the theory behind the interested reader is referred to the paper:
Eleni Tsalapati, Giorgos Stoilos, Giorgos Stamou, George Koletsos, "Efficient Query Answering Over Expressive 
Inconsistent Description Logics". In the proceedings of the International Joint Conference of AI (IJCAI, 2016). 

2) INSTALLATION
Most jar files required to use SaQAI are already located under the /lib directory. So you need to ensure that java sees them in order to run SaQAI. 

SaQAI uses Hydrowl which uses SwiftOWLIM. SwiftOWLIM uses various other jars that can be located under the folder SwiftOWLIM (in particular it uses openrdf-model.jar, openrdf-util.jar, owlim-2.9.1.jar, rio.jar, sesame.jar, and trree-2.9.1.jar). Java needs to be able to see these jars as well in order for Hydrowl to work. Please see the separate SwiftOWLIM folder for licenses regarding these jars.

3) USING SaQAI
Under the main package in SaQAI, there are two java classes that contain examples about how to use SaQAI for 
computing consistent answers under the ICAR and IAR semantics the Example_ICAR and Example_IAR. In Example_ICAR there is also an option to run the
class ICAR_skipDisjProp, which is an optimised version of the ICAR class, in which
the disjoint property axioms that are not in use are skipped.

The first query used is an artificial query that contains the top concepts of the ontology. This way, rapid computes
the rewriting of the rest of the queries much faster.  

3a) Input  
If the ontology (in OWL/XML form) used is not OWL 2 RL then a completion of the ontology must be
 computed first using Hydrowl (see Hydrowl/examples/ComputeRepairForOntoExample).
The dataset can be either an .owl file or a PostgreSQL dump file. This version of SaQAI handles databases such 
that each concept/role of the ontology corresponds to one table, whose name is the name of the concept/role in
 the ontology (in small letters!), with one (or two in case of role) column.

The test ontology and datasets can be found in the file EvaluationData and the queries in QueriesForTestOntologies.java

3b) Output
To check whether there are assertions s.t. T\cup\{a\} \models \bot  it needs to load the initial abox and 
tbox in OWLim. Hence, initially the time required to load to OWLim appears.

"Computing set cr(A,T): " is the time to compute the set cr(\A,\T) (see def. 8 of paper). In that case, 
all the assertions a s.t. T\cup\{a\} \models \bot will be *removed* from the abox.owl file but not from the dataset.sql
file. Then, the new abox will be loaded to OWLim.





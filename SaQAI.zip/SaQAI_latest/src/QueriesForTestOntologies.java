public class QueriesForTestOntologies {
	
	public static String getTestQuery_LUBM(int i) {
		String prefixForA="http://swat.cse.lehigh.edu/onto/univ-bench.owl#";
		switch(i) {
		case 0: 
			//return "Q(?0)  <- "+prefixForA+"P(?0,?1)";
			//return "Q(?0) <- "+prefixForA+"R(?0,?2)" +prefixForA+"P(?0,?1)";
			return "Q(?0) <- "+prefixForA+"Person(?0)"+prefixForA+"Work(?0)"+prefixForA+"Publication(?0)"+prefixForA+"Organization(?0)";//preprocess
		case 1:	
			return "Q(?0,?1) <- "+prefixForA+"Person(?0)"+prefixForA+"takesCourse(?0,?1) ";//q1
		case 2:
			return "Q(?0,?1) <- "+prefixForA+"Employee(?0)"+prefixForA+"publicationAuthor(?1,?0)";//q2
		
		case 3:	
				return "Q(?0,?1,?2,?3,?4,?5) <- "+prefixForA+"FullProfessor(?0)"+prefixForA+"publicationAuthor(?1,?0)"+prefixForA+"teacherOf(?0,?2)"+prefixForA+"advisor(?3,?0)"+prefixForA+"GraduateStudent(?3)"+prefixForA+"degreeFrom(?0,?4)"+prefixForA+"degreeFrom(?3,?5)";//q4
		case 4:	
			return "Q(?0) <-"+prefixForA+"Organization(?0)"; //g2
		case 5:	
			return "Q(?0) <-"+prefixForA+"Employee(?0)"; //g3
		
		case 6:	
			return "Q(?0,?1) <- "+prefixForA+"Person(?0)"+prefixForA+"teacherOf(?0,?1)"+prefixForA+"Course(?1)";//req2
		case 7:	
			return "Q(?0,?1,?2) <-"+prefixForA+"Student(?0)"+prefixForA+"advisor(?0,?1)"+prefixForA+"Faculty(?1)"+prefixForA+"takesCourse(?0,?2)"+prefixForA+"teacherOf(?1,?2)"+prefixForA+"Course(?2)";//req3
		case 8:	
			return "Q(?0,?1) <- "+prefixForA+"Student(?0)"+prefixForA+"takesCourse(?0,?1)"+prefixForA+"Course(?1)"+prefixForA+"teacherOf(?2,?1)"+prefixForA+"Faculty(?2)"+prefixForA+"worksFor(?2,?3)"+prefixForA+"Department(?3)"+prefixForA+"memberOf(?0,?3)"; //lutz1
		case 9:	
			 return "Q(?0) <- "+prefixForA+"Publication(?0)"+prefixForA+"publicationAuthor(?0,?1)"+prefixForA+"Professor(?1)"+prefixForA+"publicationAuthor(?0,?2)"+prefixForA+"Student(?2)";//lutz5
		default:
			return null;
		}
	}

}

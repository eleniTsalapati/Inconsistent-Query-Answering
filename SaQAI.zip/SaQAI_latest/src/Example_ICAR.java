
/* Copyright 2016, 2017 by the National Technical University of Athens.

   This file is part of SaQAI.

   SaQAI is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   SaQAI is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
 */
import java.io.File;
import java.util.ArrayList;
//package org.semanticweb.hydrowl;

import org.apache.log4j.PropertyConfigurator;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

import org.semanticweb.SaQAI.ICAR.ICAR;
import org.semanticweb.SaQAI.ICAR.ICAR_skipDisjProp;
import org.semanticweb.SaQAI.database.CreateOntology;

public class Example_ICAR{
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("./logger.properties");
	
		Boolean refMin =true; //true if we use refMin, i.e. by computing only the necessary disjoint atoms and not the ones computed automatically from owlim
		//for details see paper "Efficient Query Answering Over Expressive Inconsistent Description	Logics". Otherwise refMin =false.

		try {			
			String tboxFile = "file:/C:/Users/etsalap/workspace/convertedOntologyToOWLXML-owl-repair_for_OWLim.owl";
			//--------------
			String db = "u1p15e-4"; //
//			String db = "u1p5e-2"; //
//			String db = "u1p2e-1";//
			//--------------
		//	String db = "u5p15e-4"; //
		//	String db = "u5p5e-2";
		//	String db = "u5p2e-1";
			//--------------
		//	String db = "u10p15e-4";
			//String db = "u10p5e-2";
	//		String db = "u10p2e-1"; 
			//--------------
		//	String db = "u20p15e-4";
			//String db = "u20p5e-2"; 
		//	String db = "u20p2e-1";
		
			//& dbs with no inconsistencies:
			//String db = "u1p0";  
			//String db = "u5p0";
		//	String db = "u10p0";
			//String db = "u20p0";
			
//			String aboxFile = "C:/Users/etsalap/workspace/lubm_"+db+".owl";
			String aboxFile = "C:/Users/etsalap/workspace/"+db+".sql";
			
			ArrayList<String> queries = new ArrayList<String>();
			for (int i=0 ; i<=9 ; i++) {	
				queries.add(QueriesForTestOntologies.getTestQuery_LUBM(i));
			}
			
			if(aboxFile.contains(".owl")){
				ICAR ICARQASystem = new ICAR();
				 ICARQASystem.ICARQA(queries,tboxFile,aboxFile,refMin);

//				ICAR_skipDisjProp ICARQASystem_skipDisjProp = new ICAR_skipDisjProp();
//				ICARQASystem_skipDisjProp.ICARQA(queries,tboxFile,aboxFile,refMin);
			}
			
			else if(aboxFile.contains(".sql")){
				System.out.println("Transforming .sql file to .owl...");
				IRI physicalURIOfBaseOntology = IRI.create(tboxFile);
				OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
				OWLOntology sourceOntology = manager.loadOntology(physicalURIOfBaseOntology);
				
				//give the path of the owl file which will be populated by the db:
				String newOntologyFile = "C:/Users/etsalap/workspace/lubm_"+db+".owl";
				File new_onto_file = new File(newOntologyFile);
				File DB = new File(aboxFile);				
				String iri = "http://lubm_"+db;

				CreateOntology.readDBandCreatePopulatedOnto(sourceOntology, new_onto_file, DB, iri);
				System.out.println("Transformation completed");
				
				ICAR ICARQASystem = new ICAR();
				ICARQASystem.ICARQA(queries,tboxFile,newOntologyFile,refMin);
			
				//ICAR_skipDisjProp ICARQASystem_skipDisjProp = new ICAR_skipDisjProp();
				//	ICARQASystem_skipDisjProp.ICARQA(queries,tboxFile,newOntologyFile,refMin);
		}
			else {
				System.out.println("ABox must  be either an .owl file or a PostgreSQL dump file");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);	
		}
	}
}

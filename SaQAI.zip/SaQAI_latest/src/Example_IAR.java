/* Copyright 2016, 2017 by the National Technical University of Athens.

   This file is part of SaQAI.

   SaQAI is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   SaQAI is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.File;
import java.util.ArrayList;

import org.apache.log4j.PropertyConfigurator;
import org.semanticweb.SaQAI.IAR.IAR;
import org.semanticweb.SaQAI.database.CreateOntology;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;


public class Example_IAR {
	public static void main(String[] args) {
		PropertyConfigurator.configure("./logger.properties");
		String tboxFile = "file:/C:/workspace/convertedOntologyToOWLXML-owl-repair_for_OWLim.owl";
		//--------------
		String db = "u1p15e-4"; //
//		String db = "u1p5e-2"; //
//		String db = "u1p2e-1";//
		//--------------
	//	String db = "u5p15e-4"; //
	//	String db = "u5p5e-2";
	//	String db = "u5p2e-1";
		//--------------
	//	String db = "u10p15e-4";
		//String db = "u10p5e-2";
		//String db = "u10p2e-1"; 
		//--------------
	//	String db = "u20p15e-4";
		//String db = "u20p5e-2"; 
	//	String db = "u20p2e-1";
	
		//& dbs with no inconsistencies:
		//String db = "u1p0";  
		//String db = "u5p0";
	//	String db = "u10p0";
		//String db = "u20p0";
		
//		String aboxFile = "C:/workspace/lubm_"+db+".owl";
		String aboxFile = "C:/workspace/"+db+".sql";
		
		ArrayList<String> queries = new ArrayList<String>();
		for (int i=0 ; i<=9 ; i++) {	
			queries.add(QueriesForTestOntologies.getTestQuery_LUBM(i));
		}
	
		try {
			
			if(aboxFile.contains(".owl")){		
				IAR IARQASystem = new IAR();
				IARQASystem.IARQA(queries, tboxFile, aboxFile, db);
				}
			
			else if(aboxFile.contains(".sql")){
				System.out.println("Transforming .sql file to .owl...");
				IRI physicalURIOfBaseOntology = IRI.create(tboxFile);
				OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
				OWLOntology sourceOntology = manager.loadOntology(physicalURIOfBaseOntology);
				
				//give the path of the owl file which will be populated by the db:
				String newOntologyFile = "/C:/workspace/lubm_"+db+".owl";
				File new_onto_file = new File(newOntologyFile);
				File DB = new File(aboxFile);				
				String iri = "http://lubm_"+db;

				CreateOntology.readDBandCreatePopulatedOnto(sourceOntology, new_onto_file, DB, iri);
				System.out.println("Transformation completed");
				
				IAR IARQASystem = new IAR();
				IARQASystem.IARQA(queries, tboxFile, newOntologyFile, db);
				}
			else {
				System.out.println("ABox must  be either an .owl file or a PostgreSQL dump file");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);	
		}
	}
	
}




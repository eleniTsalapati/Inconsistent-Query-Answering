/* Copyright 2013, 2014 by the National Technical University of Athens.

This file is part of Hydrowl.

Hydrowl is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Hydrowl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with Hydrowl. If not, see <http://www.gnu.org/licenses/>.
*/

package org.semanticweb.hydrowl.rewriting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.semanticweb.hydrowl.Configuration;
import org.semanticweb.hydrowl.Configuration.RapidType;
import org.semanticweb.hydrowl.queryAnswering.QueryRewritingSystemInterface;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import qa.algorithm.rapid.dllite.DLRapid;

import qa.algorithm.rapid.Rapid;

import common.dl.LoadedOntology;
import common.lp.Clause;

public class RapidQueryRewriter implements QueryRewritingSystemInterface {
	
	protected static Logger logger = Logger.getLogger(RapidQueryRewriter.class);
	private OWLOntology sourceOntology;
	private Rapid rapid;
	private Configuration config=null;
	
	public RapidQueryRewriter() {
		this(new Configuration());
	}
	
	public RapidQueryRewriter(Configuration configuration) {
		config=configuration;
		if (config==null)
			config=new Configuration();
//		config.rapidType=RapidType.FULLY_UNFOLD;
		//What kind of Rapid to create
		if (config.rapidType==RapidType.FULLY_UNFOLD) 
			rapid = qa.algorithm.rapid.elhi.ETRapid.createExpandRapid();
		else if (config.rapidType==RapidType.PARTLY_UNFOLD)
			rapid = qa.algorithm.rapid.elhi.ETRapid.createUnfoldRapid();
		else if (config.rapidType==RapidType.DL_LITE_UNFOLD)
			rapid=qa.algorithm.rapid.dllite.DLRapid.createFastUnfoldRapid();
		else
			rapid = qa.algorithm.rapid.elhi.ETRapid.createDatalogRapid();
		
	}
	
//	public void initialise(String sourceOntologyFile) throws OWLOntologyCreationException {
//		config=new Configuration();
//		config.rapidType=RapidType.FULLY_UNFOLD;
//		initialise(sourceOntologyFile,config);
//	}
	
//	@Override
	public void loadOntologyToSystem(String sourceOntologyFile) throws OWLOntologyCreationException {
		long start=System.currentTimeMillis();
		IRI physicalURIOfBaseOntology = IRI.create(sourceOntologyFile);
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		sourceOntology = manager.loadOntology(physicalURIOfBaseOntology);
		try {
			LoadedOntology ontRef = new LoadedOntology(sourceOntology.getOWLOntologyManager(),sourceOntology,false);
//			OWL2LogicTheory owl2LogicTheory=rapid.importOntology(ontRef,true);
			rapid.importOntology(ontRef,true);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		long sourceLoading=System.currentTimeMillis()-start;	//System.out.println("loading in: " + sourceLoading + " msec\n");
//		logger.info("loading in: " + sourceLoading + " msec\n");
//		logger.info("Done pre-processing\n\n");

	}

	public void loadOWLOntologyToSystem(OWLOntology tboxOntology) throws OWLOntologyCreationException {
		long start=System.currentTimeMillis();
		sourceOntology =  tboxOntology;
		try {
			LoadedOntology ontRef = new LoadedOntology(sourceOntology.getOWLOntologyManager(),sourceOntology,false);
//			OWL2LogicTheory owl2LogicTheory=rapid.importOntology(ontRef,true);
			rapid.importOntology(ontRef,true);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		long sourceLoading=System.currentTimeMillis()-start;	//System.out.println("loading in: " + sourceLoading + " msec\n");
		logger.info("Loading ontology to Rapid in: " + sourceLoading + " ms\n");
//		logger.info("Done pre-processing\n\n");

	}

//	@Override
	public Set<Clause> getOnlyQueriesRelatedToExistentials(Clause conjunctiveQueryAsClause) throws Exception {
		rapid.computeRewritings(conjunctiveQueryAsClause,true,true).getFilteredRewritings();
		return rapid.getShrinkedClauses();
	}
	
	public ArrayList<Clause> getRewWithUnfolding(Clause conjunctiveQueryAsClause) throws Exception {
		
		return rapid.computeRewritings(conjunctiveQueryAsClause,true,false).getAllComputedRewritings();//.getFilteredRewritings();
	}
	
	public ArrayList<Clause> getDL_LiteUnfolding(Clause conjunctiveQueryAsClause,OWLOntology ontology) throws Exception {
		
		rapid=qa.algorithm.rapid.dllite.DLRapid.createFastUnfoldRapid();
		try {
			LoadedOntology ontRef = new LoadedOntology(ontology.getOWLOntologyManager(),ontology,false);
			rapid.importOntology(ontRef,true);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		//System.out.println("::"+rapid.getEngineName());
		return rapid.computeRewritings(conjunctiveQueryAsClause,true).getFilteredRewritings();
	}
	
	public Set<Clause> getPossibleAdditionalClauses() {
		return rapid.getClausesByNormalisation();
	}
	
	public ArrayList<Clause> computeQueryRewriting(Clause conjunctiveQuery) throws Exception {
		return rapid.computeRewritings(conjunctiveQuery).getFilteredRewritings();
	}

//	@Override
	public void shutDown() { }

}

/* Copyright 2013, 2014 by the National Technical University of Athens.

This file is part of Hydrowl.

Hydrowl is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Hydrowl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with Hydrowl. If not, see <http://www.gnu.org/licenses/>.
*/

package org.semanticweb.hydrowl.queryAnswering;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import org.openrdf.sesame.query.QueryResultsTable;
import org.semanticweb.hydrowl.exceptions.SystemOperationException;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLOntology;

import common.lp.Atom;
import common.lp.Clause;

public interface IncompleteReasonerInterface {

	public void loadInputToSystem(String ontologyFile, String[] dataset) throws SystemOperationException;
	public void evaluateQueryCompletePart(Clause conjunctiveQueryAsClause,Set<Atom> atomsToCover) throws SystemOperationException;
	public void evaluateQuery(Clause conjunctiveQueryAsClause) throws SystemOperationException;
	public QueryResultsTable evaluateQueryDisjProp(Clause conjunctiveQueryAsClause) throws SystemOperationException;
	public void evaluateQuery(Set<Clause> queriesCreatedByShrinkingOnly) throws SystemOperationException;
	public QueryResultsTable evaluateQuery_Disjoint(Set<Clause> queriesCreatedByShrinkingOnly, ArrayList<Map<String, Set<String>>> map, Map<String,Set<String>> disjMapToSkip) throws SystemOperationException;
	public QueryResultsTable evaluateQuery_Disjoint(Set<Clause> queriesCreatedByShrinkingOnly, ArrayList<Map<String, Set<String>>> map, Set<Clause> additionalOntologyAxioms) throws SystemOperationException;
	public void evaluateQueryIncompletePart(String incompleteQueryForOWLim) throws SystemOperationException;
	public void shutDown() throws SystemOperationException;
	public String getValueOfCompletePartAt(int i, int j);
	public String getValueOfIncompletePartAt(int i, int j);
	public int getNumberOfReturnedAnswersCompletePart();
	int getNumberOfReturnedAnswersIncompletePart();
	public String getName();
	public void loadAdditionalAxiomsToSystem(Set<Clause> additionalOntologyAxioms);
	public void loadAdditionalOWLAxiomsToSystem(Set<OWLAxiom> additionalOntologyAxioms);
	public void loadInputOntologyToSystem(String ontologyFile)  throws SystemOperationException ;
	public void loadInputDatasetToSystem(String[] dataset)  throws SystemOperationException ;

	public QueryResultsTable evaluateQuery4repair(Set<Clause> rewritingsS) throws SystemOperationException;

}

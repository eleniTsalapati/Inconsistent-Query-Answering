/* Copyright 2013, 2014 by the National Technical University of Athens.

This file is part of Hydrowl.

Hydrowl is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Hydrowl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with Hydrowl. If not, see <http://www.gnu.org/licenses/>.
*/

package org.semanticweb.hydrowl.queryAnswering;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.openrdf.sesame.query.QueryResultsTable;
import org.apache.log4j.Logger;
import org.semanticweb.hydrowl.exceptions.SystemOperationException;
import org.semanticweb.hydrowl.queryAnswering.impl.OWLimQueryEvaluator;
import org.semanticweb.hydrowl.rewriting.RapidQueryRewriter;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;

import common.lp.Atom;
import common.lp.Clause;
import common.lp.ClauseParser;


public class RewritingBasedQueryEvaluator {
	private IncompleteReasonerInterface incompleteReasoner;
	private QueryRewritingSystemInterface queryRewriter;
	
	protected static Logger logger = Logger.getLogger(RewritingBasedQueryEvaluator.class);
	
//	public RewritingBasedQueryEvaluator(String sourceOntologyFile, String repairedOntology, String[] dataset, IncompleteReasonerInterface incompReasoner, RapidQueryRewriter queryRewritingSystem) throws SystemOperationException, OWLOntologyCreationException {
//		incompleteReasoner=incompReasoner;
//		queryRewriter=queryRewritingSystem;
//				
//		/** Loading Ontology and data to OWLim *///System.out.println("start");
//		queryRewritingSystem.loadOntologyToSystem(sourceOntologyFile); //System.out.println("ontology loaded loaded");
//
//		incompleteReasoner.loadInputToSystem(repairedOntology, dataset); //System.out.println("input loaded");
//	}

	public RewritingBasedQueryEvaluator( IncompleteReasonerInterface incompReasoner, RapidQueryRewriter queryRewritingSystem) throws SystemOperationException, OWLOntologyCreationException {
		incompleteReasoner=incompReasoner;
		queryRewriter=queryRewritingSystem;
	}
	
	public void loadOntologyToSystem(String sourceOntologyFile) throws SystemOperationException, OWLOntologyCreationException{
	
		queryRewriter.loadOntologyToSystem(sourceOntologyFile); //System.out.println("ontology loaded loaded");
		incompleteReasoner.loadInputOntologyToSystem(sourceOntologyFile);
	}
	
	public void loadDatasetToSystem(String[] dataset) throws SystemOperationException{
		incompleteReasoner.loadInputDatasetToSystem( dataset);
	}
	
	public void evaluateQuery(String conjunctiveQuery) throws Exception {
		System.out.println("Query is: " + conjunctiveQuery + "\n");
		logger.debug("Query is: " + conjunctiveQuery + "\n");
		Clause conjunctiveQueryAsClause = new ClauseParser().parseClause(conjunctiveQuery);
		
		long start=System.currentTimeMillis();

		Set<Clause> ucqPartOfRewriting = queryRewriter.getOnlyQueriesRelatedToExistentials(conjunctiveQueryAsClause);
			Set<Clause> additionalOntologyAxioms = new HashSet<Clause>();
			for (Clause cl : queryRewriter.getPossibleAdditionalClauses()) {
				if (cl.isQueryClause())
					ucqPartOfRewriting.add(cl);
				else
					additionalOntologyAxioms.add(cl);
			incompleteReasoner.loadAdditionalAxiomsToSystem(additionalOntologyAxioms);
			}
			
		long rewTime=(System.currentTimeMillis()-start);
		logger.info("Queries obtained only due to existentials: " + ucqPartOfRewriting.size() + " computed in: " + rewTime + " ms.\n");
		logger.info("Converting them into an OWLim SeRQL query.\n");
		
		start=System.currentTimeMillis();
		
		incompleteReasoner.evaluateQuery(ucqPartOfRewriting);
		long evalTime=System.currentTimeMillis()-start;
		logger.info("UCQ part evalauted over OWLim in: " + evalTime + " ms and returned: " + incompleteReasoner.getNumberOfReturnedAnswersCompletePart()  + " answers.\n");
	}
	
		
	public QueryResultsTable evaluateQuery_Disjoint(String conjunctiveQuery,ArrayList< Map<String, Set<String>>> map) throws Exception {
		logger.debug("Query is: " + conjunctiveQuery + "\n");
		Clause conjunctiveQueryAsClause = new ClauseParser().parseClause(conjunctiveQuery);
		
		long start=System.currentTimeMillis();
		
		Set<Clause> ucqPartOfRewriting = queryRewriter.getOnlyQueriesRelatedToExistentials(conjunctiveQueryAsClause);
		Set<Clause> additionalOntologyAxioms = new HashSet<Clause>();
		Set<Clause> additionalQueries = new HashSet<Clause>();
		for (Clause cl : queryRewriter.getPossibleAdditionalClauses()) {
			if (cl.isQueryClause()){
				ucqPartOfRewriting.add(cl);
				additionalQueries.add(cl);
			}
			else
				additionalOntologyAxioms.add(cl);
		}
		incompleteReasoner.loadAdditionalAxiomsToSystem(additionalOntologyAxioms);

		long rewTime=(System.currentTimeMillis()-start);
		logger.info("Queries obtained only due to existentials: " + ucqPartOfRewriting.size() + " computed in: " + rewTime + " ms.\n");
		logger.info("Converting them into an OWLim SeRQL query.\n");
		
		start=System.currentTimeMillis();
			
		QueryResultsTable table =  incompleteReasoner.evaluateQuery_Disjoint(ucqPartOfRewriting, map, additionalOntologyAxioms);
		long evalTime=System.currentTimeMillis()-start;
		logger.info("UCQ part evalauted over OWLim in: " + evalTime + " ms and returned: " + incompleteReasoner.getNumberOfReturnedAnswersCompletePart()  + " answers.\n");
		//System.out.println("answers: "+table);
		return table;
	}
	
	public QueryResultsTable evaluateDisjointProperties(String disjointProperties) throws Exception {
		
		Clause conjunctiveQueryAsClause = new ClauseParser().parseClause(disjointProperties);
		
		QueryResultsTable table =incompleteReasoner.evaluateQueryDisjProp(conjunctiveQueryAsClause);
		
	return table;		
	}




	public void shutDown() throws SystemOperationException {
		incompleteReasoner.shutDown();
		queryRewriter.shutDown();
	}
}


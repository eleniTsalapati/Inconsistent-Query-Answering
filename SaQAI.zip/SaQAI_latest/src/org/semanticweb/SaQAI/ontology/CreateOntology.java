package org.semanticweb.SaQAI.ontology;
/* Copyright 2016, 2017 by the National Technical University of Athens.

This file is part of SaQAI.

SaQAI is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SaQAI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
*/

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDeclarationAxiom;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyChange;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;

public class CreateOntology {

public static void createEmptyOntology(String nameOfFile, OWLOntology sourceOntology, OWLOntologyManager manager, String ontologyFile_empty) throws OWLOntologyStorageException, OWLOntologyCreationException{
		
		File new_onto_file_empty = new File(nameOfFile +"_empty"+".owl");
		String iri_empty =  "http://" +nameOfFile +"_empty";
		OWLOntologyManager manager_empty = OWLManager.createOWLOntologyManager();
	    IRI ontologyIRI_empty = IRI.create(iri_empty);
	    OWLOntology ont_empty = manager_empty.createOntology(ontologyIRI_empty); 
	    	
	    List<OWLOntologyChange> changes=new ArrayList<OWLOntologyChange>();
	    Set<OWLClass> referencedClasses = new HashSet<OWLClass>();
	    referencedClasses.addAll(sourceOntology.getClassesInSignature());
	   
	    for (OWLClass owlclass : referencedClasses) {
	      if (!ont_empty.containsEntityInSignature(owlclass)) {
	    	  OWLDeclarationAxiom declaration=manager.getOWLDataFactory().getOWLDeclarationAxiom(owlclass);
	          changes.add(new AddAxiom(ont_empty,declaration));
	      }
	    }
	    
	    Set<OWLObjectProperty> referencedProperties = new HashSet<OWLObjectProperty>();
	    referencedProperties.addAll(sourceOntology.getObjectPropertiesInSignature(true));
	    
	    for (OWLObjectProperty owlprop : referencedProperties) {
	      if (!ont_empty.containsEntityInSignature(owlprop)) {
	    	  OWLDeclarationAxiom declaration=manager.getOWLDataFactory().getOWLDeclarationAxiom(owlprop);
	          changes.add(new AddAxiom(ont_empty,declaration));
	      }
	    }
	    
	    manager_empty.applyChanges(changes);
	    manager_empty.saveOntology(ont_empty, IRI.create(new_onto_file_empty));
	
	}
}

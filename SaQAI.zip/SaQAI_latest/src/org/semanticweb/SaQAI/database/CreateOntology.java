/* Copyright 2016, 2017 by the National Technical University of Athens.

This file is part of SaQAI.

SaQAI is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SaQAI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
*/

package org.semanticweb.SaQAI.database;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;

public class CreateOntology {

	public static OWLOntology readDBandCreatePopulatedOnto(OWLOntology ontology, File outputfile, File DBFile, String iri) throws FileNotFoundException, OWLOntologyCreationException, OWLOntologyStorageException{
		Map<String,OWLClass> classesInStrings = new HashMap<String,OWLClass>();
		
		for(OWLClass cl: ontology.getClassesInSignature()){
			classesInStrings.put(cl.toString(),cl);
		}
		
		Map<String,OWLObjectProperty> propertiesInStrings = new HashMap<String,OWLObjectProperty>();
		for(OWLObjectProperty pr: ontology.getObjectPropertiesInSignature()){
			propertiesInStrings.put(pr.toString(),pr);
		}
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
	    IRI ontologyIRI = IRI.create(iri);
	    OWLOntology ont = manager.createOntology(ontologyIRI);
	    OWLDataFactory factory = manager.getOWLDataFactory();
	    
//		 for(OWLAxiom ax : ontology.getAxioms()){
//			 AddAxiom addAxiom1 = new AddAxiom(ont, ax);
//			   manager.applyChange(addAxiom1);
//		 }
	   
	 //	System.out.println("RDF/XML--: ");
	      
	        //Creating Scanner instance to read File in Java
	        Scanner scnr = new Scanner(DBFile);
	      
	        //Reading each line of file using Scanner class
	
	        //create the instances of classes:
	        while(scnr.hasNextLine()){
	            String line = scnr.nextLine();
	            
	            
	            if(line.contains("COPY")){   	
					String[] words = line.split(" ");
					String onto_element = Arrays.asList(words).get(1);
					for(String c : classesInStrings.keySet()){
						if(c.toLowerCase().contains("#"+onto_element+">")){
							while(scnr.hasNextLine()){
								  String line1 =scnr.nextLine();
								  if(line1.contains("<")){
									  String[] parts = line1.split(">");	
										String part0 = Arrays.asList(parts).get(0);
										String[] newparts =part0.split("<");
										String instance = Arrays.asList(newparts).get(1);
										 OWLIndividual individual = factory.getOWLNamedIndividual(IRI
										            .create(ontologyIRI +"#"+ instance));
										 OWLClassAssertionAxiom axiom1 = factory
										            .getOWLClassAssertionAxiom(classesInStrings.get(c), individual);
									
										 
										 AddAxiom addAxiom1 = new AddAxiom(ont, axiom1);
										 manager.applyChange(addAxiom1);
								  }
								  if(line1.contains("\\"+".")){
						            	break;
						            }
//								  if(line1.contains("END")){
//									  break;
//								  }
								 
							  }							
						}
					}
	            }
	        }
	        
	        //create the instances of properties:
	        Scanner scnr1 = new Scanner(DBFile);
	        int k=0;
	        while(scnr1.hasNextLine()){
	        	
	            String line = scnr1.nextLine();
	            if(line.contains("COPY")){
					String[] words = line.split(" ");
					String onto_element = Arrays.asList(words).get(1);
					for(String c : propertiesInStrings.keySet()){
						if(c.toLowerCase().contains("#"+onto_element+">")){				
							int i=0; 
							while(scnr1.hasNextLine()){
								String instance1="";
								String instance2="";
								String line1 =scnr1.nextLine();
									if(line1.contains("<") ){
										i++;  
									  String[] parts = line1.split(">");
									  if(Arrays.asList(parts).size()<2){ //THEN IT HAS THE FORM dummy <x >
											instance1 += iri+"/DUMMY_"+k;
											String[] newparts1 =Arrays.asList(parts).get(0).split("<");
											instance2 += Arrays.asList(newparts1).get(1);
											k= k+1;
									  }
									  else{
										
									  String part0 = Arrays.asList(parts).get(0);
									  String part1 = Arrays.asList(parts).get(1);
									  
										if(part0.contains("DUMMY")){
											instance1 += iri+"/DUMMY_"+k;
											String[] newparts1 =part1.split("<");
											instance2 += Arrays.asList(newparts1).get(1);
											k= k+1;
										}
										else{										
											if(part1.contains("DUMMY")){
												String[] newparts1 =part0.split("<");
												instance1 += Arrays.asList(newparts1).get(1);
												instance2 += iri+"/DUMMY_"+k;
												k= k+1;
											}
											else{
												String[] newparts0 =part0.split("<");
												instance1 += Arrays.asList(newparts0).get(1);
												String[] newparts1 =part1.split("<");
												instance2 += Arrays.asList(newparts1).get(1);	
											}
										}
									  }
										OWLIndividual ind1 = factory.getOWLNamedIndividual(IRI
									            .create(ontologyIRI+"#"+instance1));
										OWLIndividual ind2= factory.getOWLNamedIndividual(IRI
									            .create(ontologyIRI+"#"+instance2));
										
										 OWLObjectPropertyAssertionAxiom axiom1 = factory
										            .getOWLObjectPropertyAssertionAxiom(propertiesInStrings.get(c), ind1, ind2);

										 AddAxiom addAxiom1 = new AddAxiom(ont, axiom1);
										 manager.applyChange(addAxiom1);
								  }
									if(line1.contains("\\"+".")){
						            	break;
						            }
//								  if(line1.contains("END")){
//									  break;
//								  }
							  }							
						}
					}
	            }
	        }       	        
	 manager.saveOntology(ont, IRI.create(outputfile.toURI()));
	return ont;		   
	}   

}

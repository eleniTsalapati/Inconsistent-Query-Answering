package org.semanticweb.SaQAI.mainInconsistencyCheck;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.openrdf.sesame.query.QueryResultsTable;
import org.semanticweb.hydrowl.queryAnswering.RewritingBasedQueryEvaluator;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class InconsistencyChecker {

	public boolean removeInconsistencies(ArrayList<Map<String, Set<String>>> disjointnessMapping, RewritingBasedQueryEvaluator hybridQA, String dataset) throws Exception{
		boolean containsInc=false;
		Map<String, Set<String>> disjointConc=	disjointnessMapping.get(0);
		Map<String, Set<String>> disjointProp= disjointnessMapping.get(1);
				
		Set<String> guarded = new HashSet<String>(); 
		Set<String> inconsistentProps= new HashSet<String>();
		Set<String> inconsistentConcs= new HashSet<String>();
		
		for(String x:disjointConc.keySet()){
			 Set<String> disjoint = new HashSet<String>();
			 if(!disjointConc.get(x).isEmpty()){
				 disjoint.addAll(disjointConc.get(x));
				 for(String y: disjoint){
					 inconsistentConcs.addAll(tagInconsistencies(x,y).get(0));
					 guarded.addAll(tagInconsistencies(x,y).get(1));
				 }
			 }
		}
		
		for(String x:disjointProp.keySet()){
			 Set<String> disjoint = new HashSet<String>();
			 if(!disjointProp.get(x).isEmpty()){
				 disjoint.addAll(disjointProp.get(x));
				 for(String y: disjoint){
					 tagInconsistencies(x,y);
					 inconsistentProps.addAll(tagInconsistencies(x,y).get(0));
					 guarded.addAll(tagInconsistencies(x,y).get(1));
					// System.out.println(guarded);					
				 }
			 }
		}
		
		ArrayList<Set<String>> toCheck = new ArrayList<Set<String>>();
		toCheck.add(inconsistentConcs);
		toCheck.add(inconsistentProps);
		toCheck.add(guarded);
//		System.out.println(guarded);
//		System.out.println(toCheck);
		if(inconsistentConcs.size()!=0 || inconsistentProps.size()!=0 || guarded.size()!=0 ){
			Map<String, Set<String>> incAtoms =	findIncAtoms(inconsistentConcs, inconsistentProps,guarded, hybridQA);
			
			if(incAtoms.keySet().size()!=0){
				containsInc=true;
				removeInconsistentAtoms(dataset,incAtoms);	
			}	
		}
		return containsInc;
	}
	
	public ArrayList<Set<String>> tagInconsistencies(String x,String y){
		
		Set<String> guarded = new HashSet<String>(); 
		Set<String> inconsistent= new HashSet<String>();
		ArrayList<Set<String>> toCheck = new ArrayList<Set<String>>();
 		
		if(x.equals(y)){ //then you have disj(A,A) or disj(R,R).
			inconsistent.add(x);
		}

		if(y.contains(x)){
			if(y.contains("ObjectSomeValuesFrom")&&y.contains("Inverse")){ //then you have disj(\exists R,\exists R^-)
				if(!guarded.contains(x)){
					guarded.add(x);
				}
			}
			else if (y.contains("Inverse")){ //then you have disj(R, R^-)
				if(!guarded.contains(x)){
					guarded.add(x);
				}
			}		
		}
		toCheck.add(inconsistent);
		toCheck.add(guarded);
	return toCheck;
	}
	public  static Map<String, Set<String>> findIncAtoms(Set<String> inconsistentClasses, Set<String> inconsistentPropes, Set<String> guarded, RewritingBasedQueryEvaluator hybridQA) throws Exception{
		
	 	Map<String, Set<String>> incAtoms = new HashMap<String, Set<String>>();	 	
		
		for(String incClass :inconsistentClasses){
			String c1 = Arrays.asList(incClass.split("<")).get(1);
			String c2 = Arrays.asList(c1.split(">")).get(0);
			String query = "Q(?0) <- "+c2+"(?0)";
				QueryResultsTable table = hybridQA.evaluateDisjointProperties(query);
				if(table.getRowCount()!=0){				
					incAtoms.put(incClass, null); //we do not need to know the values here, we just remove all atoms with predicate incClass
				}	
			}
		
		for(String incProp :inconsistentPropes){
			String p1 = Arrays.asList(incProp.split("<")).get(1);
			String p2 = Arrays.asList(p1.split(">")).get(0);
			String query = "Q(?0,?1) <- "+p2+"(?0,?1)";
			QueryResultsTable table = hybridQA.evaluateDisjointProperties(query);
			if(table.getRowCount()!=0){				
				incAtoms.put(incProp,null);//we do not need to know the values here, we just remove all atoms with predicate incProp
			}
		}
		
		for(String g :guarded){
			String g1 = Arrays.asList(g.split("<")).get(1);
			String g2 = Arrays.asList(g1.split(">")).get(0);
			String query = "Q(?0,?0) <- "+g2+"(?0,?0)"; //for this case we only want to remove the atoms P(a,a)
			Set<String> incInds = new HashSet<String>();
			QueryResultsTable table = hybridQA.evaluateDisjointProperties(query);
			if(table.getRowCount()!=0){	
				for(int i=0 ; i<table.getRowCount();i++ ){
					incInds.add(table.getValue(i, 0).toString());
				}
				incAtoms.put(g ,incInds);//we need to know the values here
			}
		}
		return incAtoms;
	}
	
	private static void removeInconsistentAtoms(String dataset,Map<String, Set<String>> incAtoms) throws Exception{
		File abox = new File(dataset);
		Map<String,OWLClass> classesInStrings = new HashMap<String,OWLClass>();		
		
		IRI physicalURIOfBaseOntology = IRI.create(abox);
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		OWLOntology aboxOntology = manager.loadOntology(physicalURIOfBaseOntology);
		
		Map<String, Set<OWLObjectPropertyAssertionAxiom>>  propertyAssertionsMapping = new HashMap<String, Set<OWLObjectPropertyAssertionAxiom>>();
		Set< OWLObjectPropertyAssertionAxiom> allObjPropAssertions = new HashSet< OWLObjectPropertyAssertionAxiom>();
		
		for(OWLAxiom c : aboxOntology.getABoxAxioms(false)){
			if(c instanceof OWLObjectPropertyAssertionAxiom){
				allObjPropAssertions.add((OWLObjectPropertyAssertionAxiom)c);					
				for(OWLObjectProperty prop: c.getObjectPropertiesInSignature()){
					if(!propertyAssertionsMapping.keySet().contains(prop.toString())){
						Set< OWLObjectPropertyAssertionAxiom> assertions = new HashSet< OWLObjectPropertyAssertionAxiom>();
						assertions.add((OWLObjectPropertyAssertionAxiom)c);	//System.out.println("+" + prop.toString());
						propertyAssertionsMapping.put(prop.toString(), assertions);
					}
					else{
						propertyAssertionsMapping.get(prop.toString()).add((OWLObjectPropertyAssertionAxiom)c);
					}
				}
			}
		}

		for(OWLClass cl:  aboxOntology.getClassesInSignature()){
			classesInStrings.put(cl.toString(),cl);
		}
		
		Set<OWLAxiom> assertionsToRemove = new HashSet<OWLAxiom>();
				
		for(String at : incAtoms.keySet()){
			if(incAtoms.get(at)==null){
				Set<OWLClassAssertionAxiom> classAssertions = aboxOntology.getClassAssertionAxioms(classesInStrings.get(at));
				if(classAssertions!=null){
					assertionsToRemove.addAll(classAssertions);
				}
				
				Set<OWLObjectPropertyAssertionAxiom> propertyAssertions = propertyAssertionsMapping.get(at);
				if(propertyAssertions!=null){
					assertionsToRemove.addAll(propertyAssertions);
				}
			}
			else{
				Set<OWLObjectPropertyAssertionAxiom> propertyAssertions = propertyAssertionsMapping.get(at);
				if(propertyAssertions!=null){
					for(OWLObjectPropertyAssertionAxiom p: propertyAssertions ){
						if(p.getObject().equals(p.getSubject())){
							assertionsToRemove.add(p);
						}
					}
				}
			}
		}
		//System.out.println("-------"+assertionsToRemove);
		manager.removeAxioms(aboxOntology, assertionsToRemove);
		manager.saveOntology(aboxOntology);
	}

}

/* Copyright 2016, 2017 by the National Technical University of Athens.

   This file is part of SaQAI.

   SaQAI is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   SaQAI is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
 */

package org.semanticweb.SaQAI.IAR;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.semanticweb.hydrowl.queryAnswering.RewritingBasedQueryEvaluator;
import org.semanticweb.hydrowl.queryAnswering.impl.OWLimQueryEvaluator;
import org.semanticweb.hydrowl.rewriting.RapidQueryRewriter;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLDisjointObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;


public class IAR {
	
	public void IARQA(ArrayList<String> queries,  String tboxFile, String dataset, String db) throws Exception {
		long start_loading_data = System.currentTimeMillis();
		
		File aboxFile = new File(dataset);
		IRI physicalURIOfBaseOntology = IRI.create(aboxFile);
		OWLOntologyManager manager_a=OWLManager.createOWLOntologyManager();
		OWLOntology aboxOntology = manager_a.loadOntology(physicalURIOfBaseOntology); // abox 
		
		
		IRI physicalURIOfTBoxOntology = IRI.create(tboxFile);
		OWLOntologyManager manager_t=OWLManager.createOWLOntologyManager();
		OWLOntology tboxOntology = manager_t.loadOntology(physicalURIOfTBoxOntology); //tbox
	
		System.out.println("Loading ontology and abox in: " + (System.currentTimeMillis()-start_loading_data) + " ms\n");
		long start_cleaning = System.currentTimeMillis();

		ArrayList<String> disjQueries = new ArrayList<String>();
		disjQueries.addAll(createQueries(tboxOntology)); 
		
		RewritingBasedIARCleaner IARCleaner = new RewritingBasedIARCleaner(tboxOntology,new RapidQueryRewriter());
		
		Set<OWLAxiom> assertionsToRemove = new  HashSet<OWLAxiom>();
		assertionsToRemove.addAll(IARCleaner.computeIARAssertionsToRemove(disjQueries, manager_a, tboxOntology, aboxOntology)); 
		
		String ontologyFile_cons =createIARRepairedABox(db, aboxOntology, manager_a, assertionsToRemove);

		System.out.println("Total time for ABox IAR cleaning: " + (System.currentTimeMillis()-start_cleaning) + " ms\n");
		
		long start_loading = System.currentTimeMillis();

		RewritingBasedQueryEvaluator hybridQA_consistent = new RewritingBasedQueryEvaluator(new OWLimQueryEvaluator(),new RapidQueryRewriter());		
		hybridQA_consistent.loadDatasetToSystem(new String[] {ontologyFile_cons});
		hybridQA_consistent.loadOntologyToSystem(tboxFile);
		
		System.out.println("Loading in: " + (System.currentTimeMillis()-start_loading) + " ms\n");
		
		for (int i=0 ; i<=9 ; i++) {
			long start_eval = System.currentTimeMillis();
			hybridQA_consistent.evaluateQuery(queries.get(i));
			System.out.println("Evaluation in: " + (System.currentTimeMillis()-start_eval) + " ms\n");
		}
		hybridQA_consistent.shutDown();
	}

	
	public String createIARRepairedABox(String db, OWLOntology sourceOntology, OWLOntologyManager manager, Set<OWLAxiom> assertionsToRemove) throws OWLOntologyStorageException, OWLOntologyCreationException{
		long startClean=System.currentTimeMillis();
		
		OWLOntologyManager manager_iar = OWLManager.createOWLOntologyManager();
		String iarOntologyName = db+"_iar.owl";
		File iarOntologyFile = new File(iarOntologyName); 
	 	IRI ontologyIRI = IRI.create(iarOntologyName);
	    OWLOntology ontology_iar = manager_iar.createOntology(ontologyIRI);
	    String iarOntologyNameFileString= "file:/" + iarOntologyFile.getAbsolutePath().toString().replace("\\", "/");    
				 	    
	    manager_iar.addAxioms(ontology_iar, sourceOntology.getABoxAxioms(true));
	    manager_iar.removeAxioms(ontology_iar, assertionsToRemove);
	    manager_iar.saveOntology(ontology_iar, IRI.create(iarOntologyNameFileString));	    

	//    System.out.println("Time for cleaning: "+(System.currentTimeMillis()-startClean));		

	    System.out.println("# of axioms of source ontology: "+sourceOntology.getABoxAxioms(true).size());//.getABoxAxioms(true).size());
	    System.out.println("# of axioms of iar-repaired ontology: " +ontology_iar.getAxiomCount());
	
	return iarOntologyNameFileString;
	}

	private  ArrayList<String> createQueries(OWLOntology ontology){
		ArrayList<String> queriesStrings = new 	ArrayList<String>();
		
		for(OWLAxiom a :ontology.getAxioms()){
			if(a instanceof OWLDisjointClassesAxiom){
				queriesStrings.add(createConceptQuery(a));
		}
						
			if(a instanceof OWLDisjointObjectPropertiesAxiom){
				queriesStrings.add(createPropertyQuery(a));
			}			
	}
		return queriesStrings;
	}
	
	public  String createConceptQuery(OWLAxiom a){
			
			Boolean firstAtomExistential =false;
			Boolean secondAtomExistential =false;
			Boolean firstAtomContInverse =false;
			Boolean secondAtomContInverse =false;
			
			Set<OWLClassExpression> cls = ((OWLDisjointClassesAxiom)a).getClassExpressions();		
			ArrayList<OWLClassExpression> clsA= new ArrayList<OWLClassExpression>();
			clsA.addAll(cls);
			String query = "Q(?0) <- ";
			
			String firstClass =clsA.get(0).toString();//System.out.println(firstClass);		
			String firstAtom = "";  
			
			if(!firstClass.contains("ObjectSomeValuesFrom")){
				String firstStep1 = Arrays.asList(firstClass.split("<")).get(1);
				firstAtom += Arrays.asList(firstStep1.split(">")).get(0);
			}
			else{
				firstAtomExistential=true;
				if(!firstClass.contains("Inverse")){						
					String firstStep1 = Arrays.asList(firstClass.split("ObjectSomeValuesFrom\\(<")).get(1);
					firstAtom += Arrays.asList(firstStep1.split(">")).get(0);
				}
				else{
					firstAtomContInverse=true;
					String firstStep1 = Arrays.asList(firstClass.split("InverseOf\\(<")).get(1);
					firstAtom += Arrays.asList(firstStep1.split(">")).get(0);
				}				
			}
			
			String secondClass =clsA.get(1).toString();//System.out.println(secondClass);
			String secondAtom = "";

			if(!secondClass.contains("ObjectSomeValuesFrom")){
				String firstStep1 = Arrays.asList(secondClass.split("<")).get(1);
				secondAtom += Arrays.asList(firstStep1.split(">")).get(0);
			}
			else{
				secondAtomExistential=true;
				if(!secondClass.contains("Inverse")){						
					String firstStep1 = Arrays.asList(secondClass.split("ObjectSomeValuesFrom\\(<")).get(1);
					secondAtom += Arrays.asList(firstStep1.split(">")).get(0);
				}
				else{
					secondAtomContInverse=true;
					String firstStep1 = Arrays.asList(secondClass.split("InverseOf\\(<")).get(1);
					secondAtom += Arrays.asList(firstStep1.split(">")).get(0);
				}				
			}
			
			if(!firstAtomExistential&&!secondAtomExistential){
				query+=firstAtom +"(?0)"+secondAtom+"(?0)";
			}
			if(firstAtomExistential&&!secondAtomExistential){
				if(!firstAtomContInverse){
					query+=firstAtom +"(?0,?1)"+secondAtom+"(?0)";
				}
				else{
					query+=firstAtom +"(?1,?0)"+secondAtom+"(?0)";
				}					
			}
			if(!firstAtomExistential&&secondAtomExistential){
				if(!secondAtomContInverse){
					query+=firstAtom +"(?0)"+secondAtom+"(?0,?1)";
				}
				else{
					query+=firstAtom +"(?0)"+secondAtom+"(?1,?0)";
				}
			}
			if(firstAtomExistential&&secondAtomExistential){
				if(!firstAtomContInverse&& !secondAtomContInverse){
					query+=firstAtom +"(?0,?1)"+secondAtom+"(?0,?1)";
				}
				if(firstAtomContInverse&& !secondAtomContInverse){
					query+=firstAtom +"(?1,?0)"+secondAtom+"(?0,?1)";
				}	
				if(!firstAtomContInverse&& secondAtomContInverse){
					query+=firstAtom +"(?0,?1)"+secondAtom+"(?1,?0)";
				}
				if(firstAtomContInverse&& secondAtomContInverse){
					query+=firstAtom +"(?1,?0)"+secondAtom+"(?1,?0)";
				}
			}
	
		//	System.out.println(query);
		
	return query;
	}
	
	public  String createPropertyQuery(OWLAxiom a){
		Boolean firstAtomContInverse =false;
		Boolean secondAtomContInverse =false;
		
		Set<OWLObjectPropertyExpression> cls = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();		
		ArrayList<OWLObjectPropertyExpression> clsA= new ArrayList<OWLObjectPropertyExpression>();
		clsA.addAll(cls);
		
		String query = "Q(?0,?1) <- ";
		
		String firstProperty =clsA.get(0).toString();
		String firstAtom = "";
		if(!firstProperty.contains("Inverse")){						
			String firstStep1 = Arrays.asList(firstProperty.split("<")).get(1);
			firstAtom += Arrays.asList(firstStep1.split(">")).get(0);
		}
		else{
			firstAtomContInverse=true;
			String firstStep1 = Arrays.asList(firstProperty.split("InverseOf\\(<")).get(1);
			firstAtom += Arrays.asList(firstStep1.split(">")).get(0);
		}
		
		String secondProperty =clsA.get(1).toString();
		String secondAtom = "";

		if(!secondProperty.contains("Inverse")){						
			String secondStep1 = Arrays.asList(secondProperty.split("<")).get(1);
			secondAtom += Arrays.asList(secondStep1.split(">")).get(0);
		}
		else{
			secondAtomContInverse=true;
			String secondStep1 = Arrays.asList(secondProperty.split("InverseOf\\(<")).get(1);
			secondAtom += Arrays.asList(secondStep1.split(">")).get(0);
		}
		if(!firstAtomContInverse&& !secondAtomContInverse){
			query+=firstAtom +"(?0,?1)"+secondAtom+"(?0,?1)";
		}
		if(firstAtomContInverse&& !secondAtomContInverse){
			query+=firstAtom +"(?1,?0)"+secondAtom+"(?0,?1)";
		}	
		if(!firstAtomContInverse&& secondAtomContInverse){
			query+=firstAtom +"(?0,?1)"+secondAtom+"(?1,?0)";
		}
		if(firstAtomContInverse&& secondAtomContInverse){
			query+=firstAtom +"(?1,?0)"+secondAtom+"(?1,?0)";
		}
		//System.out.println("query: " + query);
	return query;
	}
}


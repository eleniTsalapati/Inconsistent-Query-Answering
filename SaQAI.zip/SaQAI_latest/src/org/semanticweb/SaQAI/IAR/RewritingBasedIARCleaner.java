/* Copyright 2016, 2017 by the National Technical University of Athens.

   This file is part of SaQAI.

   SaQAI is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   SaQAI is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
 */
package org.semanticweb.SaQAI.IAR;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.semanticweb.hydrowl.exceptions.SystemOperationException;
import org.semanticweb.hydrowl.queryAnswering.QueryRewritingSystemInterface;
import org.semanticweb.hydrowl.rewriting.RapidQueryRewriter;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;

import common.lp.Atom;
import common.lp.Clause;
import common.lp.ClauseParser;
import common.lp.Predicate;

public class RewritingBasedIARCleaner {
	private QueryRewritingSystemInterface queryRewriter;
	
	public RewritingBasedIARCleaner(OWLOntology tboxOntology, RapidQueryRewriter queryRewritingSystem) throws SystemOperationException, OWLOntologyCreationException {
		queryRewriter=queryRewritingSystem;		
		queryRewritingSystem.loadOWLOntologyToSystem(tboxOntology); //System.out.println("ontology loaded loaded");
	}
	
	public Set<OWLAxiom> computeIARAssertionsToRemove(ArrayList<String> queries, OWLOntologyManager manager_a, OWLOntology tboxOntology, OWLOntology sourceOntology) throws Exception{
		long preprocess=System.currentTimeMillis();

		ArrayList<Clause> rewriting = new ArrayList<Clause>();
		rewriting.addAll(rewrite_DisjointQueries(queries, tboxOntology));
		Set<OWLAxiom> assertionsToRemove = new  HashSet<OWLAxiom>();
		
		Map<String, Set<OWLObjectPropertyAssertionAxiom>>  propertyAssertionsMapping = computePropertyAssertionsMapping(sourceOntology);
		Map<String,OWLClass> classesInStrings = computeClassesInStrings(sourceOntology);
		System.out.println("Preprocessing in: "+(System.currentTimeMillis()-preprocess)+" ms");	

		long startClean=System.currentTimeMillis();

		removeInconsistentAssertions( rewriting,  manager_a,  sourceOntology, propertyAssertionsMapping , classesInStrings); 
		System.out.println("Computation of the set cr(A,T) in: "+(System.currentTimeMillis()-startClean));	
		
		assertionsToRemove.addAll(computeIARInconsistentAssertions (rewriting, sourceOntology, propertyAssertionsMapping,classesInStrings));
	
	return assertionsToRemove;
	}
	
	public void removeInconsistentAssertions(ArrayList<Clause> rewriting, OWLOntologyManager manager_a, OWLOntology abox, Map<String, Set<OWLObjectPropertyAssertionAxiom>>  propertyAssertionsMapping ,Map<String,OWLClass> classesInStrings) throws OWLOntologyStorageException{
		
		Set<OWLAxiom> assertionsToRemove = new HashSet<OWLAxiom>();
		
		for(Clause query: rewriting){
			if(query.getBodyAtoms().size()==1){
				//then the query is of the for Q(x)<-A(x) or Q(x,y)<-P(x,y) i.e. T\models A \sqsubseteq \neg A or P\sqsubseteq \neg P 				
				if(query.getBodyAtomAt(0).isConcept()){
					if(classesInStrings.keySet().contains("<"+query.getBodyAtomAt(0).getPredicate().toString()+">")){
						assertionsToRemove.addAll(abox.getClassAssertionAxioms(classesInStrings.get("<"+query.getBodyAtomAt(0).getPredicate().toString()+">")));
					}
				}
				else{
					if(propertyAssertionsMapping.keySet().contains("<"+query.getBodyAtomAt(0).getPredicate().toString()+">")){
						assertionsToRemove.addAll(propertyAssertionsMapping.get("<"+query.getBodyAtomAt(0).getPredicate().toString()+">"));
					}
				}
			}
			else{
				if(query.getBody().get(0).getPredicate()==query.getBody().get(1).getPredicate()){ //then the query is of the form Q(x,y)<-P(x,y)P(y,x), i.e. T\models P\sqsubseteq \neg P^-
																		//or Q(x)<-P(x,y)P(y,x), i.e. T\models \exists P\sqsubseteq \neg \exists P^-								
					Set<OWLObjectPropertyAssertionAxiom> propAssertions = new HashSet<OWLObjectPropertyAssertionAxiom>();
			       if(propertyAssertionsMapping.keySet().contains("<"+query.getBodyAtomAt(0).getPredicate().toString()+">")){
						propAssertions.addAll(propertyAssertionsMapping.get("<"+query.getBodyAtomAt(0).getPredicate().toString()+">"));
						for(OWLObjectPropertyAssertionAxiom pr : propAssertions){
							if(pr.getSubject()==pr.getObject()){
								assertionsToRemove.add(pr);
							}
						}
			       }
				}
			}
		}
		
		//System.out.println("assertionsToRemove: " +assertionsToRemove);
		if(assertionsToRemove.size()!=0 ){
			manager_a.removeAxioms(abox, assertionsToRemove);
			manager_a.saveOntology(abox);	    			    
		
		}
	}
	
	public ArrayList<Clause> rewrite_DisjointQueries(ArrayList<String> queries, OWLOntology tboxOntology) throws Exception {
	
	//	long start=System.currentTimeMillis();		
		ArrayList<Clause> rewritings = new ArrayList<Clause>();
		for(String conjunctiveQuery : queries){
			Clause conjunctiveQueryAsClause = new ClauseParser().parseClause(conjunctiveQuery);
			ArrayList<Clause> rewriting = queryRewriter.getDL_LiteUnfolding(conjunctiveQueryAsClause, tboxOntology);	
			rewritings.addAll(rewriting);
		}		
	//	System.out.println("time for rewritings: "+(System.currentTimeMillis()-start));		
	//	System.out.println("rewriting size: "+rewritings.size());
		
	return rewritings;
	}
	
	public Map<String, Set<OWLObjectPropertyAssertionAxiom>> computePropertyAssertionsMapping( OWLOntology abox){
		
		Map<String, Set<OWLObjectPropertyAssertionAxiom>>  propertyAssertionsMapping = new HashMap<String, Set<OWLObjectPropertyAssertionAxiom>>();
	//	Set< OWLObjectPropertyAssertionAxiom> allObjPropAssertions = new HashSet< OWLObjectPropertyAssertionAxiom>();
			
			for(OWLAxiom c : abox.getABoxAxioms(false)){
				if(c instanceof OWLObjectPropertyAssertionAxiom){
	//				allObjPropAssertions.add((OWLObjectPropertyAssertionAxiom)c);					
					for(OWLObjectProperty prop: c.getObjectPropertiesInSignature()){
						if(!propertyAssertionsMapping.keySet().contains(prop.toString())){
							Set< OWLObjectPropertyAssertionAxiom> assertions = new HashSet< OWLObjectPropertyAssertionAxiom>();
							assertions.add((OWLObjectPropertyAssertionAxiom)c);	//System.out.println("+" + prop.toString());
							propertyAssertionsMapping.put(prop.toString(), assertions);
						}
						else{
							propertyAssertionsMapping.get(prop.toString()).add((OWLObjectPropertyAssertionAxiom)c);
						}
					}
				}
			}
	return propertyAssertionsMapping;
	}

	public Map<String,OWLClass> computeClassesInStrings(OWLOntology abox){
		Map<String,OWLClass> classesInStrings = new HashMap<String,OWLClass>();		
		for(OWLClass cl:  abox.getClassesInSignature()){
			classesInStrings.put(cl.toString(),cl);
		}
		
		return classesInStrings;
	}
	public Set<OWLAxiom> computeIARInconsistentAssertions(ArrayList<Clause> rewritings, OWLOntology sourceOntology, Map<String, Set<OWLObjectPropertyAssertionAxiom>> propertyAssertionsMapping, Map<String,OWLClass> classesInStrings){ 

		Set<OWLAxiom> assertionsToRemove = new  HashSet<OWLAxiom>();
		Set<Atom> atomsInRew = new  HashSet<Atom>();

		Map<String, Map<OWLIndividual, OWLClassAssertionAxiom >> classAssertionsMapping = new  HashMap<String, Map<OWLIndividual, OWLClassAssertionAxiom >>();
		Map<String, Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>>> subjectAssertionsMapping = new  HashMap< String, Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>>>();
		Map<String, Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>>> objectAssertionsMapping = new  HashMap< String, Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>>>();
		Map<String,  Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom>> propertiesAssertionsMapping = new  HashMap<String,  Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom>>();
		Map<String,  Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom>> inversePropertiesAssertionsMapping = new  HashMap<String,  Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom>>();
		
		for(int i=0; i< rewritings.size();i++ ){			
			Clause rew_i= rewritings.get(i);
			
			if(rew_i.getBody().size()>1){
				Atom firstAtom = rew_i.getBody().get(0);
				Atom secondAtom = rew_i.getBody().get(1);
				atomsInRew.add(firstAtom);
				atomsInRew.add(secondAtom);
			}
		}
			
		//Gather all individuals for each atom in rew:
		for(Atom at : atomsInRew){
			String atString = "<"+  at.getPredicate().toString() +">";
			if(at.getVariables().size()==1){ //then it is concept, find its assertions	
				Set<OWLClassAssertionAxiom> classAssertions = sourceOntology.getClassAssertionAxioms(classesInStrings.get(atString));
				
				for(OWLClassAssertionAxiom caa : classAssertions){
					String cl = caa.getClassExpression().toString();
						Map<OWLIndividual, OWLClassAssertionAxiom > indsToAssertionsMapping = new  HashMap<OWLIndividual, OWLClassAssertionAxiom >();
						OWLIndividual ind = caa.getIndividual();
						if(!indsToAssertionsMapping.containsKey(ind)){
							indsToAssertionsMapping.put(ind, caa);
						}
						
						if(!classAssertionsMapping.containsKey(cl)){
							classAssertionsMapping.put(cl, indsToAssertionsMapping);
						}
						else{
							classAssertionsMapping.get(cl).put(ind, caa);
						}
					}
				}
		
			else{ // atom is a property
				Set<OWLObjectPropertyAssertionAxiom> propertyAssertions = propertyAssertionsMapping.get(atString);
				if(at.toString().contains("_")){//then the atom is either R(_u, x) or R(x, _u) 
					if(Arrays.asList(at.toString().split(",")).get(0).contains("_")){ //then the atom is of the form R(_u, x)
						if(propertyAssertions!=null){
							for(OWLObjectPropertyAssertionAxiom paa : propertyAssertions){
								String property = paa.getProperty().toString();
								OWLIndividual ind = paa.getObject();
								if(!objectAssertionsMapping.containsKey(property)){
									Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> indsToAssertionsMapping = new  HashMap<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>>();			
									Set<OWLObjectPropertyAssertionAxiom> assertions = new  HashSet<OWLObjectPropertyAssertionAxiom>();
									assertions.add(paa);
									indsToAssertionsMapping.put(ind, assertions);
									objectAssertionsMapping.put(property, indsToAssertionsMapping);
								}
								else{
									Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> indsToAssertionsMapping =  objectAssertionsMapping.get(property);
									if(indsToAssertionsMapping!=null){
										if(!indsToAssertionsMapping.containsKey(ind)){
											Set<OWLObjectPropertyAssertionAxiom> assertions = new  HashSet<OWLObjectPropertyAssertionAxiom>();
											assertions.add(paa);
											objectAssertionsMapping.get(property).put(ind, assertions);
										}
										else{
											objectAssertionsMapping.get(property).get(ind).add(paa);
										}
									}
								}
							}
						}
					}
					else{ //then the atom is of the form R(x, _u)
						if(propertyAssertions!=null){
							for(OWLObjectPropertyAssertionAxiom paa : propertyAssertions){
								String property = paa.getProperty().toString();
								OWLIndividual ind = paa.getSubject();
								if(!subjectAssertionsMapping.containsKey(property)){
									Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> indsToAssertionsMapping = new  HashMap<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>>();			
									Set<OWLObjectPropertyAssertionAxiom> assertions = new  HashSet<OWLObjectPropertyAssertionAxiom>();
									assertions.add(paa);
									indsToAssertionsMapping.put(ind, assertions);
									subjectAssertionsMapping.put(property, indsToAssertionsMapping);
								}
								else{
									Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> indsToAssertionsMapping =  subjectAssertionsMapping.get(property);
									if(indsToAssertionsMapping!=null){
										if(!indsToAssertionsMapping.containsKey(ind)){
											Set<OWLObjectPropertyAssertionAxiom> assertions = new  HashSet<OWLObjectPropertyAssertionAxiom>();
											assertions.add(paa);
											subjectAssertionsMapping.get(property).put(ind, assertions);
										}
										else{
											subjectAssertionsMapping.get(property).get(ind).add(paa);
										}
									}
								}
							}
						}
					}
				}
				else{
					if(propertyAssertions!=null){
						if(at.getArgument(0).toString().equals("?0")){						
							for(OWLObjectPropertyAssertionAxiom paa : propertyAssertions){
								String property = paa.getProperty().toString();
								
								OWLIndividual subj = paa.getSubject();
								OWLIndividual obj = paa.getObject();
								ArrayList<OWLIndividual> inds = new ArrayList<OWLIndividual>();
								inds.add(subj);
								inds.add(obj);	
								Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom> indsToAssertionsMapping = new  HashMap<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom>();
								if(!indsToAssertionsMapping.containsKey(inds)){
									indsToAssertionsMapping.put(inds, paa);
								}
								if(!propertiesAssertionsMapping.containsKey(property)){
									propertiesAssertionsMapping.put(property, indsToAssertionsMapping);
								}
								else{
									propertiesAssertionsMapping.get(property).put(inds, paa);
								}
							}
						}
						else{
							for(OWLObjectPropertyAssertionAxiom paa : propertyAssertions){
								String property = paa.getProperty().toString();
								
								OWLIndividual subj = paa.getSubject();
								OWLIndividual obj = paa.getObject();
								ArrayList<OWLIndividual> inds = new ArrayList<OWLIndividual>();
								inds.add(obj); //because it is inverse
								inds.add(subj);	
								Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom> indsToAssertionsMapping = new  HashMap<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom>();
								if(!indsToAssertionsMapping.containsKey(inds)){
									indsToAssertionsMapping.put(inds, paa);
								}
								if(!inversePropertiesAssertionsMapping.containsKey(property)){
									inversePropertiesAssertionsMapping.put(property, indsToAssertionsMapping);
								}
								else{
									inversePropertiesAssertionsMapping.get(property).put(inds, paa);
								}
							}
						}
					}
					
				}
			}
		}
		//Now gather the assertions to remove.
		for(int i=0; i< rewritings.size();i++ ){			
			Clause rew_i= rewritings.get(i);
			if(rew_i.getBody().size()>1){
				Atom firstAtom = rew_i.getBody().get(0);
				Atom secondAtom = rew_i.getBody().get(1);
				atomsInRew.add(firstAtom);
				atomsInRew.add(secondAtom);			
				
				if((firstAtom.getVariables().size()==1) &&(secondAtom.getVariables().size()==1)){
					Map<OWLIndividual, OWLClassAssertionAxiom > firstClassIndividual2AssertionMap = classAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
					Map<OWLIndividual, OWLClassAssertionAxiom > secondClassIndividual2AssertionMap =classAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
					if(firstClassIndividual2AssertionMap != null && secondClassIndividual2AssertionMap!= null){
						Set<OWLIndividual> firstClassIndividual = new HashSet<OWLIndividual>();
						firstClassIndividual.addAll(firstClassIndividual2AssertionMap.keySet());					
						Set<OWLIndividual> secondClassIndividual =  new HashSet<OWLIndividual>();
						secondClassIndividual.addAll(secondClassIndividual2AssertionMap.keySet());
						
						firstClassIndividual.retainAll(secondClassIndividual);
					
					   for(OWLIndividual ind: firstClassIndividual){
						   assertionsToRemove.add(firstClassIndividual2AssertionMap.get(ind));
						   assertionsToRemove.add(secondClassIndividual2AssertionMap.get(ind));
					   }
					}
				}
				
			if((firstAtom.getVariables().size()!=1) && (secondAtom.getVariables().size()==1)){ //then the CQ is of the form R(_u, x)/\ C(x) or R(x, _u)/\ C(x) 
				Map<OWLIndividual, OWLClassAssertionAxiom > secondClassIndividual2AssertionMap  = classAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
				if(secondClassIndividual2AssertionMap!= null){
					Set<OWLIndividual> secondClassIndividual = new  HashSet<OWLIndividual>();
					secondClassIndividual.addAll(secondClassIndividual2AssertionMap.keySet());
					if(Arrays.asList(firstAtom.toString().split(",")).get(0).contains("_")){ //then the CQ is of the form R(_u, x)/\ C(x)
						Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> firstAtomObjectAssertionsMapping =objectAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
						if( firstAtomObjectAssertionsMapping!=null){
							
							Set<OWLIndividual> firstObjectIndividual = new HashSet<OWLIndividual>();
							firstObjectIndividual.addAll(firstAtomObjectAssertionsMapping.keySet());
							firstObjectIndividual.retainAll(secondClassIndividual);
							
							for(OWLIndividual ind: firstObjectIndividual){
								assertionsToRemove.addAll(firstAtomObjectAssertionsMapping.get(ind));
								assertionsToRemove.add(secondClassIndividual2AssertionMap.get(ind));
						   }
						}
					}
					else{ //then the CQ is of the form R( x,_u)/\ C(x)
						Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> firstAtomSubjectAssertionsMapping =subjectAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
						if( firstAtomSubjectAssertionsMapping!=null){
							
							Set<OWLIndividual> firstSubjectIndividual = new HashSet<OWLIndividual>();
							firstSubjectIndividual.addAll(firstAtomSubjectAssertionsMapping.keySet());
							firstSubjectIndividual.retainAll(secondClassIndividual);
							
							for(OWLIndividual ind: firstSubjectIndividual){
								   assertionsToRemove.addAll(firstAtomSubjectAssertionsMapping.get(ind));
								   assertionsToRemove.add(secondClassIndividual2AssertionMap.get(ind));
						   }
						}
					}
				}
			}
		
			if((firstAtom.getVariables().size()==1) && (secondAtom.getVariables().size()!=1)){ //then the CQ is of the form C(x) /\  R(_u, x) or C(x) /\  R(_u, x)  
				Map<OWLIndividual, OWLClassAssertionAxiom > firstClassIndividual2AssertionMap  = classAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
				if(firstClassIndividual2AssertionMap!= null){
					Set<OWLIndividual> firstClassIndividual =  new HashSet<OWLIndividual>();
					firstClassIndividual.addAll(firstClassIndividual2AssertionMap.keySet());
					if(Arrays.asList(secondAtom.toString().split(",")).get(0).contains("_")){ //then the CQ is of the form C(x) /\  R(_u, x)
						Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> secondAtomObjectAssertionsMapping =objectAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
						if(secondAtomObjectAssertionsMapping!=null){
							Set<OWLIndividual> secondObjectIndividual = new HashSet<OWLIndividual>();
							secondObjectIndividual.addAll(secondAtomObjectAssertionsMapping.keySet());
							secondObjectIndividual.retainAll(firstClassIndividual);
							for(OWLIndividual ind: secondObjectIndividual){
								   assertionsToRemove.addAll(secondAtomObjectAssertionsMapping.get(ind));
								   assertionsToRemove.add(firstClassIndividual2AssertionMap.get(ind));
						   }
						}
					}
					else{ //then the CQ is of the form C(x) /\  R(_u, x)  
						Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> secondAtomSubjectAssertionsMapping =subjectAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
						if(secondAtomSubjectAssertionsMapping!=null){
							Set<OWLIndividual> secondSubjectIndividual = new HashSet<OWLIndividual>();

							secondSubjectIndividual.addAll(secondAtomSubjectAssertionsMapping.keySet());
							secondSubjectIndividual.retainAll(firstClassIndividual);
							
							for(OWLIndividual ind: secondSubjectIndividual){
								   assertionsToRemove.addAll(secondAtomSubjectAssertionsMapping.get(ind));
								   assertionsToRemove.add(firstClassIndividual2AssertionMap.get(ind));
						   }
						}
					}
				}
			}
		
			if((firstAtom.getVariables().size()!=1) && (secondAtom.getVariables().size()!=1)){
					//then the CQ can be one of: 1. Q(x)<-  a. R(x,_u) /\ P(x,_u') | b. R(x,_u) /\ P(_u',x) |c. R(_u,x) /\ P(_u',x) |d. R(_u,x) /\ P(x,_u')
					   // or 2. a. Q(x,y) <- R(x, y) /\ P(x,y) |b. Q(x,y) <- R(x, y) /\ P(y, x)
//					//1.
					if(firstAtom.toString().contains("_")){
					//a.R(x,_u) /\ P(x,_u')
						if(Arrays.asList(firstAtom.toString().split(",")).get(1).contains("_") && Arrays.asList(secondAtom.toString().split(",")).get(1).contains("_")){ 
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> firstAtomSubjectAssertionsMapping =subjectAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
							Set<OWLIndividual> firstSubjectIndividual = new HashSet<OWLIndividual>();
							Set<OWLIndividual> secondSubjectIndividual = new HashSet<OWLIndividual>();
							
							if(firstAtomSubjectAssertionsMapping!=null){
								firstSubjectIndividual.addAll(firstAtomSubjectAssertionsMapping.keySet());
							}						
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> secondAtomSubjectAssertionsMapping =subjectAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
							if(secondAtomSubjectAssertionsMapping!=null){
								secondSubjectIndividual.addAll(secondAtomSubjectAssertionsMapping.keySet());
							}
							firstSubjectIndividual.retainAll(secondSubjectIndividual);
			
							for(OWLIndividual ind: firstSubjectIndividual){
								   assertionsToRemove.addAll(firstAtomSubjectAssertionsMapping.get(ind));
								   assertionsToRemove.addAll(secondAtomSubjectAssertionsMapping.get(ind));
						   }
						}

					//b.R(x,_u) /\ P(_u',x)
						if(Arrays.asList(firstAtom.toString().split(",")).get(1).contains("_") && Arrays.asList(secondAtom.toString().split(",")).get(0).contains("_")){ 
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> firstAtomSubjectAssertionsMapping =subjectAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
							Set<OWLIndividual> firstSubjectIndividual = new HashSet<OWLIndividual>();
							Set<OWLIndividual> secondObjectIndividual = new HashSet<OWLIndividual>();
							
							if(firstAtomSubjectAssertionsMapping!=null){
								firstSubjectIndividual.addAll(firstAtomSubjectAssertionsMapping.keySet());
							}						
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> secondAtomObjectAssertionsMapping =objectAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
							if(secondAtomObjectAssertionsMapping!=null){
								secondObjectIndividual.addAll(secondAtomObjectAssertionsMapping.keySet());
							}
							firstSubjectIndividual.retainAll(secondObjectIndividual);
							for(OWLIndividual ind: firstSubjectIndividual){
								   assertionsToRemove.addAll(firstAtomSubjectAssertionsMapping.get(ind));
								   assertionsToRemove.addAll(secondAtomObjectAssertionsMapping.get(ind));
						   }
						}
							
					//c.R(_u,x) /\ P(_u',x)
						if(Arrays.asList(firstAtom.toString().split(",")).get(0).contains("_") && Arrays.asList(secondAtom.toString().split(",")).get(0).contains("_")){ 
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> firstAtomObjectAssertionsMapping =objectAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
							Set<OWLIndividual> firstObjectIndividual = new HashSet<OWLIndividual>();
							Set<OWLIndividual> secondObjectIndividual = new HashSet<OWLIndividual>();
							
							if(firstAtomObjectAssertionsMapping!=null){
								firstObjectIndividual.addAll(firstAtomObjectAssertionsMapping.keySet());
							}						
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> secondAtomObjectAssertionsMapping =objectAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
							if(secondAtomObjectAssertionsMapping!=null){
								secondObjectIndividual.addAll(secondAtomObjectAssertionsMapping.keySet());
							}
							firstObjectIndividual.retainAll(secondObjectIndividual);
							for(OWLIndividual ind: firstObjectIndividual){
								   assertionsToRemove.addAll(firstAtomObjectAssertionsMapping.get(ind));
								   assertionsToRemove.addAll(secondAtomObjectAssertionsMapping.get(ind));
						   }
						}
						
					//d.R(_u,x) /\ P(x,_u')
						if(Arrays.asList(firstAtom.toString().split(",")).get(0).contains("_") && Arrays.asList(secondAtom.toString().split(",")).get(1).contains("_")){ 
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> firstAtomObjectAssertionsMapping =objectAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
							Set<OWLIndividual> firstObjectIndividual = new HashSet<OWLIndividual>();
							Set<OWLIndividual> secondSubjectIndividual = new HashSet<OWLIndividual>();
							
							if(firstAtomObjectAssertionsMapping!=null){
								firstObjectIndividual.addAll(firstAtomObjectAssertionsMapping.keySet());
							}						
							Map<OWLIndividual, Set<OWLObjectPropertyAssertionAxiom>> secondAtomSubjectAssertionsMapping =subjectAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
							if(secondAtomSubjectAssertionsMapping!=null){
								secondSubjectIndividual.addAll(secondAtomSubjectAssertionsMapping.keySet());
							}
							firstObjectIndividual.retainAll(secondSubjectIndividual);
							
							for(OWLIndividual ind: firstObjectIndividual){
								   assertionsToRemove.addAll(firstAtomObjectAssertionsMapping.get(ind));
								   assertionsToRemove.addAll(secondAtomSubjectAssertionsMapping.get(ind));
						   }
						}						
					}
					else{ //2. a. Q(x,y) <- R(x, y) /\ P(x,y) b. Q(x,y) <- R(y, x) /\ P(x,y) c. Q(x,y) <- R(x, y) /\ P(y,x)
						//a.Q(x,y) <- R(x, y) /\ P(x,y)
						if(firstAtom.getArgument(0).toString().equals("?0") && secondAtom.getArgument(0).toString().equals("?0")){ 
							Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom > firstPropertyIndividuals2AssertionMap = propertiesAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
							Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom > secondPropertyIndividuals2AssertionMap =propertiesAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
							
							if(firstPropertyIndividuals2AssertionMap != null && secondPropertyIndividuals2AssertionMap!= null){
								//System.out.println(">>>>>>>>>1>>>>>>>>>>>>>>>" + firstAtom +" " +secondAtom);
									
								Set<ArrayList<OWLIndividual>> firstPropertyIndividuals = new HashSet<ArrayList<OWLIndividual>>();
								firstPropertyIndividuals.addAll(firstPropertyIndividuals2AssertionMap.keySet());					
								Set<ArrayList<OWLIndividual>> secondPropertyIndividuals = new HashSet<ArrayList<OWLIndividual>>();
								secondPropertyIndividuals.addAll(secondPropertyIndividuals2AssertionMap.keySet());					
								
								firstPropertyIndividuals.retainAll(secondPropertyIndividuals);
							
							   for(ArrayList<OWLIndividual> ind: firstPropertyIndividuals){
								  // System.out.println(">1>"+ind);
								   assertionsToRemove.add(firstPropertyIndividuals2AssertionMap.get(ind));
								   assertionsToRemove.add(secondPropertyIndividuals2AssertionMap.get(ind));
								   
							   }
							}
						}
						// b. Q(x,y) <- R(y, x) /\ P(x,y)
						if(firstAtom.getArgument(0).toString().equals("?1") && secondAtom.getArgument(0).toString().equals("?0")){ 
							Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom > firstPropertyIndividuals2AssertionMap = inversePropertiesAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
							Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom > secondPropertyIndividuals2AssertionMap =propertiesAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
							
							if(firstPropertyIndividuals2AssertionMap != null && secondPropertyIndividuals2AssertionMap!= null){
								//System.out.println(">>>>>>>>>>2>>>>>>>>>>>>>>" + firstAtom +" " +secondAtom);
									
								Set<ArrayList<OWLIndividual>> firstPropertyIndividuals = new HashSet<ArrayList<OWLIndividual>>();
								firstPropertyIndividuals.addAll(firstPropertyIndividuals2AssertionMap.keySet());					
								Set<ArrayList<OWLIndividual>> secondPropertyIndividuals = new HashSet<ArrayList<OWLIndividual>>();
								secondPropertyIndividuals.addAll(secondPropertyIndividuals2AssertionMap.keySet());					
								
								firstPropertyIndividuals.retainAll(secondPropertyIndividuals);
							
							   for(ArrayList<OWLIndividual> ind: firstPropertyIndividuals){
								  // System.out.println(">2>"+ind);
								   assertionsToRemove.add(firstPropertyIndividuals2AssertionMap.get(ind));
								   assertionsToRemove.add(secondPropertyIndividuals2AssertionMap.get(ind));
								   
							   }
							}
						}
						//c. Q(x,y) <- R(x, y) /\ P(y,x)
						if(firstAtom.getArgument(0).toString().equals("?0") && secondAtom.getArgument(0).toString().equals("?1")){ 
							Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom > firstPropertyIndividuals2AssertionMap = propertiesAssertionsMapping.get("<"+firstAtom.getPredicate().toString()+">");
							Map<ArrayList<OWLIndividual>, OWLObjectPropertyAssertionAxiom > secondPropertyIndividuals2AssertionMap =inversePropertiesAssertionsMapping.get("<"+secondAtom.getPredicate().toString()+">");
							
							if(firstPropertyIndividuals2AssertionMap != null && secondPropertyIndividuals2AssertionMap!= null){
								Set<ArrayList<OWLIndividual>> firstPropertyIndividuals = new HashSet<ArrayList<OWLIndividual>>();
								firstPropertyIndividuals.addAll(firstPropertyIndividuals2AssertionMap.keySet());					
								Set<ArrayList<OWLIndividual>> secondPropertyIndividuals = new HashSet<ArrayList<OWLIndividual>>();
								secondPropertyIndividuals.addAll(secondPropertyIndividuals2AssertionMap.keySet());					
								
								firstPropertyIndividuals.retainAll(secondPropertyIndividuals);
							
							   for(ArrayList<OWLIndividual> ind: firstPropertyIndividuals){
								   assertionsToRemove.add(firstPropertyIndividuals2AssertionMap.get(ind));
								   assertionsToRemove.add(secondPropertyIndividuals2AssertionMap.get(ind));
							   }
							}
						}
					}

				}
			}
		}

		System.out.println("# of assertions to remove: "+assertionsToRemove.size());		
		
//		logger.info("UCQ part evalauted over OWLim in: " + evalTime + " ms and returned: " + incompleteReasoner.getNumberOfReturnedAnswersCompletePart()  + " answers.\n");
	return assertionsToRemove;
	}
}

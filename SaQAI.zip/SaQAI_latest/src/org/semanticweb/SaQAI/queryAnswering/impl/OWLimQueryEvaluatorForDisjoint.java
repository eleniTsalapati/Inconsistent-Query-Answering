/* Copyright 2016, 2017 by the National Technical University of Athens.

   This file is part of SaQAI.

   SaQAI is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   SaQAI is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
 */

package org.semanticweb.SaQAI.queryAnswering.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import common.lp.Atom;
import common.lp.Clause;
import common.lp.Term;

public class OWLimQueryEvaluatorForDisjoint {

	public static String clauseCQ2SeRQL_Disjoint(Clause conjunctiveQuery, ArrayList<Atom> atomsOfConjunctiveQuery, ArrayList<Map<String, Set<String>>>  map,  Map<String,Set<String>> disjMapToSkip) {
		Map<String, Set<String>> classMap =  map.get(0);
		Map<String, Set<String>> propMap =  map.get(1);
		
		String serqlQuery="";
		String negatives="";
		
		for (int i=0 ; i<atomsOfConjunctiveQuery.size() ; i++) {		
			
			Atom at = atomsOfConjunctiveQuery.get(i); //System.out.println("--" + at);
		
			//atomsInQuery.add(at);
			if (at.isConcept()) {//at.toString, Mapping <string, set of strings> global metabliti edw, bres to set tou atom, kai an at:A(x), kai set {B, \exists R} tote not B(x), not R(x,y)...y?
				serqlQuery+="{"+handleArgument(at.getArgument(0))+"} rdf:type {<"+at.getPredicate()+ ">}, ";
				
				if(!at.getPredicate().toString().contains("_.u")){	
					if(classMap.keySet().contains("<"+at.getPredicate().toString()+">") && !(classMap.get("<"+at.getPredicate().toString()+">")==null) ){
						negatives+=	 " WHERE NOT "+"("+handleArgument( at.getArgument(0))+" IN ( " ; 
						negatives= addDisjointConcepts(negatives, classMap, "<"+at.getPredicate().toString()+">",at.getArgument(0));		
						negatives+=")"+"), ";
					}
					else negatives+=",";
				}
				else
				{//IF THE ATOM IS ADDED FROM RAPID FOR THE UNFOLDING OF Q(x)<-R(x,y) with R(x,f(x))<-A(x). Rapid creates a fresh CONCEPT R_.u(x) (the fresh atom has always "_.u"  the query Q(x)<-R_.u(x), and the axioms R_.u(x)<-R(x,y), R_.u(x)<-A(x)  
				//we add all the disjointnesses of R(x,y).
					
					String[] partss =at.getPredicate().toString().split("_.u");
			    	String init_atom = Arrays.asList(partss).get(0);
			    	if(propMap.keySet().contains("<"+init_atom+">") && !(propMap.get("<"+init_atom+">")==null) ){
			    		negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
			    		negatives= addDisjointProp(negatives, propMap, at, init_atom, disjMapToSkip);
					}
			    	if(classMap.keySet().contains("ObjectSomeValuesFrom(<"+init_atom+"> owl:Thing)")){ //edw giati den exw where not?
			    		negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; //to ebala..
			    		negatives= addDisjointConcepts(negatives, classMap, "ObjectSomeValuesFrom(<"+init_atom+"> owl:Thing)", at.getArgument(0));		
			    	}
			    	if(classMap.keySet().contains("ObjectSomeValuesFrom(InverseOf(<"+init_atom+"> owl:Thing)")) {  //edw giati den exw where not?
			    		negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; //to ebala..
			    		negatives= addDisjointConcepts(negatives, classMap, "ObjectSomeValuesFrom(InverseOf(<"+init_atom+">) owl:Thing)", at.getArgument(1));		
			    	}
			    	else negatives+=",";
			    	negatives+=")"+"), ";
				}
			}
			else{
				
			    serqlQuery+="{"+handleArgument(at.getArgument(0))+"} <"+at.getPredicate()+ "> {"+handleArgument(at.getArgument(1))+"}, ";
			    boolean b=false;
			    if(propMap.keySet().contains("<"+at.getPredicate().toString()+">") && !(propMap.get("<"+at.getPredicate().toString()+">")==null) ){
			    	
			    	negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
			    	negatives= addDisjointProp(negatives, propMap, at, at. getPredicate().toString(), disjMapToSkip);
					b=true;		
				}
				if (classMap.keySet().contains("ObjectSomeValuesFrom(<"+at.getPredicate()+"> owl:Thing)")){
					if(!b){
						negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
						b=true;
					}
					negatives= addDisjointConcepts(negatives, classMap, "ObjectSomeValuesFrom(<"+at. getPredicate().toString()+"> owl:Thing)", at.getArgument(0));
					b=true;
				}
				if (classMap.keySet().contains("ObjectSomeValuesFrom(InverseOf(<"+at.getPredicate()+">) owl:Thing)")){
					if(!b){
						negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
						b=true;
					}
					negatives= addDisjointConcepts(negatives, classMap,"ObjectSomeValuesFrom(InverseOf(<"+at.getPredicate()+">) owl:Thing)",at.getArgument(1));
					b=true;
				}
				if(!b){
					negatives+=",";
				}
				else{
					negatives+=")"+"), ";
				}
			}
		}
		
		serqlQuery+=negatives;	
	//	System.out.println("--------------------------------------");
		if(negatives==""){
			serqlQuery+="END";
			serqlQuery=serqlQuery.replace(", END", "");
			serqlQuery=serqlQuery.replace("?", "");
		}
		else{
		serqlQuery=serqlQuery.replace(", , ", " ");
		serqlQuery=serqlQuery.replace("},  WHERE", "}  WHERE");
		serqlQuery=serqlQuery.replace("),  WHERE NOT", ")  AND NOT ");
		serqlQuery=serqlQuery.replace("UNION ))", "))");
		serqlQuery+="END";
		serqlQuery=serqlQuery.replace(", END", "");
		serqlQuery=serqlQuery.replace(",END", "");
		serqlQuery=serqlQuery.replace("?", "");
		//	System.out.println("query: " + serqlQuery);
		}
		return serqlQuery;
	}

	private static String addDisjointProp(String serqlQuery, Map<String, Set<String>> propMap, Atom at, String mainProp,  Map<String,Set<String>> disjMapToSkip){
		
		for(String s: propMap.get("<"+mainProp+">")){
			if(disjMapToSkip.keySet().contains("<"+mainProp+">")){
				if(!disjMapToSkip.get("<"+mainProp+">").contains(s)){
					//System.out.println(at);
					if(!s.contains("InverseOf")){
						serqlQuery+="SELECT " +handleArgument( at.getArgument(0)) + " FROM {"+handleArgument(at.getArgument(0)) +"}"+ s+ "{ "+handleArgument( at.getArgument(1))+" }" +
								" UNION ";							
					}
					else{
						String[] parts =s.split("<");
						String part1 = Arrays.asList(parts).get(1);
						String[] newparts =part1.split(">");
				//System.out.println(at);
						serqlQuery+="SELECT " +handleArgument( at.getArgument(0)) + " FROM {" +handleArgument( at.getArgument(1))+"} <"+ Arrays.asList(newparts).get(0)+ "> {"+ handleArgument(at.getArgument(0))+" }" +
								" UNION ";
					}
				}
			}
		}
	return serqlQuery;
	}
	
	public static String clauseCQ2SeRQL_Disjoint(Clause conjunctiveQuery, ArrayList<Atom> atomsOfConjunctiveQuery, ArrayList<Map<String, Set<String>>>  map, Set<Clause> additionalOntologyAxioms) {
		Map<String, Set<String>> classMap =  map.get(0);
		Map<String, Set<String>> propMap =  map.get(1);
		boolean oneAtom = false;
		
		String serqlQuery="";
		String negatives="";
		long start = System.currentTimeMillis();
		for (int i=0 ; i<atomsOfConjunctiveQuery.size() ; i++) {		
			
			Atom at = atomsOfConjunctiveQuery.get(i); //
			//atomsInQuery.add(at);
			if (at.isConcept()) {
				serqlQuery+="{"+handleArgument(at.getArgument(0))+"} rdf:type {<"+at.getPredicate()+ ">}, ";
				
				if(!at.getPredicate().toString().contains("_.u")){	
					if(classMap.keySet().contains("<"+at.getPredicate().toString()+">") && !(classMap.get("<"+at.getPredicate().toString()+">")==null) ){
						negatives+=	 " WHERE NOT "+"("+handleArgument( at.getArgument(0))+" IN ( " ; 
						negatives= addDisjointConcepts(negatives, classMap, "<"+at.getPredicate().toString()+">",at.getArgument(0));		
						negatives+=")"+") ";
					}
					else{
						if(atomsOfConjunctiveQuery.size()==1){
							oneAtom = true;
							serqlQuery=serqlQuery.replace(", ", "");
							serqlQuery=serqlQuery.replace("?", "");
						}
					}
 				}
				else 
				{//IF THE ATOM IS ADDED FROM RAPID FOR THE UNFOLDING OF Q(x)<-R(x,y) with R(x,f(x))<-A(x). Rapid creates a fresh CONCEPT R_.u(x) (the fresh atom has always "_.u"  the query Q(x)<-R_.u(x), and the axioms R_.u(x)<-R(x,y), R_.u(x)<-A(x)  
				//we add all the disjointnesses of R(x,y) AND A(x).
					Boolean addedNegativeAtoms = false;
					for(Clause ax: additionalOntologyAxioms){
						if(ax.getHead().getPredicate().equals(at.getPredicate())){
							String init_atom = ax.getBodyAtomAt(0).getPredicate().toString();
							if(ax.getBodyAtomAt(0).isRole()&& !init_atom.contains("_u")){ //i.e. the axiom has the form P_u(x)<-P(x,y)
								if(propMap.keySet().contains("<"+init_atom+">") && !(propMap.get("<"+init_atom+">")==null) ){
						    		negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 						    		
						    		negatives= addDisjointProp(negatives, propMap, at, init_atom);
						    		addedNegativeAtoms = true;
								}
								if(classMap.keySet().contains("ObjectSomeValuesFrom(<"+init_atom+"> owl:Thing)")){ 
						    		if(!addedNegativeAtoms){
						    			negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 	
						    		}
						    		negatives= addDisjointConcepts(negatives, classMap, "ObjectSomeValuesFrom(<"+init_atom+"> owl:Thing)", at.getArgument(0));		
						    		addedNegativeAtoms = true;
						    	}
								if(classMap.keySet().contains("ObjectSomeValuesFrom(InverseOf(<"+init_atom+"> owl:Thing)")) {  
						    		if(!addedNegativeAtoms){
						    			negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
						    		}
									negatives= addDisjointConcepts(negatives, classMap, "ObjectSomeValuesFrom(InverseOf(<"+init_atom+">) owl:Thing)", at.getArgument(1));		
						    		addedNegativeAtoms = true;
						    	}
						    	if(atomsOfConjunctiveQuery.size()==1&& !addedNegativeAtoms){
									oneAtom = true;
									serqlQuery=serqlQuery.replace(", ", "");
									serqlQuery=serqlQuery.replace("?", "");
								}
								if(addedNegativeAtoms){
									negatives+=")"+") "; 
								}
							}
							else{
								if(!ax.getBodyAtomAt(0).toString().contains("_.u")&&ax.getBodyAtomAt(0).isConcept()){//i.e. the axiom has the form P_u(x)<-A(x)
									if(classMap.keySet().contains("<"+init_atom+">") && !(classMap.get("<"+init_atom+">")==null) ){
										negatives+=	 " WHERE NOT "+"("+handleArgument( at.getArgument(0))+" IN ( " ; 
										negatives= addDisjointConcepts(negatives, classMap, "<"+init_atom+">",at.getArgument(0));		
										negatives+=")"+") ";
									}

								}
							}
						}
					}
				}
			}
			else{
			    serqlQuery+="{"+handleArgument(at.getArgument(0))+"} <"+at.getPredicate()+ "> {"+handleArgument(at.getArgument(1))+"}, ";
			    boolean b=false;
			    if(propMap.keySet().contains("<"+at.getPredicate().toString()+">") && !(propMap.get("<"+at.getPredicate().toString()+">")==null) ){
			    	negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
			    	negatives= addDisjointProp(negatives, propMap, at, at. getPredicate().toString());
					b=true;		
				}
				if (classMap.keySet().contains("ObjectSomeValuesFrom(<"+at.getPredicate()+"> owl:Thing)")){
					if(!b){
						negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
						b=true;
					}
					negatives= addDisjointConcepts(negatives, classMap, "ObjectSomeValuesFrom(<"+at. getPredicate().toString()+"> owl:Thing)", at.getArgument(0));
					b=true;
				}
				if (classMap.keySet().contains("ObjectSomeValuesFrom(InverseOf(<"+at.getPredicate()+">) owl:Thing)")){
					if(!b){
						negatives+=	 " WHERE NOT "+"("+ handleArgument( at.getArgument(0)) +" IN ( " ; 
						b=true;
					}
					negatives= addDisjointConcepts(negatives, classMap,"ObjectSomeValuesFrom(InverseOf(<"+at.getPredicate()+">) owl:Thing)",at.getArgument(1));
					b=true;
				}
				if(!b){
					if(atomsOfConjunctiveQuery.size()==1){
						oneAtom = true;
						serqlQuery=serqlQuery.replace(", ", "");
						serqlQuery=serqlQuery.replace("?", "");
					}				
				}
				else{ 
					negatives+=")"+") ";
				}
			}
		}
			
		if(!oneAtom){		
			serqlQuery+=negatives;	
			serqlQuery=serqlQuery.replace(") ,", ") ");
			serqlQuery=serqlQuery.replace(", , ", " ");
			serqlQuery=serqlQuery.replace("},  WHERE", "}  WHERE");
			serqlQuery=serqlQuery.replace(")  WHERE NOT", ")  AND NOT ");
			serqlQuery=serqlQuery.replace("UNION ))", "))");
			serqlQuery=serqlQuery.replace("UNION ,))", "))");
			serqlQuery=serqlQuery.replace("?", "");
		}
	//	System.out.println("query: " + serqlQuery);
		return serqlQuery;
	}

	private static String addDisjointProp(String serqlQuery, Map<String, Set<String>> propMap, Atom at, String mainProp){
		
		for(String s: propMap.get("<"+mainProp+">")){
				if(!s.contains("InverseOf")){
						if(at.isRole()){
							serqlQuery+="SELECT " +handleArgument( at.getArgument(0)) + " FROM {"+handleArgument(at.getArgument(0)) +"}"+ s+ "{ "+handleArgument( at.getArgument(1))+" }" +
									" UNION ";	
						}
						if(at.isConcept()){
							serqlQuery+="SELECT " +handleArgument( at.getArgument(0)) + " FROM {"+handleArgument(at.getArgument(0)) +"}"+ s+ "{ Y }" +
									" UNION ";
						}
					}
				else{
					String[] parts =s.split("<");
					String part1 = Arrays.asList(parts).get(1);
					String[] newparts =part1.split(">");
					if(at.isRole()){
						serqlQuery+="SELECT " +handleArgument( at.getArgument(0)) + " FROM {" +handleArgument( at.getArgument(1))+"} <"+ Arrays.asList(newparts).get(0)+ "> {"+ handleArgument(at.getArgument(0))+" }" +
							" UNION ";
					}
					if(at.isConcept()){
						serqlQuery+="SELECT " +handleArgument( at.getArgument(0)) + " FROM {Y} <"+ Arrays.asList(newparts).get(0)+ "> {"+ handleArgument(at.getArgument(0))+" }" +
								" UNION ";
					}
				}
			}
	return serqlQuery;
	}
	
	private static String addDisjointConcepts(String serqlQuery, Map<String, Set<String>> classMap,  String mainConcept, Term t ){
		for(String s: classMap.get(mainConcept)){
			if(!s.contains("ObjectSomeValuesFrom")){
				serqlQuery+="SELECT * FROM {"+handleArgument(t)+"} rdf:type  { "+ s+ " }" +
						" UNION ";	
			}
			else if (s.contains("ObjectSomeValuesFrom") && !s.contains("InverseOf") ){
				String[] parts =s.split("<");
				String part1 = Arrays.asList(parts).get(1);
				String[] newparts =part1.split(">");
				serqlQuery+="SELECT * FROM {"+handleArgument(t)+"} <"+Arrays.asList(newparts).get(0)+ "> { }" +
						" UNION ";							
				}
			else if (s.contains("ObjectSomeValuesFrom") && s.contains("InverseOf") ){
					String[] parts =s.split("<");
					String part1 = Arrays.asList(parts).get(1);
					String[] newparts =part1.split(">");
					serqlQuery+="SELECT * FROM { } <"+Arrays.asList(newparts).get(0)+ ">"+ " { "+ handleArgument(t)+" } " +
							" UNION ";													
			}
		}
		return serqlQuery;
	}
	
	private static String handleArgument(Term argument) {
		if (argument.isVariable())
			return "X"+argument.toString();
		else
			return "<"+argument.toString()+">";
	}

}

package org.semanticweb.SaQAI.ICAR;
/* Copyright 2016, 2017 by the National Technical University of Athens.

   This file is part of SaQAI.

   SaQAI is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   SaQAI is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import org.semanticweb.hydrowl.queryAnswering.RewritingBasedQueryEvaluator;
import org.semanticweb.hydrowl.queryAnswering.impl.OWLimQueryEvaluator;
import org.semanticweb.hydrowl.rewriting.RapidQueryRewriter;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import  org.semanticweb.SaQAI.dlReasoning.CreateDisjointnessMapping;
import org.semanticweb.SaQAI.mainInconsistencyCheck.InconsistencyChecker;

public class ICAR{
	
	public void ICARQA(ArrayList<String> queries,  String repairedOntologyFile, String dataset, Boolean refMin) throws Exception {
		
		IRI physicalURIOfBaseOntology = IRI.create(repairedOntologyFile);
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		OWLOntology sourceOntology = manager.loadOntology(physicalURIOfBaseOntology);
		
		//compute all disjointness axioms:
		long start_disjMap = System.currentTimeMillis();
		ArrayList<Map<String, Set<String>>>  map = CreateDisjointnessMapping.createDisjointnessMapping(sourceOntology,manager,refMin, dataset);
		
		System.out.println("Computation of the disjoint axioms implied from the ontology in: " + (System.currentTimeMillis()-start_disjMap) + " ms\n");				
		RewritingBasedQueryEvaluator hybridQA = new RewritingBasedQueryEvaluator(new OWLimQueryEvaluator(),new RapidQueryRewriter());
		
		hybridQA.loadDatasetToSystem(new String[] {dataset});

		//cr(A,T):
		long start_inc = System.currentTimeMillis();
		InconsistencyChecker ic= new InconsistencyChecker();
		
		if(!ic.removeInconsistencies(map, hybridQA, dataset)){ //hasn't found any inconsistencies	
			System.out.println("Computation of cr(T,A) in: " + (System.currentTimeMillis()-start_inc) + " ms\n");						
			
			hybridQA.loadOntologyToSystem(repairedOntologyFile);
			
			//compute ICAR answers:		
			for (int i=0 ; i<queries.size() ; i++) {
					System.out.println("Evaluating query: " + i );
					runTest_Disjoint(hybridQA,queries.get(i),map);	
			}			
			hybridQA.shutDown();
			}
		else{ //has found inconsistencies.
			hybridQA.shutDown();
			RewritingBasedQueryEvaluator hybridQA_new = new RewritingBasedQueryEvaluator(new OWLimQueryEvaluator(),new RapidQueryRewriter());
			System.out.println("Loading the new dataset (cr(A,T)) to OWLim...");
			
			hybridQA_new.loadOntologyToSystem(repairedOntologyFile);
			hybridQA_new.loadDatasetToSystem(new String[] {dataset});
			
			System.out.println("Computation of cr(T,A) in: " + (System.currentTimeMillis()-start_inc) + " ms\n");						
					
			//compute ICAR answers:		
			for (int i=0 ; i<queries.size() ; i++) {
					System.out.println("Evaluating query: " + i );
					runTest_Disjoint(hybridQA_new,queries.get(i),map);	
			}			
			hybridQA_new.shutDown();
		}
	}


	
	public void  runTest_Disjoint(RewritingBasedQueryEvaluator hybridQA, String query, ArrayList<Map<String, Set<String>>>  map ) throws Exception {
		
		long start = System.currentTimeMillis();
		hybridQA.evaluateQuery_Disjoint(query, map);
		System.out.println("************Query evaluated in " + (System.currentTimeMillis()-start) + " ms *************** \n");
	}
	
	

	
}
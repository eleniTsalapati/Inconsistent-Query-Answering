package org.semanticweb.SaQAI.ICAR;
/* Copyright 2016, 2017 by the National Technical University of Athens.

   This file is part of SaQAI.

   SaQAI is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   SaQAI is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.ArrayList;
import java.util.Arrays;
//package org.semanticweb.hydrowl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.openrdf.sesame.query.QueryResultsTable;
import org.semanticweb.hydrowl.queryAnswering.RewritingBasedQueryEvaluator;
import org.semanticweb.hydrowl.queryAnswering.impl.OWLimQueryEvaluator;
import org.semanticweb.hydrowl.rewriting.RapidQueryRewriter;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLDisjointObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import  org.semanticweb.SaQAI.dlReasoning.CreateDisjointnessMapping;
import org.semanticweb.SaQAI.mainInconsistencyCheck.InconsistencyChecker;

public class ICAR_skipDisjProp{
	
	public void ICARQA(ArrayList<String> queries, String repairedOntologyFile, String dataset, Boolean refMin) throws Exception {
		
		IRI physicalURIOfBaseOntology = IRI.create(repairedOntologyFile);
		OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
		OWLOntology sourceOntology = manager.loadOntology(physicalURIOfBaseOntology);
		
		RewritingBasedQueryEvaluator hybridQA = new RewritingBasedQueryEvaluator(new OWLimQueryEvaluator(),new RapidQueryRewriter());		
		hybridQA.loadDatasetToSystem(new String[] {dataset});
		hybridQA.loadOntologyToSystem(repairedOntologyFile);

		long start_disjProp = System.currentTimeMillis();
		HashSet<OWLAxiom> skipDisjProp = new HashSet<OWLAxiom>();
		skipDisjProp.addAll(skipDisjProp(sourceOntology, manager, hybridQA));		
		System.out.println("Computation of redundant disjoint property axioms in: " + (System.currentTimeMillis()-start_disjProp) + " ms\n");
		
		long start_disjMap = System.currentTimeMillis();
		ArrayList<Map<String, Set<String>>>  map = CreateDisjointnessMapping.createDisjointnessMapping(sourceOntology,manager, skipDisjProp, refMin, dataset, hybridQA);
		System.out.println("Computation of the disjoint axioms implied from the ontology in: " + (System.currentTimeMillis()-start_disjMap) + " ms\n");
	
		long start_inc = System.currentTimeMillis();
		InconsistencyChecker ic= new InconsistencyChecker();
		
		if(!ic.removeInconsistencies(map, hybridQA, dataset)){	
			System.out.println("Computation of set cr(T,A): " + (System.currentTimeMillis()-start_inc) + " ms\n");
			hybridQA.loadOntologyToSystem(repairedOntologyFile);
			
			for (int i=0 ; i<queries.size()  ; i++) {	
				System.out.println("Evaluating query: " + i );
				runTest_Disjoint(hybridQA,queries.get(i),map);	
			}			
			hybridQA.shutDown();
		}
		else{
			hybridQA.shutDown();
			RewritingBasedQueryEvaluator hybridQA_new = new RewritingBasedQueryEvaluator(new OWLimQueryEvaluator(),new RapidQueryRewriter());
			System.out.println("Loading the new dataset (cr(A,T)) to OWLim...");
			hybridQA_new.loadDatasetToSystem(new String[] {dataset});
			hybridQA_new.loadOntologyToSystem(repairedOntologyFile);
			System.out.println("Computation of cr(T,A) in: " + (System.currentTimeMillis()-start_inc) + " ms\n");						
					
			//compute ICAR answers:		
			for (int i=0 ; i<queries.size() ; i++) {
					System.out.println("Evaluating query: " + i );
					runTest_Disjoint(hybridQA_new,queries.get(i),map);	
			}			
			hybridQA_new.shutDown();
		}
	}

	public void runTest_Disjoint(RewritingBasedQueryEvaluator hybridQA, String query, ArrayList<Map<String, Set<String>>>  map ) throws Exception {
		
		long start = System.currentTimeMillis();
		hybridQA.evaluateQuery_Disjoint(query, map);
		System.out.println("************Query evaluated in " + (System.currentTimeMillis()-start) + " ms *************** \n");
	}
	
	public HashSet<OWLAxiom> skipDisjProp(OWLOntology sourceOntology, OWLOntologyManager manager,RewritingBasedQueryEvaluator hybridQA) throws Exception{
		
		ArrayList<String> queries = new ArrayList<String>();
		Map<String, OWLAxiom> queriesFromDisjPropMap= createQueries( sourceOntology);
		queries.addAll(queriesFromDisjPropMap.keySet());
		
		HashSet<OWLAxiom> skipDisjProp = new HashSet<OWLAxiom>();
		
		for(String q : queries){
			QueryResultsTable table = hybridQA.evaluateDisjointProperties(q);
			if(table.getRowCount()==0){				
				skipDisjProp.add(queriesFromDisjPropMap.get(q));
			}	
		}
		return skipDisjProp;
	}
	
	
	private Map<String, OWLAxiom> createQueries(OWLOntology ontology){
		Map<String, OWLAxiom> queriesStrings2Axioms = new 	HashMap<String, OWLAxiom>();
				
		for(OWLAxiom a :ontology.getAxioms()){
			if(a instanceof OWLDisjointObjectPropertiesAxiom){
				Set<OWLObjectPropertyExpression> cls = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();		
				ArrayList<OWLObjectPropertyExpression> clsA= new ArrayList<OWLObjectPropertyExpression>();
				clsA.addAll(cls);
				String query = "Q(?0,?1) <- ";
				String firstAtom ="";
				String secondAtom ="";
				
				String firstProperty =clsA.get(0).toString();
				String firstStep1 = Arrays.asList(firstProperty.split("<")).get(1);
				if(!firstProperty.contains("Inverse")){							
				    firstAtom += Arrays.asList(firstStep1.split(">")).get(0)+"(?0,?1)";
				}
				else{
					firstAtom += Arrays.asList(firstStep1.split(">")).get(0)+"(?1,?0)";
				}

				String secondProperty =clsA.get(1).toString();
				String secondStep1 = Arrays.asList(secondProperty.split("<")).get(1);
				if(!secondProperty.contains("Inverse")){							
					secondAtom += Arrays.asList(secondStep1.split(">")).get(0)+"(?0,?1)";
				}
				else{
					secondAtom += Arrays.asList(secondStep1.split(">")).get(0)+"(?1,?0)";
				}
				
				query+=firstAtom+secondAtom;
				queriesStrings2Axioms.put(query,a);
			}
		}
		return queriesStrings2Axioms;
	}


	
	

}
/* Copyright 2016, 2017 by the National Technical University of Athens.

This file is part of SaQAI.

SaQAI is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SaQAI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
*/

package org.semanticweb.SaQAI.dlReasoning;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.semanticweb.hydrowl.queryAnswering.RewritingBasedQueryEvaluator;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import java.util.HashMap;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLDisjointObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.model.OWLSubObjectPropertyOfAxiom;

public class CreateDisjointnessMapping {
	
		//1. break the "ObjectUnionOf" on the rhs of the OWLAxiom:
		//2. If Disjoint(A, B) find all subclasses/ subproperties of A
	public static ArrayList<Map<String, Set<String>>> createDisjointnessMapping (OWLOntology ontology,OWLOntologyManager manager,HashSet<OWLAxiom> skipDisjProp, Boolean refMin, String dataset, RewritingBasedQueryEvaluator hybridQA)throws Exception{
		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
		allAxioms.addAll(ontology.getAxioms());
		OWLDataFactory factory = manager.getOWLDataFactory();
		
		HashSet<OWLAxiom> normalizedAllAxioms = new HashSet<OWLAxiom>();
		normalizedAllAxioms.addAll(BasicReasoning.normalizeOWLPositiveInclusions(ontology,factory));

		HashSet<OWLAxiom> impliedAxioms = new HashSet<OWLAxiom>();
		impliedAxioms.addAll(BasicReasoning.reasoningOnDisjProperties(normalizedAllAxioms, factory, skipDisjProp));
		
		HashSet<OWLAxiom> impliedAndNormalizedAxioms = new HashSet<OWLAxiom>();
		impliedAndNormalizedAxioms.addAll(impliedAxioms);
		impliedAndNormalizedAxioms.addAll(normalizedAllAxioms);
		
		ArrayList<Map<String, Set<String>>> disjMap =  disjMapsOfPropertiesAndClasses( impliedAndNormalizedAxioms,  factory,skipDisjProp, refMin, dataset, hybridQA);
		return disjMap;
	}
	
	public static ArrayList<Map<String, Set<String>>> createDisjointnessMapping(OWLOntology ontology,OWLOntologyManager manager,Boolean refMin,String dataset) throws Exception{
		//1. normalize all OWLAxioms:
		//2. If Disjoint(A, B) find all subclasses/ subproperties of A

		HashSet<OWLAxiom> allAxioms = new HashSet<OWLAxiom>();
		allAxioms.addAll(ontology.getAxioms());
		OWLDataFactory factory = manager.getOWLDataFactory();
		
		HashSet<OWLAxiom> normalizedAllAxioms = new HashSet<OWLAxiom>();
		normalizedAllAxioms.addAll(BasicReasoning.normalizeOWLPositiveInclusions(ontology,factory));

		HashSet<OWLAxiom> impliedAxioms = new HashSet<OWLAxiom>();
		impliedAxioms.addAll(BasicReasoning.reasoningOnDisjProperties(normalizedAllAxioms, factory));
		
		HashSet<OWLAxiom> impliedAndNormalizedAxioms = new HashSet<OWLAxiom>();
		impliedAndNormalizedAxioms.addAll(impliedAxioms);
		impliedAndNormalizedAxioms.addAll(normalizedAllAxioms);
		
		ArrayList<Map<String, Set<String>>> disjMap =  disjMapsOfPropertiesAndClasses( impliedAndNormalizedAxioms,  factory, refMin, dataset);
		
		return disjMap;
	}
	
private static ArrayList<Map<String, Set<String>>> disjMapsOfPropertiesAndClasses( Set<OWLAxiom> axioms, OWLDataFactory factory, HashSet<OWLAxiom> skipDisjProp, Boolean refMin, String dataset ,RewritingBasedQueryEvaluator hybridQA)throws Exception{
	Map<String, Set<String>> subclass_map = new HashMap<String, Set<String>>();
	Map<String, Set<String>> subprop_map = new HashMap<String, Set<String>>();
	Map<String, Set<String>> disjointClass_map = new HashMap<String, Set<String>>();
	Set< OWLSubClassOfAxiom> subclassAxioms = new HashSet< OWLSubClassOfAxiom>();
	Set< OWLSubObjectPropertyOfAxiom> subpropertyAxioms = new HashSet< OWLSubObjectPropertyOfAxiom>();
	Map<String, Set<String>> disjointProp_map = new HashMap<String, Set<String>>();
	Set<String> guarded = new HashSet<String>();
	Set<String> inconsistentC = new HashSet<String>();
	Set<String> inconsistentP = new HashSet<String>();
	
	for(OWLAxiom a : axioms){
		if(a instanceof OWLSubClassOfAxiom){
			subclassAxioms.add(( OWLSubClassOfAxiom)a);
		}
		if(a instanceof OWLSubObjectPropertyOfAxiom){
			subpropertyAxioms.add((OWLSubObjectPropertyOfAxiom)a);
		}
	}

	for(OWLAxiom a : axioms){		
		if(a instanceof OWLDisjointClassesAxiom ) {					
			Set<OWLClassExpression> cls = ((OWLDisjointClassesAxiom)a).getClassExpressions();		
			ArrayList<OWLClassExpression> clsA= new ArrayList<OWLClassExpression>();
			clsA.addAll(cls);				
			for( OWLSubClassOfAxiom s : subclassAxioms){
				BasicReasoning.findAllSubclasses(clsA.get(0), subclass_map, subclassAxioms, s);
				BasicReasoning.findAllSubclasses(clsA.get(1), subclass_map, subclassAxioms, s);
			}
		}
		if(a instanceof OWLDisjointObjectPropertiesAxiom ){
			if(!skipDisjProp.contains(a)){
			//	System.out.println(">>"+a);
				Set<OWLObjectPropertyExpression> prop = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();		
				ArrayList<OWLObjectPropertyExpression> propA= new ArrayList<OWLObjectPropertyExpression>();
				propA.addAll(prop);				
				for( OWLSubObjectPropertyOfAxiom s : subpropertyAxioms){
					BasicReasoning.findAllSubProperties(propA.get(0), subprop_map, subpropertyAxioms, s);
					BasicReasoning.findAllSubProperties(propA.get(1), subprop_map, subpropertyAxioms, s);
				}
			}
		}
	}
	
	for(OWLAxiom a : axioms){		
		if(a instanceof OWLDisjointClassesAxiom){					
			Set<OWLClassExpression> cls = ((OWLDisjointClassesAxiom)a).getClassExpressions();		
			ArrayList<OWLClassExpression> clsA= new ArrayList<OWLClassExpression>();
			clsA.addAll(cls);
	
			//add to disjointness map: 1. clsA.get0 and all its disjoint classes 2. its children with all their disjoint classes:
			addAllDisjointElementsOfElement_X_ToMap(clsA.get(0).toString(), clsA.get(1).toString(), subclass_map, disjointClass_map, refMin, guarded, inconsistentC);				
			//add to disjointness map: 1. clsA.get1 and all its disjoint classes 2. its children with all their disjoint classes
			addAllDisjointElementsOfElement_X_ToMap(clsA.get(1).toString(), clsA.get(0).toString(), subclass_map, disjointClass_map, refMin, guarded, inconsistentC);	
		}
		
			
		if(a instanceof OWLDisjointObjectPropertiesAxiom){					
		//	System.out.println(">>"+a);
			if(!skipDisjProp.contains(a)){
				Set<OWLObjectPropertyExpression> prop = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();		
				ArrayList<OWLObjectPropertyExpression> propA= new ArrayList<OWLObjectPropertyExpression>();
				propA.addAll(prop);
		
				addAllDisjointElementsOfElement_X_ToMap(propA.get(0).toString(), propA.get(1).toString(), subprop_map, disjointProp_map, refMin,guarded, inconsistentP);				
				addAllDisjointElementsOfElement_X_ToMap(propA.get(1).toString(), propA.get(0).toString(), subprop_map, disjointProp_map, refMin,guarded, inconsistentP);	
			}
		}
	}
	ArrayList<Map<String, Set<String>>> disjointness_maps = new ArrayList<Map<String, Set<String>>>();
	disjointness_maps.add(disjointClass_map);
	disjointness_maps.add(disjointProp_map);

	return disjointness_maps;
}

private static ArrayList<Map<String, Set<String>>> disjMapsOfPropertiesAndClasses( Set<OWLAxiom> axioms, OWLDataFactory factory,Boolean refMin,String dataset) throws Exception{
	Map<String, Set<String>> subclass_map = new HashMap<String, Set<String>>();
	Map<String, Set<String>> subprop_map = new HashMap<String, Set<String>>();
	Map<String, Set<String>> disjointClass_map = new HashMap<String, Set<String>>();
	Set< OWLSubClassOfAxiom> subclassAxioms = new HashSet< OWLSubClassOfAxiom>();
	Set< OWLSubObjectPropertyOfAxiom> subpropertyAxioms = new HashSet< OWLSubObjectPropertyOfAxiom>();
	Map<String, Set<String>> disjointProp_map = new HashMap<String, Set<String>>();
	Set<String> guarded = new HashSet<String>();
	Set<String> inconsistentC = new HashSet<String>();
	Set<String> inconsistentP = new HashSet<String>();
	
	for(OWLAxiom a : axioms){
		if(a instanceof OWLSubClassOfAxiom){
			subclassAxioms.add(( OWLSubClassOfAxiom)a);
		}
		if(a instanceof OWLSubObjectPropertyOfAxiom){
			subpropertyAxioms.add((OWLSubObjectPropertyOfAxiom)a);
		}
	}

	for(OWLAxiom a : axioms){		
		if(a instanceof OWLDisjointClassesAxiom ) {					
			Set<OWLClassExpression> cls = ((OWLDisjointClassesAxiom)a).getClassExpressions();		
			ArrayList<OWLClassExpression> clsA= new ArrayList<OWLClassExpression>();
			clsA.addAll(cls);				
			for( OWLSubClassOfAxiom s : subclassAxioms){
				BasicReasoning.findAllSubclasses(clsA.get(0), subclass_map, subclassAxioms, s);
				BasicReasoning.findAllSubclasses(clsA.get(1), subclass_map, subclassAxioms, s);
			}
		}
		if(a instanceof OWLDisjointObjectPropertiesAxiom ){	
			Set<OWLObjectPropertyExpression> prop = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();		
			ArrayList<OWLObjectPropertyExpression> propA= new ArrayList<OWLObjectPropertyExpression>();
			propA.addAll(prop);				
			for( OWLSubObjectPropertyOfAxiom s : subpropertyAxioms){
				BasicReasoning.findAllSubProperties(propA.get(0), subprop_map, subpropertyAxioms, s);
				BasicReasoning.findAllSubProperties(propA.get(1), subprop_map, subpropertyAxioms, s);
			}
		}
	}
	
	for(OWLAxiom a : axioms){		
		if(a instanceof OWLDisjointClassesAxiom){					
			Set<OWLClassExpression> cls = ((OWLDisjointClassesAxiom)a).getClassExpressions();		
			ArrayList<OWLClassExpression> clsA= new ArrayList<OWLClassExpression>();
			clsA.addAll(cls);
	
			//add to disjointness map: 1. clsA.get0 and all its disjoint classes 2. its children with all their disjoint classes:
			addAllDisjointElementsOfElement_X_ToMap(clsA.get(0).toString(), clsA.get(1).toString(), subclass_map, disjointClass_map, refMin, guarded, inconsistentC);				
			//add to disjointness map: 1. clsA.get1 and all its disjoint classes 2. its children with all their disjoint classes
			addAllDisjointElementsOfElement_X_ToMap(clsA.get(1).toString(), clsA.get(0).toString(), subclass_map, disjointClass_map,refMin, guarded, inconsistentC);	
		}
		
			
		if(a instanceof OWLDisjointObjectPropertiesAxiom){					
			Set<OWLObjectPropertyExpression> prop = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();		
			ArrayList<OWLObjectPropertyExpression> propA= new ArrayList<OWLObjectPropertyExpression>();
			propA.addAll(prop);
	
			addAllDisjointElementsOfElement_X_ToMap(propA.get(0).toString(), propA.get(1).toString(), subprop_map, disjointProp_map,refMin, guarded, inconsistentP);				
			addAllDisjointElementsOfElement_X_ToMap(propA.get(1).toString(), propA.get(0).toString(), subprop_map, disjointProp_map,refMin, guarded, inconsistentP);	
		}
	}
	ArrayList<Map<String, Set<String>>> disjointness_maps = new ArrayList<Map<String, Set<String>>>();
	disjointness_maps.add(disjointClass_map);
	disjointness_maps.add(disjointProp_map);

return disjointness_maps;
}





private static void addAllDisjointElementsOfElement_X_ToMap(String x, String y, Map<String, Set<String>> subclass_map,Map<String, Set<String>> disjointness_map, Boolean refMin, Set<String> guarded, Set<String> inconsistent){
 
	if(!disjointness_map.keySet().contains(x)){
		Set<String> tempsbcls1 = new HashSet<String>();
		tempsbcls1.add(y);
		disjointness_map.put(x, tempsbcls1 );
	}
	else{
		disjointness_map.get(x).add(y);		
	}		
	
	if(subclass_map.keySet().contains(y)){
		Set<String> subclassesOfy = new HashSet<String>();
		subclassesOfy.addAll(subclass_map.get(y));
		if(!refMin){
			disjointness_map.get(x).addAll(subclassesOfy); 
		}
	} 
	
	if(subclass_map.keySet().contains(x)){
		for(String sbclass: subclass_map.get(x)){
			if(disjointness_map.keySet().contains(sbclass)){			
				disjointness_map.get(sbclass).add(y);
				if(subclass_map.keySet().contains(y)){
					Set<String> subclassesOfy = new HashSet<String>();
					subclassesOfy.addAll(subclass_map.get(y));
					if(!refMin){
						disjointness_map.get(sbclass).addAll(subclassesOfy);
					}
				}
			}
			else{
				Set<String> tempsbcls1 = new HashSet<String>();
				tempsbcls1.add(y);
				disjointness_map.put(sbclass,tempsbcls1);
				if(subclass_map.keySet().contains(y)){
					Set<String> subclassesOfy = new HashSet<String>();
					subclassesOfy.addAll(subclass_map.get(y));
					if(!refMin){
						disjointness_map.get(sbclass).addAll( subclassesOfy);
						}
				}
			}
		}
	}
}


}

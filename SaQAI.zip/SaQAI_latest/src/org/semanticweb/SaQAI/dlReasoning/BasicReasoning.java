/* Copyright 2016, 2017 by the National Technical University of Athens.

This file is part of SaQAI.

SaQAI is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SaQAI is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with SaQAI. If not, see <http://www.gnu.org/licenses/>.
*/

package org.semanticweb.SaQAI.dlReasoning;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLDisjointObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLInverseObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLLogicalAxiom;
import org.semanticweb.owlapi.model.OWLObjectComplementOf;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectUnionOf;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.model.OWLSubObjectPropertyOfAxiom;
import org.semanticweb.owlapi.model.OWLSymmetricObjectPropertyAxiom;

public class BasicReasoning {

	public static Set<OWLAxiom> reasoningOnDisjProperties(Set<OWLAxiom> axioms, OWLDataFactory factory){
		Set<OWLAxiom> newAxioms = new HashSet<OWLAxiom>(); 
		Set<OWLAxiom> impliedAxioms = new HashSet<OWLAxiom>(); 
		
		for(OWLAxiom a: axioms){	
				if(a instanceof OWLDisjointObjectPropertiesAxiom){						
					Set<OWLObjectPropertyExpression> properties = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();
					ArrayList<OWLObjectPropertyExpression> propA =new ArrayList<OWLObjectPropertyExpression>();
					propA.addAll(properties);	
					//if P<\not R  create also   P- <\not R- 	
					if(!propA.get(0).toString().contains("InverseOf")&&!propA.get(1).toString().contains("InverseOf")){ 
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(propA.get(0).getInverseProperty(), propA.get(1).getInverseProperty()));
					}
					//if P<\not R-  create also    P- <\not R 	
					if(!propA.get(0).toString().contains("InverseOf")&&propA.get(1).toString().contains("InverseOf")){
						ArrayList<OWLObjectPropertyExpression> noninvpropA =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA.addAll(propA.get(1).getObjectPropertiesInSignature());
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(propA.get(0).getInverseProperty(), noninvpropA.get(0)));
					}
					//if P-<\not R  create also   P <\not R- 	
					if(propA.get(0).toString().contains("InverseOf")&&!propA.get(1).toString().contains("InverseOf")){
						ArrayList<OWLObjectPropertyExpression> noninvpropA =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA.addAll(propA.get(0).getObjectPropertiesInSignature());
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(noninvpropA.get(0), propA.get(1).getInverseProperty()));
					}
					//if P-<\not R-  create also    P <\not R 	
					if(propA.get(0).toString().contains("InverseOf")&&propA.get(1).toString().contains("InverseOf")){
						ArrayList<OWLObjectPropertyExpression> noninvpropA0 =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA0.addAll(propA.get(0).getObjectPropertiesInSignature());
						ArrayList<OWLObjectPropertyExpression> noninvpropA1 =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA1.addAll(propA.get(1).getObjectPropertiesInSignature());
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(noninvpropA0.get(0), noninvpropA1.get(0)));
					}
				}
			
		}
		impliedAxioms.addAll(newAxioms);
		return impliedAxioms;
	}
	public static Set<OWLAxiom> reasoningOnDisjProperties(Set<OWLAxiom> axioms, OWLDataFactory factory,HashSet<OWLAxiom> skipDisjProp ){
		Set<OWLAxiom> newAxioms = new HashSet<OWLAxiom>(); 
		Set<OWLAxiom> impliedAxioms = new HashSet<OWLAxiom>(); 
		
		for(OWLAxiom a: axioms){
			if(!skipDisjProp.contains(a)){
				if(a instanceof OWLDisjointObjectPropertiesAxiom){						
					Set<OWLObjectPropertyExpression> properties = ((OWLDisjointObjectPropertiesAxiom)a).getProperties();
					ArrayList<OWLObjectPropertyExpression> propA =new ArrayList<OWLObjectPropertyExpression>();
					propA.addAll(properties);	
					//if P<\not R  create also   P- <\not R- 	
					if(!propA.get(0).toString().contains("InverseOf")&&!propA.get(1).toString().contains("InverseOf")){ 
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(propA.get(0).getInverseProperty(), propA.get(1).getInverseProperty()));
					}
					//if P<\not R-  create also    P- <\not R 	
					if(!propA.get(0).toString().contains("InverseOf")&&propA.get(1).toString().contains("InverseOf")){
						ArrayList<OWLObjectPropertyExpression> noninvpropA =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA.addAll(propA.get(1).getObjectPropertiesInSignature());
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(propA.get(0).getInverseProperty(), noninvpropA.get(0)));
					}
					//if P-<\not R  create also   P <\not R- 	
					if(propA.get(0).toString().contains("InverseOf")&&!propA.get(1).toString().contains("InverseOf")){
						ArrayList<OWLObjectPropertyExpression> noninvpropA =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA.addAll(propA.get(0).getObjectPropertiesInSignature());
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(noninvpropA.get(0), propA.get(1).getInverseProperty()));
					}
					//if P-<\not R-  create also    P <\not R 	
					if(propA.get(0).toString().contains("InverseOf")&&propA.get(1).toString().contains("InverseOf")){
						ArrayList<OWLObjectPropertyExpression> noninvpropA0 =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA0.addAll(propA.get(0).getObjectPropertiesInSignature());
						ArrayList<OWLObjectPropertyExpression> noninvpropA1 =new ArrayList<OWLObjectPropertyExpression>();
						noninvpropA1.addAll(propA.get(1).getObjectPropertiesInSignature());
						newAxioms.add(factory.getOWLDisjointObjectPropertiesAxiom(noninvpropA0.get(0), noninvpropA1.get(0)));
					}
				}
			}
			
		}
		impliedAxioms.addAll(newAxioms);
		return impliedAxioms;
	}

	public static void findAllSubclasses(OWLClassExpression owlClassExpression,Map<String, Set<String>> map, Set< OWLSubClassOfAxiom> subclassAxioms,OWLSubClassOfAxiom s){
		
		Stack<OWLClassExpression> subclasses_stack = new Stack<OWLClassExpression>();  			
		Set< OWLClassExpression> addedClassInStack = new HashSet< OWLClassExpression>();
		
			if(s.getSuperClass().equals(owlClassExpression)){ 
				OWLClassExpression sbc = s.getSubClass();
				subclasses_stack.push(sbc);						
				addedClassInStack.add(sbc);
				while (!subclasses_stack.isEmpty()){
					OWLClassExpression subClass = subclasses_stack.pop();
					if(!map.keySet().contains(owlClassExpression.toString())){
						Set<String> tempsbcls1 = new HashSet<String>();
						tempsbcls1.add(subClass.toString());
						map.put(owlClassExpression.toString(), tempsbcls1);
					}
					else{
						map.get(owlClassExpression.toString()).add(subClass.toString());
					}								
					for( OWLSubClassOfAxiom d : subclassAxioms){
							if(d.getSuperClass().equals(subClass)){
								OWLClassExpression sb_c = d.getSubClass();
								if(!addedClassInStack.contains(sb_c)){
									subclasses_stack.push(sb_c);
									addedClassInStack.add(sb_c);
								}
							}
						}
					}							
				}
	}

	public static void findAllSubProperties(OWLObjectPropertyExpression property, Map<String, Set<String>> map, Set< OWLSubObjectPropertyOfAxiom> subpropAxioms,OWLSubObjectPropertyOfAxiom s){
		
		Stack<OWLObjectPropertyExpression> subprop_stack = new Stack<OWLObjectPropertyExpression>();  
		Set< OWLObjectPropertyExpression> addedPropInStack = new HashSet< OWLObjectPropertyExpression>();
		
		if(s.getSuperProperty().equals(property)){ 
			OWLObjectPropertyExpression sbc = s.getSubProperty();
			subprop_stack.push(sbc);						
			addedPropInStack.add(sbc);
			while (!subprop_stack.isEmpty()){
				OWLObjectPropertyExpression subprop = subprop_stack.pop();
				if(!map.keySet().contains(property.toString())){
					Set<String> tempsbcls1 = new HashSet<String>();
					tempsbcls1.add(subprop.toString());
					map.put(property.toString(), tempsbcls1);
				}
				else{
					map.get(property.toString()).add(subprop.toString());
				}								
				for( OWLSubObjectPropertyOfAxiom d : subpropAxioms){
						if(d.getSuperProperty().equals(subprop)){
							OWLObjectPropertyExpression sb_c = d.getSubProperty();
							if(!addedPropInStack.contains(sb_c)){
								subprop_stack.push(sb_c);
								addedPropInStack.add(sb_c);
							}
						}
					}
				}							
			}	
		
	}

	public static Set<OWLAxiom> normalizeOWLPositiveInclusions(OWLOntology ontology, OWLDataFactory factory){
		
		Set<OWLAxiom> discardAxioms = new HashSet<OWLAxiom>(); 
		Set<OWLAxiom> normalizedOnto = new HashSet<OWLAxiom>(); 
		Set<OWLLogicalAxiom> axioms = ontology.getLogicalAxioms();
		Stack<OWLAxiom> axiomStack = new Stack<OWLAxiom>();
	
		for (OWLAxiom ax : axioms) {
			axiomStack.push(ax);
		}
		int number=0;
		while(!axiomStack.isEmpty()){
			boolean b =false;
			OWLAxiom a =axiomStack.pop();
	
			if (a instanceof OWLSubClassOfAxiom) {
				OWLClassExpression subClass = ((OWLSubClassOfAxiom)a).getSubClass();
				OWLClassExpression supClass = ((OWLSubClassOfAxiom)a).getSuperClass();
				if (supClass.isOWLThing() || subClass.isOWLNothing()) {
				} 
				
				else if (supClass instanceof OWLObjectComplementOf) {
						OWLClassExpression ex = ((OWLObjectComplementOf)supClass).getOperand();
						axiomStack.push(factory.getOWLDisjointClassesAxiom(subClass,ex));
						b=true;
				}
				else if (supClass instanceof OWLObjectIntersectionOf) {
					for (OWLClassExpression ex : ((OWLObjectIntersectionOf)supClass).getOperands()) {
						axiomStack.push(factory.getOWLSubClassOfAxiom(subClass, ex));
						b=true;
					}
				} else if (supClass instanceof OWLObjectSomeValuesFrom) {
					OWLObjectSomeValuesFrom cDescr = (OWLObjectSomeValuesFrom)supClass;
					OWLObjectPropertyExpression supProp = cDescr.getProperty();
					OWLClassExpression filler = cDescr.getFiller();
					String prefix = ontology.getOntologyID().getOntologyIRI() + "#";
					if (!filler.isOWLThing()) { //CGLLR TRANSFORMATION:
						OWLObjectProperty property = factory.getOWLObjectProperty(IRI.create(prefix+"P_5000"+number));
					 	axiomStack.push(factory.getOWLSubClassOfAxiom(subClass,factory.getOWLObjectSomeValuesFrom(property, factory.getOWLThing())));
					 	axiomStack.push(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(property.getInverseProperty(),factory.getOWLThing()),filler));
						axiomStack.push(factory.getOWLSubObjectPropertyOfAxiom(property, supProp));
						b=true;
						number++;
					}
				}
				if (subClass instanceof OWLObjectUnionOf) {
					for (OWLClassExpression ex : ((OWLObjectUnionOf)subClass).getOperands()) {
						axiomStack.push(factory.getOWLSubClassOfAxiom(ex, supClass));
						b=true;
					}
				}				
			}
			if (a instanceof OWLDisjointClassesAxiom) {
				Set<OWLClassExpression> cls = ((OWLDisjointClassesAxiom)a).getClassExpressions();
				ArrayList<OWLClassExpression> clsA = new ArrayList<OWLClassExpression>();
				clsA.addAll(cls);
				if(clsA.get(1) instanceof OWLObjectUnionOf) {
					for(OWLClassExpression op : ((OWLObjectUnionOf) clsA.get(1)).getOperands()){
						axiomStack.push(factory.getOWLDisjointClassesAxiom(clsA.get(0), op));
						b=true;
					}
				}  
				if ((clsA.get(0) instanceof OWLObjectUnionOf)) {
					for(OWLClassExpression op : ((OWLObjectUnionOf) clsA.get(0)).getOperands()){
						axiomStack.push(factory.getOWLDisjointClassesAxiom(clsA.get(1), op));
						b=true;
					}
				}
				if((clsA.get(0) instanceof OWLObjectSomeValuesFrom)) {
					OWLObjectSomeValuesFrom cDescr = (OWLObjectSomeValuesFrom)clsA.get(0);
					OWLObjectPropertyExpression supProp = cDescr.getProperty();
					OWLClassExpression filler = cDescr.getFiller();
					if(filler instanceof OWLObjectUnionOf ){
						for(OWLClassExpression op : ((OWLObjectUnionOf) filler).getOperands()){
							axiomStack.push(factory.getOWLDisjointClassesAxiom(clsA.get(1), factory.getOWLObjectSomeValuesFrom(supProp,op)));
							b=true;
						}
					}
				} 
				if((clsA.get(1) instanceof OWLObjectSomeValuesFrom)) {
					OWLObjectSomeValuesFrom cDescr = (OWLObjectSomeValuesFrom)clsA.get(1);
					OWLObjectPropertyExpression supProp = cDescr.getProperty();
					OWLClassExpression filler = cDescr.getFiller();
					if(filler instanceof OWLObjectUnionOf ){
						for(OWLClassExpression op : ((OWLObjectUnionOf) filler).getOperands()){
							axiomStack.push(factory.getOWLDisjointClassesAxiom(clsA.get(0), factory.getOWLObjectSomeValuesFrom(supProp,op)));
							b=true;
						}
					}
				} 
				
			}
		
			else if(a instanceof OWLSubObjectPropertyOfAxiom){
				OWLObjectPropertyExpression subProperty = ((OWLSubObjectPropertyOfAxiom)a).getSubProperty();
				OWLObjectPropertyExpression supProperty = ((OWLSubObjectPropertyOfAxiom)a).getSuperProperty();
				if (supProperty instanceof OWLObjectIntersectionOf) {
					for (OWLObjectPropertyExpression ex : ((OWLObjectIntersectionOf)supProperty).getObjectPropertiesInSignature()) {
						axiomStack.push(factory.getOWLSubObjectPropertyOfAxiom(subProperty, ex));
						b=true;
					}
					
				}
				 if (subProperty instanceof OWLObjectUnionOf) {
					for (OWLObjectPropertyExpression ex : ((OWLObjectUnionOf)subProperty).getObjectPropertiesInSignature()) {
						axiomStack.push(factory.getOWLSubObjectPropertyOfAxiom(ex, supProperty));
						b=true;
					}
				}
				 else if(!(supProperty instanceof OWLObjectIntersectionOf)){
					 if(!normalizedOnto.contains(a)){//if P<R create also \existsP < \existsR 
						 axiomStack.add(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(subProperty, factory.getOWLThing()), factory.getOWLObjectSomeValuesFrom(supProperty, factory.getOWLThing())));
						//System.out.println(i+ ": " + a ); //if P<R  create also  \exists P- < \exists R-,  P- < R- 	
						if(!subProperty.toString().contains("InverseOf")&&!supProperty.toString().contains("InverseOf")){ 
							axiomStack.add(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(subProperty.getInverseProperty(), factory.getOWLThing()), factory.getOWLObjectSomeValuesFrom(supProperty.getInverseProperty(), factory.getOWLThing())));
							axiomStack.add(factory.getOWLSubObjectPropertyOfAxiom(subProperty.getInverseProperty(), supProperty.getInverseProperty()));
						}
						//if P<R-  create also  \exists P- < \exists R,  P- < R 	
						if(!subProperty.toString().contains("InverseOf")&&supProperty.toString().contains("InverseOf")){
							ArrayList<OWLObjectPropertyExpression> noninvpropA =new ArrayList<OWLObjectPropertyExpression>();
							noninvpropA.addAll(supProperty.getObjectPropertiesInSignature());
							axiomStack.add(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(subProperty.getInverseProperty(), factory.getOWLThing()), factory.getOWLObjectSomeValuesFrom(noninvpropA.get(0), factory.getOWLThing())));
							axiomStack.add(factory.getOWLSubObjectPropertyOfAxiom(subProperty.getInverseProperty(), noninvpropA.get(0)));
						}
						//if P-<R  create also  \exists P< \exists R-,  P < R- 	
						if(subProperty.toString().contains("InverseOf")&&!supProperty.toString().contains("InverseOf")){
							ArrayList<OWLObjectPropertyExpression> noninvpropA =new ArrayList<OWLObjectPropertyExpression>();
							noninvpropA.addAll(subProperty.getObjectPropertiesInSignature());
							axiomStack.add(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(noninvpropA.get(0), factory.getOWLThing()), factory.getOWLObjectSomeValuesFrom(supProperty.getInverseProperty(), factory.getOWLThing())));
							axiomStack.add(factory.getOWLSubObjectPropertyOfAxiom(noninvpropA.get(0), supProperty.getInverseProperty()));
						}
						//if P-<R-  create also  \exists P < \exists R,  P < R 	
						if(subProperty.toString().contains("InverseOf")&&supProperty.toString().contains("InverseOf")){
							ArrayList<OWLObjectPropertyExpression> noninvpropA0 =new ArrayList<OWLObjectPropertyExpression>();
							noninvpropA0.addAll(subProperty.getObjectPropertiesInSignature());
							ArrayList<OWLObjectPropertyExpression> noninvpropA1 =new ArrayList<OWLObjectPropertyExpression>();
							noninvpropA1.addAll(supProperty.getObjectPropertiesInSignature());
							axiomStack.add(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(noninvpropA0.get(0), factory.getOWLThing()),  factory.getOWLObjectSomeValuesFrom(noninvpropA1.get(0), factory.getOWLThing())));
							axiomStack.add(factory.getOWLSubObjectPropertyOfAxiom(noninvpropA0.get(0), noninvpropA1.get(0)));
						}	 
					}
				 }
			}
			else if (a instanceof OWLEquivalentObjectPropertiesAxiom) {
				for (OWLSubObjectPropertyOfAxiom ax : ((OWLEquivalentObjectPropertiesAxiom)a).asSubObjectPropertyOfAxioms()) {
					axiomStack.push(ax);
					b=true;
				}
			}
					
			 else if (a instanceof OWLObjectPropertyDomainAxiom) {
				OWLObjectPropertyExpression prop = ((OWLObjectPropertyDomainAxiom)a).getProperty();
				OWLClassExpression domain = ((OWLObjectPropertyDomainAxiom)a).getDomain();
				
				axiomStack.push(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(prop, factory.getOWLThing()), domain));
				b=true;
			} 
			 
			 else if (a instanceof OWLObjectPropertyRangeAxiom) {
				OWLObjectPropertyExpression prop = ((OWLObjectPropertyRangeAxiom)a).getProperty();
				OWLClassExpression range = ((OWLObjectPropertyRangeAxiom)a).getRange();
	
				axiomStack.push(factory.getOWLSubClassOfAxiom(factory.getOWLObjectSomeValuesFrom(prop.getInverseProperty(), factory.getOWLThing()), range));
				b=true;
			} 
			else if (a instanceof OWLSymmetricObjectPropertyAxiom) {
				
				for (OWLSubObjectPropertyOfAxiom ax : ((OWLSymmetricObjectPropertyAxiom)a).asSubPropertyAxioms()) {
					axiomStack.push(ax);
					b=true;
				}
			}
			
			else if (a instanceof OWLInverseObjectPropertiesAxiom) {
				OWLObjectProperty first = ((OWLInverseObjectPropertiesAxiom)a).getFirstProperty().asOWLObjectProperty();
				OWLObjectProperty second = ((OWLInverseObjectPropertiesAxiom)a).getSecondProperty().asOWLObjectProperty();
				axiomStack.push(factory.getOWLEquivalentObjectPropertiesAxiom(first, factory.getOWLObjectInverseOf(second)));
				b=true;
			}
			
			if (a instanceof OWLEquivalentClassesAxiom) {
				for (OWLSubClassOfAxiom ax : ((OWLEquivalentClassesAxiom)a).asOWLSubClassOfAxioms()) {
					axiomStack.push(ax);
					b=true;
				}
			}
			if(!b){
				normalizedOnto.add(a);
			}
		}
		return normalizedOnto;
	}

}

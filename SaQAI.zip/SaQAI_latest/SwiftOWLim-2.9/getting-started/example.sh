foo=$PWD
cd ..
source setvars.sh
cd $foo
$JAVA_HOME/bin/java -Xmx256m -cp "$CP_TESTS:bin" GettingStarted

VER=2.9.1
JAVA_HOME="$HOME/jdk6-64"
JAVA_TOOLS_JAR=$JAVA_HOME/lib/tools.jar
TRREE_JAR=trree-$VER.jar
OWLIM_JAR=owlim-$VER.jar
SESAME_LIB="$PWD/ext"
SESAME_JAR=$SESAME_LIB/rio.jar:$SESAME_LIB/openrdf-model.jar:$SESAME_LIB/openrdf-util.jar:$SESAME_LIB/sesame.jar
CP_TESTS="$PWD/lib/$TRREE_JAR:$PWD/lib/$OWLIM_JAR:$PWD/bin:$PWD/ext/lubm.jar:$SESAME_JAR:$JAVA_TOOLS_JAR"

/*
 OWLIM - a SAIL implementation with OWL inference for Sesame (www.openrdf.org)
  
 Copyright (c) 2004-2005, OntoText Lab. / SIRMA

 This library is free software; you can redistribute it and/or modify it under
 the terms of the GNU Lesser General Public License as published by the Free
 Software Foundation; either version 2.1 of the License, or (at your option)
 any later version.
 This library is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 details.
 You should have received a copy of the GNU Lesser General Public License along
 with this library; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/
package org.openrdf.sesame.sailimpl;


import java.io.*;
import java.util.*;
import java.util.zip.*;

import org.openrdf.sesame.omm.SessionContext;
import org.openrdf.sesame.sail.*;
import org.openrdf.model.*;
import org.openrdf.model.impl.*;
import org.openrdf.sesame.sail.query.Query;
import org.openrdf.rio.NamespaceListener;
import org.openrdf.rio.StatementHandler;
import org.openrdf.rio.ParseException;
import org.openrdf.util.log.ThreadLog;
import org.openrdf.rio.Parser;
import org.openrdf.rio.turtle.TurtleWriter;
import org.openrdf.rio.RdfDocumentWriter;
import org.openrdf.rio.rdfxml.RdfXmlWriter;

import com.ontotext.trree.transitivity.AbstractInferencer;
import com.ontotext.trree.transitivity.InferencerFactory;
import com.ontotext.trree.transitivity.EntityPool;
import com.ontotext.trree.transitivity.Repository;
import com.ontotext.trree.transitivity.IntSetData;
import com.ontotext.trree.transitivity.ThreadPool;
import com.ontotext.trree.transitivity.TransitiveRepository;
//import com.ontotext.trree.transitivity.NoResourceRulesHashInferencer;
import com.ontotext.trree.transitivity.StatementIdIterator;
import com.ontotext.trree.transitivity.rules.RuntimeInferencerCompiler;
import com.ontotext.trree.transitivity.IntegerContainer;

public class OWLIMSchemaRepository implements RdfSchemaRepository {

  private final static String PARAM_IMPORTS = "imports";
  private final static String PARAM_DEFAULTNS = "defaultNS";
  private final static String PARAM_DATAFORMAT = "dataFormat";
  private final static String PARAM_COMPRESSFILE = "compressFile";
  private final static String PARAM_RULESET = "ruleset";
  private final static String PARAM_MAIN_FILE = "file";
  private final static String PARAM_NEW_TRIPLES_FILE = "new-triples-file";
  private final static String PARAM_NOPERSIST = "noPersist";
  private final static String PARAM_BASE_URL = "base-URL";
  final static String PARAM_PARTIALRDFS = "partialRDFS";
  final static String PARAM_TRANS = "transitive";
  final static String PARAM_INDEX_SIZE = "indexSize";
  final static String PARAM_JOBSIZE = "jobsize";
  final static String PARAM_PERSISTCACHE = "persistcache";
  final static String IMPLICIT_ONLY = "http://www.ontotext.com/owlim#implicitOnly";
  final static int DEFAULT_JOB_SIZE = 1000;
  private final static String PARAM_FLUSH_ON_EACH = "flushOnEach";
  boolean bSafeTrans = true;
  boolean bFlushOnEach = false;
  

  private ValueFactory VFactory = new ValueFactoryImpl();

  private String Importedfilenames;
  private String ImporteddefaultNS;
  private boolean CompressFile = false;

  private Repository storage;
  private AbstractInferencer Infer;
  private EntityPool Entities = null;

  private boolean AddAsAxiom = false;

  String importedfilenames;
  String importeddefaultNS;
  String mainStorageFileName = null;
  String sNewTriplesFileName = null;
  String baseURL = null;
  boolean bNoPersist = false;
  boolean bCompressFile = false;
  String sDataFormat = null;
  private int nDebugLevel = 0; 
  {
	nDebugLevel = Integer.parseInt( System.getProperty("debug.level", "0"));  
  }
  private boolean bInRemoteContext = false;
  {
	  bInRemoteContext = Boolean.parseBoolean( System.getProperty("remote.context", "false"));  
  }
  private boolean InferStatements = true;

  ArrayList waitingToCommit = new ArrayList();
  Object persistMutex = new Object();
  boolean bInitialized = false;
  boolean bUseMultithread = false;
  boolean bTransitive = false;
  int nJobSize = 1;
  PersistThread dumper;
  public void initialize(Map map) throws SailInitializationException {
	bInitialized = false;
	int numCPU = Runtime.getRuntime().availableProcessors(); 
	if ((numCPU - 1) < 2)
		numCPU = 2;
	int numWorkers = Integer.parseInt(System.getProperty("num.threads.run", ""+numCPU));
	bUseMultithread = (numWorkers > 1); 
	
	nJobSize = DEFAULT_JOB_SIZE;
	try {
		nJobSize = Integer.parseInt((String) map.get(PARAM_JOBSIZE));
	} catch (NumberFormatException nfe) {
		
	}
	
	// initialize the entity pool using the 'indexSize' param from the map
	Entities = new EntityPool(map);	
	
	if (nJobSize == 0)
		nJobSize = DEFAULT_JOB_SIZE; // default
	
	pool = new LocalThreadPool(numWorkers, nJobSize);
	

    Importedfilenames = (String) map.get(PARAM_IMPORTS);
    ImporteddefaultNS = (String) map.get(PARAM_DEFAULTNS);
    String temp = (String) map.get(PARAM_COMPRESSFILE);
    if (temp != null && temp.trim().length() > 0)
    	CompressFile = "yes".compareToIgnoreCase(temp) == 0;

    importedfilenames = (String) map.get(PARAM_IMPORTS);
    importeddefaultNS = (String) map.get(PARAM_DEFAULTNS);

    temp = (String) map.get(PARAM_MAIN_FILE);
    if (temp == null || temp.trim().length() == 0)
    	mainStorageFileName = null;
    else
    	mainStorageFileName = temp;
    
    temp = (String) map.get(PARAM_FLUSH_ON_EACH);
    if (temp != null && temp.trim().length() > 0 && "true".equals(temp))
    	bFlushOnEach = true;
    
    sNewTriplesFileName = (String) map.get(PARAM_NEW_TRIPLES_FILE);


    temp = System.getProperty(PARAM_NOPERSIST);
    if (temp == null) {
      temp = (String) map.get(PARAM_NOPERSIST);
      if (temp == null)
        temp = "false";
    }
    bNoPersist = 0=="true".compareToIgnoreCase(temp);
    sDataFormat = (String) map.get(PARAM_DATAFORMAT);

    baseURL = System.getProperty(PARAM_BASE_URL);
    if (baseURL == null) {
      baseURL = (String) map.get(PARAM_BASE_URL);
      if (baseURL == null || baseURL.length() == 0)
        baseURL = "http://www.ontotext.com/kim/kimo.rdfs#";
    }
    
      temp = (String) map.get("debug.level");
      if (temp != null) {
    	  try {
    		  nDebugLevel = Integer.parseInt(temp);
    	  } catch (NumberFormatException nfe) {
    	  }
      }

    temp = System.getProperty(PARAM_COMPRESSFILE);
    if (temp == null) {
      temp = (String) map.get(PARAM_COMPRESSFILE);
      if (temp == null)
        temp = "no";
    }
    bCompressFile = 0 == "yes".compareToIgnoreCase(temp);

    try{

		String ruleset = (String) map.get(PARAM_RULESET);

		if (ruleset == null || ruleset.trim().length() == 0) {
                        ruleset = System.getProperty(PARAM_RULESET);
                        if (ruleset == null)
                            ruleset = "owl-horst";
		}
		String partial = (String) map.get(PARAM_PARTIALRDFS);
		if (partial == null || partial.trim().length() == 0) {
                        partial = System.getProperty(PARAM_PARTIALRDFS);
                        if (partial == null)
                            partial = "true";
                    }

		InferStatements = ruleset.toLowerCase().compareTo("empty")!=0;
		map.put(AbstractInferencer.INFER_STATEMENTS_KEY, ""+InferStatements);
		boolean bSafeStack = true; 
		
		
		String transitiveInference = (String) map.get(PARAM_TRANS);
        if (transitiveInference == null)
        	transitiveInference = System.getProperty(PARAM_TRANS);
		bTransitive = (transitiveInference!= null) && (transitiveInference.length() > 0) && "true".compareTo(transitiveInference)==0;
		if (InferStatements)
			Infer = InferencerFactory.createInferencer(ruleset, partial.toLowerCase().compareTo("false")!=0, bSafeStack, bTransitive );
		else {
			bTransitive = false;
			Infer = InferencerFactory.createInferencer("rdfs", true, bSafeStack, bTransitive );
		}

                    if (Infer == null) {
                        Infer = RuntimeInferencerCompiler.compileInferencer(ruleset, bSafeStack, partial.toLowerCase().compareTo("false")!=0, bTransitive);
                        if (Infer == null) {
                            System.err.println("Rule set '" + ruleset + "' does not match none of the precompiled rule sets, nor does it correspond to a valid existing PIE rule file");
                            throw new SailInitializationException("Unknown rule set: " + ruleset);
                        }
                    }


		int indexSize = -1;
                    temp = (String)map.get(PARAM_INDEX_SIZE);
                    if (temp == null)
                        temp = System.getProperty(PARAM_INDEX_SIZE);
                    if (temp != null) {
                        try {
                            indexSize = Integer.parseInt(temp);
                            if (indexSize < 100000)
                                indexSize = -1;
                        } catch (NumberFormatException nfe) {}
                    }
                    if(!bTransitive)
                    	storage = new Repository();
                    else
                    	storage = new TransitiveRepository();
                    
                    map.put(AbstractInferencer.REPOSITORY_KEY, storage);
                    map.put(AbstractInferencer.ENTITIY_POOL_KEY, Entities);
                    map.put(Repository.INDEX_SIZE_KEY, ""+indexSize);
                    Infer.initialize(map);

    } catch (Exception e) {
    	e.printStackTrace();
    	System.exit(1);
    }

    AddAsAxiom = true;
    doLocalInit();
    AddAsAxiom = false;

    _loadMainDataFile();
	bInitialized = true;
	dumper = new PersistThread(storage);
	dumper.start();

  }

  
  /*--------------------------------------------------------------------------
  NamespaceIterator
 --------------------------------------------------------------------------*/
private class NamespaceIteratorImpl_ implements NamespaceIterator {

    private Iterator Iter;
    private String CurrentKey;
    boolean Found = false;

    public NamespaceIteratorImpl_(Iterator iter) {
        Iter = iter;
        Found = Iter.hasNext();
    }

    public boolean hasNext() {
        return Found;
    }

    public void next() {
    	CurrentKey = (String) Iter.next();
        Found = Iter.hasNext();
    }

    public String getPrefix() {
    	int lastIndex = CurrentKey.lastIndexOf(':');
    	if (lastIndex < 0)
    		lastIndex = CurrentKey.length();
        return CurrentKey.substring(0, lastIndex);
        
    }

    public String getName() {
        return (String) Infer.getNameSpaceMapping().get(CurrentKey);
    }

    public void close() {}
}

  
  protected void doLocalInit() {
      if (Importedfilenames == null || Importedfilenames.length() == 0) {
          return;
      }
      if (ImporteddefaultNS == null || ImporteddefaultNS.length() == 0) {
          return;
      }
      StringTokenizer tokanizer = new StringTokenizer(Importedfilenames, ";", false);
      StringTokenizer tokanizerNS = new StringTokenizer(ImporteddefaultNS,
              ";", false);
      while (tokanizer.hasMoreTokens()) {
          String tok = tokanizer.nextToken().trim();
          String ns = tokanizerNS.nextToken().trim();
          _addThisOntology(tok, ns);
      }
  }

  public void _addThisOntology(String fname, String defaultNS) {
      Parser p = null;
      long startTime = System.currentTimeMillis();
      if (nDebugLevel > 0)
    	  System.out.print("_addThisOntology: " + fname + " ...");
              if (fname.endsWith(".nt")) {
                  p = new org.openrdf.rio.ntriples.NTriplesParser(getValueFactory());
              } else {
                  p = new org.openrdf.rio.rdfxml.RdfXmlParser(getValueFactory());
              }

      try {
          startTransaction();
          p.setStopAtFirstError(true);
          
          p.setNamespaceListener(new NamespaceListener() {

			public void handleNamespace(String prefix, String uri) {
				// TODO Auto-generated method stub
				try {
					changeNamespacePrefix(uri, prefix);
				} catch (SailUpdateException sue) {
					sue.printStackTrace();
				}
			}
        	  
          });
          
          p.setStatementHandler(new StatementHandler() {
              public void handleStatement(Resource subject, URI predicate,
                                          Value object) {
                  try {
                      addStatement(subject, predicate, object);
                  } catch (SailUpdateException sue) {
                      sue.printStackTrace();
                  }
              }
          });
          Reader theFileReader;
          if (CompressFile /*&& (0== fname.compareTo(MainStorageFileName))*/) {
              try {
                      theFileReader = new InputStreamReader(new GZIPInputStream(new FileInputStream(new File(fname))));
              } catch (Exception e) {
                  theFileReader = new FileReader(fname);
              }
          }
          else
              theFileReader = new FileReader(fname);
          BufferedReader bufReader = new BufferedReader(theFileReader, 1024 * 1024);
          try {
              p.parse(bufReader, defaultNS);
          } catch (ParseException pe) {
              pe.printStackTrace();
              ThreadLog.error("PE:" + fname + "[" + pe.getLineNumber() + "," +
                              pe.getColumnNumber() + "]", pe);
          } finally {
              theFileReader.close();
          }
      } catch (Exception e) {
          e.printStackTrace();
          ThreadLog.error("in import of " + fname, e);
      } finally {
          commitTransaction();
          if (nDebugLevel > 0)
        	  System.out.println(" processed for " + (System.currentTimeMillis()- startTime)+"ms");
      }
  }

  private boolean TransactionStarted = false;

  private int NumberOfStatementsInlastTransaction = 0;

  private class MethodLockMT {
		
		Object _accessMutex = new Object();
		Object _lockingContext = null;
		
		protected boolean checkLockAccess() {
			synchronized (_accessMutex) {
				if (_lockingContext != null && 
						_lockingContext.equals(SessionContext.getContext()))
					return true;
			}
			return false;
		}
		
		protected void _lock() {
			synchronized (_accessMutex) {
				while(_lockingContext != null) {
					try {
						_accessMutex.wait();
					} catch (InterruptedException ie) {}
				}
				_lockingContext = SessionContext.getContext();
			}
		}
		
		protected void _unlock() {
			synchronized (_accessMutex) {
				if (_lockingContext == null)
					return;
				if (!_lockingContext.equals(SessionContext.getContext()))
					return;
				_lockingContext = null;
				_accessMutex.notifyAll();
			}
		}
  }
  
  MethodLockMT _lock = new MethodLockMT(); 

  // identifier of the last uncommited transaction (increment by 16 to 
  // reuse last 4 bits from the Status.
  // it will be inceremented on commit if there was an merge during 
  // the last open transaction
  int lastTransactionId = 16;
  
  public void startTransaction() {
//    if (TransactionStarted)
//      throw new RuntimeException("Transaction already started");
    _lock._lock();
    TransactionStarted = true;
  }

  public void commitTransaction() {
    if (! TransactionStarted)
      throw new RuntimeException("Transaction not started");
    pool.commitCurrentWorker();
    synchronized (this) {
    	while(pool.hasActiveWorker()) {
    		try { wait(10);} catch (InterruptedException ie) {}
    	}
	} 
    
    if (InferStatements) {
    	Infer.reinfer();
        pool.commitCurrentWorker();
        synchronized (this) {
        	while(pool.hasActiveWorker()) {
        		try { wait(10);} catch (InterruptedException ie) {}
        	}
    	} 
    }
    if (bSafeTrans)
    	NumberOfStatementsInlastTransaction = storage.size()-1;
    else
    	NumberOfStatementsInlastTransaction = Integer.MAX_VALUE;
    TransactionStarted = false;
    _lock._unlock();

  }

  public boolean transactionStarted() {
    return TransactionStarted;
  }
  public class LocalThreadPool extends ThreadPool {
	  int jobSize;
	  LocalWorkerThread t = null;
	  
	  public LocalThreadPool(int num, int jobSize) {
		  super(num);
		  this.jobSize = jobSize; 
	  }
	  class LocalWorkerThread extends ThreadPool.WorkerThread {
		  int threadData[] = null;
		  int currentIndex = 0;
		public void doJob() {
			for (int i = 0; i < currentIndex; i+=4) {
				if (InferStatements)
					Infer.addStatement(threadData[i], threadData[i+1], threadData[i+2], threadData[i+3]);
				else
					storage.put(threadData[i], threadData[i+1], threadData[i+2], threadData[i+3]);
			}
		} //doJob
		public void addStatement(int subj, int pred, int obj, byte status) {
			threadData[currentIndex++] = subj;
			threadData[currentIndex++] = pred;
			threadData[currentIndex++] = obj;
			threadData[currentIndex++] = status;
			if (currentIndex == threadData.length) {
				t = null;
				synchronized (this) {
					notify();
				}
			}
		}
		public void go() {
			if (currentIndex > 0) {
				t = null;
				synchronized (this) {
					notify();
				}
			}
		}
	  } // LocalWorkerThread
		public void commitCurrentWorker() {
			if (t != null)
				t.go();
		}
		public void addStatement(int subj, int pred, int obj, byte status) {
			if (t == null) {
				t = (LocalWorkerThread)allocWorker();
				if (t.threadData == null)
					t.threadData = new int[jobSize*4];
				t.currentIndex = 0;
			}
			t.addStatement(subj, pred, obj, status);
		}
		
	  public ThreadPool.WorkerThread createButNotStartThread() {
		return new LocalWorkerThread();
	  }
	}
  LocalThreadPool pool = null;
  int countExplicit = 0;
  public void addStatement(Resource resource, URI uRI, Value value) throws SailUpdateException {
    if (! TransactionStarted)
      throw new RuntimeException("Transaction must be started first");

    int subj = Entities.add(resource, false);
    int pred = Entities.add(uRI, false);
    int obj = Entities.add(value, value instanceof Literal);
    if(!AddAsAxiom)
    	countExplicit++;
    	if (bUseMultithread || (!bUseMultithread && bTransitive)) {
    		((LocalThreadPool)pool).addStatement(subj, pred, obj, AddAsAxiom?Repository.AXIOM_STATEMENT_STATUS | Repository.EXPLICIT_STATEMENT_STATUS:Repository.EXPLICIT_STATEMENT_STATUS);
    	} else {
    		if (InferStatements)
    			Infer.addStatement(subj, pred, obj, AddAsAxiom?Repository.AXIOM_STATEMENT_STATUS | Repository.EXPLICIT_STATEMENT_STATUS :Repository.EXPLICIT_STATEMENT_STATUS);
    		else
    			storage.put(subj, pred, obj, AddAsAxiom?Repository.AXIOM_STATEMENT_STATUS | Repository.EXPLICIT_STATEMENT_STATUS : Repository.EXPLICIT_STATEMENT_STATUS);
    	}
 
  }

  public int removeStatements(Resource resource, URI uRI, Value value) throws SailUpdateException {
    if (! TransactionStarted)
      throw new RuntimeException("Transaction must be started first");

    int subj = (resource == null) ? 0 : Entities.getId(resource);
    int pred = (uRI == null) ? 0 : Entities.getId(uRI);
    int obj = (value == null) ? 0 : Entities.getId(value);

    return storage.remove(subj, pred, obj);
  }

  public void clearRepository() throws SailUpdateException {
    if (! TransactionStarted)
      throw new RuntimeException("Transaction must be started first");

    storage.clear();
  }

  public void changeNamespacePrefix(String uri, String prefix) throws SailUpdateException {
		Map map = Infer.getNameSpaceMapping(); 
		if (!map.containsValue(uri)) {
			map.put(prefix, uri);
			if (nDebugLevel > 1)
				System.out.println("added prefix:"+prefix+" -> ns:"+uri);
		} else {
			if (nDebugLevel > 1)
				System.out.println("uri found:"+uri);
		}
  }

  public void addListener(SailChangedListener sailChangedListener) {
  }

  public void removeListener(SailChangedListener sailChangedListener) {
  }

  public ValueFactory getValueFactory() {
    return VFactory;
  }

  public StatementIterator getStatements(Resource resource, URI uRI, Value value) {
    int subj = (resource == null) ? 0 : Entities.getId(resource);
    int pred = (uRI == null) ? 0 : Entities.getId(uRI);
    int obj = (value == null) ? 0 : Entities.getId(value);
    if ((subj == 0 && resource != null) ||
        (pred == 0 && uRI != null) ||
        (obj == 0 && value != null))
      return EmptyIterator;
    return new StatementIteratorImpl(storage.get(subj, pred, obj, Repository.INVERSE_PROP, NumberOfStatementsInlastTransaction), false);
  }

  private StatementIterator EmptyIterator = new StatementIterator() {
    public boolean hasNext() {
      return false;
    }

    public Statement next() {
      return null;
    }

    public void close() {
    }

  };

  public boolean hasStatement(Resource resource, URI uRI, Value value) {
    int subj = (resource == null) ? 0 : Entities.getId(resource);
    int pred = (uRI == null) ? 0 : Entities.getId(uRI);
    int obj = (value == null) ? 0 : Entities.getId(value);
    if ((subj == 0 && resource != null) ||
        (pred == 0 && uRI != null) ||
        (obj == 0 && value != null))
      return false;
    return storage.hasStatement(subj, pred, obj, NumberOfStatementsInlastTransaction);
  }

  static boolean bQuery = true;
  String pad(int val, int sz) {
	  String s = ""+val;
	  while (s.length() < sz)
		  s="0"+s;
	  return s;
  }
  public Query optimizeQuery(Query query) {
    return query;
  }

  public NamespaceIterator getNamespaces() {
      return new NamespaceIteratorImpl_(Infer.getNameSpaceMapping().keySet().iterator());
  }

  public StatementIterator getExplicitStatements(Resource resource, URI uRI, Value value) {
  	boolean bImplictit = false;
	SessionContext context = SessionContext.getContext(true);
	if (context != null) {
		if (context.VersionState != -1) {
			context.VersionState = -1;
			bImplictit = true;
		} else {
			if (resource != null && IMPLICIT_ONLY.equals(resource.toString())) {
				context.VersionState = 0;
				return EmptyIterator;
			}
		}
	}

	int subj = (resource == null) ? 0 : Entities.getId(resource);
    int pred = (uRI == null) ? 0 : Entities.getId(uRI);
    int obj = (value == null) ? 0 : Entities.getId(value);
    if ((subj == 0 && resource != null) ||
        (pred == 0 && uRI != null) ||
        (obj == 0 && value != null))
      return EmptyIterator;
    if (bImplictit)
        return new StatementIteratorImpl(storage.getIterator(subj, pred, obj, NumberOfStatementsInlastTransaction), true, true);
    return new StatementIteratorImpl(storage.getIterator(subj, pred, obj, NumberOfStatementsInlastTransaction), true);
  }
 
//------------------------
  private URI getRdfTypeNode() {
	  return (URI) Entities.getEntity(Infer.getRdfTypeNode());
  }
  private URI getRdfsClassNode() {
	  return (URI) Entities.getEntity(Infer.getRdfsClassNode());
  }
  
  private URI getRdfPropertyNode() {
	  return (URI) Entities.getEntity(Infer.getRdfPropertyNode());
  }
  
  private URI getRdfsSubClassOfNode() {
	  return (URI) Entities.getEntity(Infer.getRdfsSubClassOfNode());
  }
  private URI getRdfsSubPropertyOfNode() {
	  return (URI) Entities.getEntity(Infer.getRdfsSubPropertyOfNode());
  }
  private URI getRdfsDomainNode() {
	  return (URI) Entities.getEntity(Infer.getRdfsDomainNode());
  }
  private URI getRdfsRangeNode() {
	  return (URI) Entities.getEntity(Infer.getRdfsRangeNode());
  }
//------------------------
  
  public boolean hasExplicitStatement(Resource resource, URI uRI, Value value) {
	    int subj = (resource == null) ? 0 : Entities.getId(resource);
	    int pred = (uRI == null) ? 0 : Entities.getId(uRI);
	    int obj = (value == null) ? 0 : Entities.getId(value);
	    if ((subj == 0 && resource != null) ||
	        (pred == 0 && uRI != null) ||
	        (obj == 0 && value != null))
	      return false;
	    boolean found = false;
	    StatementIdIterator iter = storage.getIterator(subj, pred, obj, NumberOfStatementsInlastTransaction);
	    while (iter.hasNext()) {
	    	if (iter.Status == 0) 
	    		iter.next();
	    	else {	
	    		found = true; break;
	    	}
	    }
	    iter.close();
	    return found;
  }

  public StatementIterator getClasses() {
      return getStatements(null, getRdfTypeNode(), getRdfsClassNode());
  }

  public boolean isClass(Resource resource) {
      return hasStatement(resource, getRdfTypeNode(), getRdfsClassNode());
  }

  public StatementIterator getProperties() {
      return getStatements(null, getRdfTypeNode(), getRdfPropertyNode());
  }

  public boolean isProperty(Resource resource) {
      return hasStatement(resource, getRdfTypeNode(), getRdfPropertyNode());
  }

  public StatementIterator getSubClassOf(Resource resource, Resource resource1) {
      return getStatements(resource, getRdfsSubClassOfNode(),
              resource1);
  }

  public StatementIterator getDirectSubClassOf(Resource resource, Resource resource1) {
      return _getDirectStatements(resource,
              getRdfsSubClassOfNode(),
              resource1,
              getRdfsSubClassOfNode());
  }

  public boolean isSubClassOf(Resource resource, Resource resource1) {
      return hasStatement(resource, getRdfsSubClassOfNode(), resource1);
  }

  public boolean isDirectSubClassOf(Resource resource, Resource resource1) {
      StatementIterator iter = getDirectSubClassOf(resource, resource1);
      boolean result = iter.hasNext();
      iter.close();
      return result;
  }

  public StatementIterator getSubPropertyOf(Resource resource, Resource resource1) {
      return getStatements(resource, getRdfsSubPropertyOfNode(),
              resource1);
  }

  public StatementIterator getDirectSubPropertyOf(Resource resource, Resource resource1) {
      return _getDirectStatements(resource,
              (URI) getRdfsSubPropertyOfNode(),
              resource1,
              (URI) getRdfsSubPropertyOfNode());
  }

  public boolean isSubPropertyOf(Resource resource, Resource resource1) {
      return hasStatement(resource, (URI)getRdfsSubPropertyOfNode(), resource1);
  }

  public boolean isDirectSubPropertyOf(Resource resource, Resource resource1) {
      StatementIterator iter = getDirectSubPropertyOf(resource, resource1);
      boolean result = iter.hasNext();
      iter.close();
      return result;
  }

  public StatementIterator getDomain(Resource resource, Resource resource1) {
      return getStatements(resource, (URI) getRdfsDomainNode(),
              resource1);
  }

  public StatementIterator getRange(Resource resource, Resource resource1) {
      return getStatements(resource, (URI) getRdfsRangeNode(),
              resource1);
  }

  public StatementIterator getType(Resource resource, Resource resource1) {
      return getStatements(resource, (URI) getRdfTypeNode(),
              resource1);
  }

  public StatementIterator getDirectType(Resource resource, Resource resource1) {
      return _getDirectStatements(resource, (URI) getRdfTypeNode(),
              resource1,
              (URI) getRdfsSubClassOfNode());
  }

  public boolean isType(Resource resource, Resource resource1) {
      return hasStatement(resource, (URI)getRdfTypeNode(), resource1);
  }

  public boolean isDirectType(Resource resource, Resource resource1) {
      StatementIterator iter = getDirectType(resource, resource1);
      boolean result = iter.hasNext();
      iter.close();
      return result;
  }

  public LiteralIterator getLiterals(String label, String language, URI datatype) {
      if (language != null && datatype != null) {
          return BlankLiteralIterator;
      }
      return new LitralIteratorImpl(label, language, datatype);
  }
  
  private class LitralIteratorImpl implements LiteralIterator {
      private boolean Blank;
      private String Label;
      private String Language;
      private URI Datatype;
      private int Index = 1;

      private Value CurrentLiteral;

      public LitralIteratorImpl() {
          Blank = true;
      }

      public LitralIteratorImpl(String label, String language, URI datatype) {
          Blank = false;
          Label = label;
          Language = language;
          Datatype = datatype;
          next();
      }

      public Literal nextLiteral() {
          return (Literal) next();
      }

      public Value next() {
          if (Blank)
              return null;

//          int[] id = Entities.getIds();
//          Value[] keys = (Value[]) Entities.getKeys();

          Value l = CurrentLiteral;

          while (Index < Entities.size()) {
          	CurrentLiteral = (Value)Entities.getEntity(-Index);
              if (CurrentLiteral != null) {
//                  CurrentLiteral = (Literal) keys[Index];
                  Index++;
                  if (((Label != null && ((Literal) CurrentLiteral).getLabel().equals(Label)) || Label == null) &&
                      ((Language != null && ((Literal) CurrentLiteral).getLanguage().equals(Language)) || Language == null) &&
                      ((Datatype != null && ((Literal) CurrentLiteral).getDatatype().equals(Datatype)) || Datatype == null)) {

                      CurrentLiteral = l;
                      break;
                  }
              }
              Index++;
          }

          return l;
      }

      public boolean hasNext() {
          return Index < Entities.size();
      }

      public void close() {}
  }

  private LiteralIterator BlankLiteralIterator = new LitralIteratorImpl();
  
  protected class ResultStatementIdIterator extends StatementIdIterator {
      private IntegerContainer C = new IntegerContainer();
      private int Index = 0;
      boolean Found;
      public long getStatementNumber() { return -1;}

      public void add(int subj, int pred, int obj) {
          C.add(subj);
          C.add(pred);
          C.add(obj);
      }

      public boolean hasNext() {
          return Found;
      }

      public void next() {
          	Found = false;
          	if (Index < C.size()) {
		            Subj = C.get(Index++);
		            Pred = C.get(Index++);
		            Obj = C.get(Index++);
		            Found = true;
          	}
      }
      public void changeStatus(byte status) {

      }
      
      public void close() {}
  }

  private StatementIterator _getDirectStatements(Resource resource,
          URI uri, Resource resource1, URI property_)
  {
      int subj = 0;
      if (resource != null) {
          subj = Entities.getId(resource);
          if (subj == 0) {
              return EmptyIterator;
          }
      }

      int pred1 = Entities.getId(uri);
      int pred2 = Entities.getId(property_);

      int obj = 0;
      if (resource1 != null) {
          obj = Entities.getId(resource1);
          if (obj == 0) {
              return EmptyIterator;
          }
      }

      StatementIdIterator iter1 = storage.get(subj, pred1, obj, Repository.INVERSE_PROP, NumberOfStatementsInlastTransaction);
      ResultStatementIdIterator res = new ResultStatementIdIterator();

      while (iter1.hasNext()) {
          if (iter1.Subj != iter1.Obj) {
              StatementIdIterator iter2 = storage.get(iter1.Subj, pred1, 0, Repository.INVERSE_PROP, NumberOfStatementsInlastTransaction);
              boolean existsIntermediate = false;
              boolean inCycle = false;
              while (iter2.hasNext()) {
                  inCycle = true;

                  if (iter2.Obj != iter1.Subj && iter2.Obj != iter1.Obj) {
                      StatementIdIterator iter3 = storage.get(
                              iter2.Obj, pred2, iter1.Obj, Repository.INVERSE_PROP, NumberOfStatementsInlastTransaction);
                      existsIntermediate = iter3.hasNext();
                      if (existsIntermediate) {
                          break;
                      }
                  }
                  iter2.next();
              }

              if (inCycle && ! existsIntermediate) {
                  res.add(iter1.Subj, pred1, iter1.Obj);
              }
          }
          iter1.next();
      }

      res.next();
      return new StatementIteratorImpl(res, false);
  }

  public void shutDown() {
	  dumper.interrupt();
	  dumper.mustBreak = true;
	  while (dumper.getState() != Thread.State.TERMINATED) {
		  synchronized (this) {try { wait(100);} catch (InterruptedException ie) {}}
	  }
    if (mainStorageFileName != null ) {
		if (nDebugLevel > 1)
			System.out.print("Refreshing main file:"+mainStorageFileName+" ...");
      _syncToMainFile();
		if (nDebugLevel > 1)
			System.out.println("done");
    }
    pool.shutDown();
    Infer.shutdown(); Infer = null;
    Entities = null;
    VFactory = null;
  }

// -----------------------------------------------------------------------------------------
// StatementIteratorImpl
// -----------------------------------------------------------------------------------------

  private class StatementIteratorImpl implements StatementIterator {

    private StatementIdIterator Iter;
    private boolean ExplicitStatements;
    private boolean bSkipExplicitStatements;

    public StatementIteratorImpl(StatementIdIterator iter, boolean explicitStatements, boolean bSkipExplicitStatements) {
    	this.bSkipExplicitStatements = bSkipExplicitStatements;
        Iter = iter;
        ExplicitStatements = true;
	      while (Iter.hasNext()) {
	        if (Iter.Status == ((bSkipExplicitStatements)?0:Repository.EXPLICIT_STATEMENT_STATUS))
	          break;
	        Iter.next();
	      }
    }
    public StatementIteratorImpl(StatementIdIterator iter, boolean explicitStatements) {
    	bSkipExplicitStatements = false;
      Iter = iter;
      ExplicitStatements = explicitStatements;
      if (explicitStatements) {
        while (Iter.hasNext()) {
          if (0 != (Iter.Status & Repository.EXPLICIT_STATEMENT_STATUS))
            break;
          Iter.next();
        }
      }
    }

    public boolean hasNext() {
      return Iter.hasNext();
    }

    public Statement next() {
      Statement st = null;
      if (bInRemoteContext)
    	  st = new org.openrdf.model.impl.StatementImpl((Resource)Entities.getEntity(Iter.Subj), (URI)Entities.getEntity(Iter.Pred), (Value)Entities.getEntity(Iter.Obj));
      else
    	  st = new StatementImpl(Iter.Subj, Iter.Pred, Iter.Obj);

      if (ExplicitStatements) {
        while (Iter.hasNext()) {
          Iter.next();
          if (bSkipExplicitStatements) {
        	  if (Iter.Status == 0)
        		  break;
          } else {
              if (0 != (Iter.Status & Repository.EXPLICIT_STATEMENT_STATUS))
	            break;
          }
        }
      } else {
        Iter.next();
      }
      return st;
    }

    public void close() {
      //Iter.close();
    }
  }

// -----------------------------------------------------------------------------------------
// StatementImpl
// -----------------------------------------------------------------------------------------

  private class StatementImpl implements Statement {

    private int Subj, Pred, Obj;
    private Resource Subject;
    private URI Predicate;
    private Value Object;

    public StatementImpl(int subj, int pred, int obj) {
      Subj = subj;
      Pred = pred;
      Obj = obj;

    }

    public int compareTo(Object o) {
      return equals(o) ? 0 : -1;
    }

    public boolean equals(Object o) {
      if (o instanceof StatementImpl) {
        StatementImpl s = (StatementImpl) o;
        return Subj == s.Subj &&
               Pred == s.Pred &&
               Obj == s.Obj;
      } else if (o instanceof Statement) {
        Statement s = (Statement) o;
        return getSubject().equals(s.getSubject()) &&
               getPredicate().equals(s.getPredicate()) &&
               getObject().equals(s.getObject());
      }
      return false;
    }

    public Resource getSubject() {
      if (Subject == null) {
        Subject = (Resource) Entities.getEntity(Subj);
      }
      return Subject;
    }

    public URI getPredicate() {
      if (Predicate == null) {
        Predicate = (URI) Entities.getEntity(Pred);
      }
      return Predicate;
    }

    public Value getObject() {
      if (Object == null) {
        Object = (Value) Entities.getEntity(Obj);
      }
      return Object;
    }

  }

// -----------------------------------------------------------------------------------------

  protected void _syncToMainFile() {
	  if (mainStorageFileName == null || mainStorageFileName.trim().length() == 0)
		  return;
    java.io.Writer fw = null;
    try {
      java.io.File FILEN = new java.io.File(mainStorageFileName);
      if (bCompressFile)
        fw = new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(
            FILEN)));
      else
        fw = new java.io.FileWriter(FILEN, false);

      final RdfDocumentWriter ntw;
      if (0 == "rdfxml".compareTo(sDataFormat))
        ntw = new RdfXmlWriter(new BufferedWriter(fw, 256 * 1024));
      else if (0 == "turtle".compareTo(sDataFormat))
        ntw = new TurtleWriter(new BufferedWriter(fw, 256 * 1024));
      else
        ntw = new org.openrdf.rio.ntriples.NTriplesWriter(new BufferedWriter(fw,
            256 * 1024));
      ntw.startDocument();
      ntw.writeComment("main file");
      StatementIterator iter = new StatementIteratorImpl(storage.createtExplicitStorageIterator(0), true);//getExplicitStatements(null, null, null);
      while (iter.hasNext()) {
        Statement st = iter.next();
        ntw.writeStatement(st.getSubject(), st.getPredicate(), st.getObject());
      }
      ntw.endDocument();
      fw.flush();
      fw.close();
    }
    catch (IOException ioe) {
      ioe.printStackTrace();
      throw new RuntimeException("prev hide", ioe);
    }
    finally {
      try {
        fw.close();
      }
      catch (IOException ioe2) {

      }
    }
    if (sNewTriplesFileName != null)
      _backupFile(new File(sNewTriplesFileName), "~bak");

  }

  protected void _loadMainDataFile() {
    if (mainStorageFileName != null) {
      File fMainFile = new File(mainStorageFileName);
      if (! fMainFile.exists()) {
    	  if (true) return;
        try {
          fMainFile.createNewFile();
        }
        catch (IOException ioe) {
          throw new RuntimeException("Cannot create " + mainStorageFileName + " file!", ioe);
        }
      }
      _addThisOntology(mainStorageFileName, baseURL);
      if (!bNoPersist && sNewTriplesFileName != null && sNewTriplesFileName.length() > 1) {
        File oldTempFile = new File(sNewTriplesFileName);
        if (oldTempFile.exists()) {
          _addThisOntology(sNewTriplesFileName, baseURL);
          _backupFile(oldTempFile, "~bak");
        }
      }
    }
  }

  protected void _backupFile(File extFile, String nameext) {
    if (extFile != null && extFile.exists()) {
      String backup = extFile.getAbsolutePath() + "." + nameext;
      File bakFile = new java.io.File(backup);
      if (bakFile.exists())
        bakFile.delete();
      if (!extFile.renameTo(bakFile)) {
        try {
          bakFile = bakFile.getCanonicalFile();
          extFile.renameTo(bakFile);
        }
        catch (IOException ioe) {

        }
      }
      String name = extFile.getAbsolutePath();
      if (name.indexOf(nameext) == -1)
        extFile.delete();
    }
  }

  //private Object _writeLock = new Object();
  
  int persistedcount = 0;
  class PersistThread extends Thread {
	  StatementIdIterator statements;
	  boolean mustBreak = false;

	  org.openrdf.rio.ntriples.NTriplesWriter ntw = null;
	  java.io.FileWriter fw = null;
	  
	  PersistThread(Repository rep ) {
		  statements = rep.createtExplicitStorageIterator(-1);
		  try { prepareDump(); } catch (Exception e) {
			  e.printStackTrace(System.err);
		  }
	  }
	  private void prepareDump() throws IOException {
		  if (bNoPersist == true || sNewTriplesFileName == null || sNewTriplesFileName.length() < 1)
			  return;
          java.io.File FILEN = new java.io.File(sNewTriplesFileName);
          fw = new java.io.FileWriter(FILEN, true);
          ntw = new org.openrdf.rio.ntriples.NTriplesWriter(fw);
          ntw.startDocument();
		  
	  }
	  private void finalizeDump()throws IOException {
		  statements.close();
          ntw.endDocument();
          fw.flush();
          fw.close();
	  }
	  public void run() {
		  if (ntw == null) return;
		  while(!mustBreak) {
			synchronized (this) {
				  try {
					  wait(5000);
				  }catch (InterruptedException ie) {
					  try { finalizeDump();} catch (Exception e) {e.printStackTrace(System.err);}
					  return;
				  }
				  if (interrupted()) {
					  try { finalizeDump();} catch (Exception e) {e.printStackTrace(System.err);}
					  return;
				  }
			}  
			try {
//				System.out.println("dump started!");
				while (!mustBreak && statements.hasNext()) {
					persistedcount++;
					ntw.writeStatement((Resource)Entities.getEntity(statements.Subj), (URI)Entities.getEntity(statements.Pred), (Value)Entities.getEntity(statements.Obj));
					if (bFlushOnEach)
						fw.flush();
					statements.next();
				}
				fw.flush();
//				System.out.println("Dumper: mustBreak ="+mustBreak+", empty iterator, persistedcount="+persistedcount);
			} catch (IOException ioe) {
				ioe.printStackTrace(System.err);
			}
		  }
		  if (mustBreak) {
			  try { finalizeDump();} catch (Exception e) {e.printStackTrace(System.err);}
		  }
	  }
  }
  
}

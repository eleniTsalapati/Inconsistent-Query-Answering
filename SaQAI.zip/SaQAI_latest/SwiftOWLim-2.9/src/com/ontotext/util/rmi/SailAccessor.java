package com.ontotext.util.rmi;

import org.openrdf.sesame.sail.Sail;
import org.openrdf.rio.*;

public interface SailAccessor {
  /**
   * Gets the SAIL object of this repository. Note that no security
   * restrictions are placed on the Sail; it is the developer's responsibility
   * to check access restrictions before doing operations on the Sail.
   */
  public Sail getSail();

  /**
   *  Checks whether the current user has read access to this repository.
   */
  public boolean hasReadAccess();

  /**
   *  Checks whether the current user has write access to this repository.
   */
  public boolean hasWriteAccess();

  /**
   *  Extracts data from the repository and reports the triples to the supplied RdfDocumentWriter.
   */
  public void extractRDF(RdfDocumentWriter rdfDocWriter, boolean ontology, boolean instances, boolean explicitOnly, boolean niceOutput)
          throws org.openrdf.sesame.config.AccessDeniedException, java.io.IOException;
}

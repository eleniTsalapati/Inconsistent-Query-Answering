package com.ontotext.util.rmi;

import org.openrdf.sesame.repository.SesameRepository;
import org.openrdf.sesame.repository.local.LocalRepository;
import org.openrdf.sesame.constants.QueryLanguage;
import org.openrdf.sesame.query.TableQueryResultListener;
import org.openrdf.model.Graph;
import java.io.IOException;
import org.openrdf.sesame.query.MalformedQueryException;
import org.openrdf.sesame.query.QueryEvaluationException;
import org.openrdf.sesame.config.AccessDeniedException;
import org.openrdf.sesame.query.QueryResultsTable;
import org.openrdf.sesame.query.GraphQueryResultListener;
import java.net.URL;
import org.openrdf.sesame.constants.RDFFormat;
import org.openrdf.sesame.admin.AdminListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.Reader;
import java.io.InputStream;
import org.openrdf.model.Resource;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import org.openrdf.sesame.sail.Sail;
import org.openrdf.rio.RdfDocumentWriter;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SailAccessEnabledRepository implements SesameRepository, SailAccessor {
  LocalRepository toRouteWith;
  SailAccessEnabledRepository(LocalRepository toRouteWith) {
    this.toRouteWith = toRouteWith;
  }
  public void performTableQuery(QueryLanguage parm1, String parm2, TableQueryResultListener parm3) throws java.io.IOException, org.openrdf.sesame.query.MalformedQueryException, org.openrdf.sesame.query.QueryEvaluationException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.performTableQuery(parm1, parm2, parm3);
  }
  public QueryResultsTable performTableQuery(QueryLanguage parm1, String parm2) throws java.io.IOException, org.openrdf.sesame.query.MalformedQueryException, org.openrdf.sesame.query.QueryEvaluationException, org.openrdf.sesame.config.AccessDeniedException {
    return this.toRouteWith.performTableQuery(parm1, parm2);
  }
  public void performGraphQuery(QueryLanguage parm1, String parm2, GraphQueryResultListener parm3) throws java.io.IOException, org.openrdf.sesame.query.MalformedQueryException, org.openrdf.sesame.query.QueryEvaluationException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.performGraphQuery(parm1, parm2, parm3);
  }
  public Graph performGraphQuery(QueryLanguage language, String query)
      throws IOException, MalformedQueryException, QueryEvaluationException, AccessDeniedException {
      return this.toRouteWith.performGraphQuery(language, query);
  }

  public void addData(URL parm1, String parm2, RDFFormat parm3, boolean parm4, AdminListener parm5) throws java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.addData(parm1, parm2, parm3, parm4, parm5);
  }
  public void addData(File parm1, String parm2, RDFFormat parm3, boolean parm4, AdminListener parm5) throws java.io.FileNotFoundException, java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.addData(parm1, parm2, parm3, parm4, parm5);
  }
  public void addData(String parm1, String parm2, RDFFormat parm3, boolean parm4, AdminListener parm5) throws java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.addData(parm1, parm2, parm3, parm4, parm5);
  }
  public void addData(Reader parm1, String parm2, RDFFormat parm3, boolean parm4, AdminListener parm5) throws java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.addData(parm1, parm2, parm3, parm4, parm5);
  }
  public void addData(InputStream parm1, String parm2, RDFFormat parm3, boolean parm4, AdminListener parm5) throws java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.addData(parm1, parm2, parm3, parm4, parm5);
  }
  public void addData(SesameRepository repository, AdminListener listener)
    throws IOException, AccessDeniedException {
      this.toRouteWith.addData(repository, listener);
  }

  public InputStream extractRDF(RDFFormat parm1, boolean parm2, boolean parm3, boolean parm4, boolean parm5) throws java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    return this.toRouteWith.extractRDF(parm1, parm2, parm3, parm4, parm5);
  }
  public void removeStatements(Resource parm1, URI parm2, Value parm3, AdminListener parm4) throws java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.removeStatements(parm1, parm2, parm3, parm4);
  }
  public void clear(AdminListener parm1) throws java.io.IOException, org.openrdf.sesame.config.AccessDeniedException {
    this.toRouteWith.clear(parm1);
  }
  public void addGraph(Graph graph) throws IOException, AccessDeniedException{
     this.toRouteWith.addGraph(graph);
  }
  public void addGraph(QueryLanguage language, String query)
          throws IOException, AccessDeniedException {
      this.toRouteWith.addGraph(language, query);
  }
  public void removeGraph(Graph graph) throws IOException, AccessDeniedException {
      this.toRouteWith.removeGraph(graph);
  }
  public void removeGraph(QueryLanguage language, String query)
          throws IOException, AccessDeniedException {
      this.toRouteWith.removeGraph(language, query);
  }

  public Sail getSail() {
    return this.toRouteWith.getSail();
  }

  public String getRepositoryId() {
      return this.toRouteWith.getRepositoryId();
  }

  public void addGraph(QueryLanguage language, java.lang.String query, boolean joinBlankNodes)
           throws IOException, AccessDeniedException {
      this.toRouteWith.addGraph(language, query, joinBlankNodes);
  }

  public void addGraph(Graph graph, boolean joinBlankNodes)
           throws IOException, AccessDeniedException {
      this.toRouteWith.addGraph(graph, joinBlankNodes);
  }

  public boolean hasReadAccess() {
      return this.toRouteWith.hasReadAccess();
  }

  public boolean hasWriteAccess() {
      return this.toRouteWith.hasWriteAccess();
  }

  public void extractRDF(RdfDocumentWriter rdfDocWriter, boolean ontology, boolean instances, boolean explicitOnly, boolean niceOutput)
          throws AccessDeniedException,
                 IOException {
      this.toRouteWith.extractRDF(rdfDocWriter, ontology, instances, explicitOnly, niceOutput);
  }
}

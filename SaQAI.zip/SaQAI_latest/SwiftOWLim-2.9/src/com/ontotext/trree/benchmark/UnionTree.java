/*
 OWLIM - a SAIL implementation with OWL inference for Sesame (www.openrdf.org)
  
 Copyright (c) 2004-2005, OntoText Lab. / SIRMA

 This library is free software; you can redistribute it and/or modify it under
 the terms of the GNU Lesser General Public License as published by the Free
 Software Foundation; either version 2.1 of the License, or (at your option)
 any later version.
 This library is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 details.
 You should have received a copy of the GNU Lesser General Public License along
 with this library; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package com.ontotext.trree.benchmark;

import java.io.*;
import java.util.*;

/**
 * UnionTree - generates the data for the unions benchmark 
 * @author Damyan
 *
 */
public class UnionTree {

    public static final String UNION_TREE_BENCH_FILE_NAME_BASE = "./benchmark/data/union-tree-";
    public static final String FILE_NAME_EXTENSION = ".nt";

    public static void main(String[] args) throws Exception {
        if (args.length != 3 && args.length != 4) {
            System.out.println("Union Tree Benchmark File Generator");
            System.out.println("Usage: java UnionTree <tree-height> <branch-coeffitient> <instances-per-node>");
            System.out.println("  <tree-height>  --  the height of the hierarchy tree");
            System.out.println("  <branch-coeff> --  number of branches per non-leaf node");
            System.out.println("  <instances-pre-node> -- number of instances per node of the tree");
            return;
        }

        int height = Integer.parseInt(args[0]);
        int branches = Integer.parseInt(args[1]);
        int instances = Integer.parseInt(args[2]);
        int maxNumberOfClasses = args.length == 3 ? Integer.MAX_VALUE : Integer.parseInt(args[3]) + 1;

        String filename = generateFileName(height, branches);
        PrintWriter out = new PrintWriter(new FileWriter(filename));

        String classBase = "<http://www.test.org#Union";
        String unionOf = "<http://www.w3.org/2002/07/owl#unionOf> ";
        String bnodeBase = "_:node";
        String first = "<http://www.w3.org/1999/02/22-rdf-syntax-ns#first> ";
        String rest = "<http://www.w3.org/1999/02/22-rdf-syntax-ns#rest> ";
        String list = "<http://www.w3.org/1999/02/22-rdf-syntax-ns#List> ";
        String type = "<http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ";
        String nil = "<http://www.w3.org/1999/02/22-rdf-syntax-ns#nil> ";
        String dot = ".";
        String br = "> ";
        String instanceBase = "<http://www.test.org#Instance_";

        int bnodeCounter = 1;
        int classCounter = 1;
        int instanceCounter = 1;

        List union = new ArrayList();
        union.add(classBase + (classCounter++) + br);
        List newUnion;
        boolean done = false;

        for (int h = 0; h < height; h++) {
            newUnion = new ArrayList();

            for (int i = 0; i < union.size(); i++) {
                String cl = (String) union.get(i);
                if (Integer.parseInt(cl.substring(classBase.length(), cl.length() - 2)) == maxNumberOfClasses) {
                    done = true;
                    break;
                }

                for (int j = 0; j < instances; j++) {
                    out.println(instanceBase + (instanceCounter++) + br + type + cl + dot);
                }

                if (h == height - 1)
                    continue;

                String[] bnodes = new String[branches];
                String[] classes = new String[branches];
                for (int j = 0; j < branches; j++) {
                    bnodes[j] = bnodeBase + (bnodeCounter++) + " ";
                    classes[j] = classBase + (classCounter++) + br;
                }

                out.println(cl + unionOf + bnodes[0] + dot);
                for (int j = 0; j < branches; j++) {
                    if (bnodes[j] == null)
                        break;
                    out.println(bnodes[j] + first + classes[j] + dot);
                    out.println(bnodes[j] + type + list + dot);
                    if (j < branches - 1) {
                        out.println(bnodes[j] + rest + bnodes[j + 1] + dot);
                    } else {
                        out.println(bnodes[j] + rest + nil + dot);
                    }
                    newUnion.add(classes[j]);
                }

            } // for i

            union = newUnion;
            if (done)
                break;
        }

        out.close();
        System.out.println("File '" + filename + "' generated.");
    }

    public static String generateFileName(int treeHeight, int branchCoeff) {
        return UNION_TREE_BENCH_FILE_NAME_BASE + treeHeight + "-" + branchCoeff + FILE_NAME_EXTENSION;
    }
}

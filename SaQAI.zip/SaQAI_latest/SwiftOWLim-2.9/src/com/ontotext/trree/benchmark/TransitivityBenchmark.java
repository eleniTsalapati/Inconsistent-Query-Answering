/*
 OWLIM - a SAIL implementation with OWL inference for Sesame (www.openrdf.org)
  
 Copyright (c) 2004-2005, OntoText Lab. / SIRMA

 This library is free software; you can redistribute it and/or modify it under
 the terms of the GNU Lesser General Public License as published by the Free
 Software Foundation; either version 2.1 of the License, or (at your option)
 any later version.
 This library is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 details.
 You should have received a copy of the GNU Lesser General Public License along
 with this library; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package com.ontotext.trree.benchmark;

/**
 * TransitivityBenchmark - runs the EXQUANT transitivity benchmark
 * 
 * @author Damyan
 *
 */
public class TransitivityBenchmark {

    public static void main(String[] args) throws Exception {
    	int stepchain = Integer.parseInt( System.getProperty("stepchain", "1000"));
    	int maxchain = Integer.parseInt( System.getProperty("maxchain", "5000"));
        for (int i = stepchain; i <= maxchain; i += stepchain) {
            runTransitivityBenchmark(i);
        }
    }

    public static void runTransitivityBenchmark(int chainLength) throws Exception {
        Transitivity.main(new String[] { "" + chainLength });
        java.io.File f = new java.io.File("./kb/kb.nt");
        f.delete();
        Benchmark.main(new String[] { "./bin/test/system.conf", Transitivity.generateFileName(chainLength), "./benchmark/transitivity-benchmark-query.serql" });
    }
}

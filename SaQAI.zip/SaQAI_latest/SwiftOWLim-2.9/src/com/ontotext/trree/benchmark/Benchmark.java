/*
 OWLIM - a SAIL implementation with OWL inference for Sesame (www.openrdf.org)
  
 Copyright (c) 2004-2005, OntoText Lab. / SIRMA

 This library is free software; you can redistribute it and/or modify it under
 the terms of the GNU Lesser General Public License as published by the Free
 Software Foundation; either version 2.1 of the License, or (at your option)
 any later version.
 This library is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 details.
 You should have received a copy of the GNU Lesser General Public License along
 with this library; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package com.ontotext.trree.benchmark;

import java.io.*;
import java.util.*;
import org.openrdf.sesame.Sesame;
import java.io.File;
import org.openrdf.sesame.repository.local.LocalRepository;
import org.openrdf.model.Statement;
import org.openrdf.sesame.Sesame;
import org.openrdf.sesame.admin.AdminListener;
import org.openrdf.sesame.config.*;
import org.openrdf.sesame.constants.QueryLanguage;
import org.openrdf.sesame.constants.RDFFormat;
import org.openrdf.sesame.query.*;
import org.openrdf.sesame.repository.local.LocalRepository;
import org.openrdf.sesame.repository.local.LocalService;
import org.openrdf.model.Value;

/**
 * Benchmark - a benchmark running utility
 * 
 * @author Ruslan Velkov - ontotext lab.
 *
 */
public class Benchmark {

    public static void main(String[] args) throws Exception {

        if (args.length != 3) {
            System.out.println("OWLIM Benchmark");
            System.out.println("Usage: java Benchmark <config-file> <data-file> <query-file>");
            System.out.println("  <config-file>  --  the repository config file");
            System.out.println("  <data-file>    --  file containing the data and/or the schema (ontology)");
            System.out.println("  <query-file>   --  file containing queries to be evaluated over the loaded data");
            return;
        }

        String config_file = args[0];
        String data_file = args[1];
        String query_file = args[2];
        String[] queries = collectQueries(query_file);

        File file = new File(config_file);
        LocalService service = Sesame.getService(file);
        service.login("admin", "REPLACE_ME");
        LocalRepository repository = (LocalRepository)service.getRepository("owlim-benchmark");

        System.out.println("Loading data. . .");
        long begin = System.currentTimeMillis();

        repository.addData(new File(data_file), "http://www.test.org#", RDFFormat.NTRIPLES, true, new AdminListener() {
            public void transactionStart() {
            }

            public void transactionEnd() {
            }

            public void status(String string, int _int, int _int2) {
            }

            public void notification(String string, int _int, int _int2, Statement statement) {
            }

            public void warning(String string, int _int, int _int2, Statement statement) {
                System.err.println("Warning: " + string + " " + _int + " " + _int2 + " " + statement);
            }

            public void error(String string, int _int, int _int2, Statement statement) {
                throw new RuntimeException(string + " " + _int + " " + _int2 + " " + statement);
            }
        });

        long end = System.currentTimeMillis();
        System.err.println("Data from\t'" + data_file + "'\tloaded in\t" + (end - begin) + "\tms.");
        System.out.println("");

        boolean printResults = false;

        for (int i = 0; i < queries.length; i++) {
            String name = queries[i].substring(0, queries[i].indexOf(":"));
            String query = queries[i].substring(name.length() + 1).trim();
            System.out.println("[" + name + "]");
            long queryBegin = System.currentTimeMillis();
            QueryResultsTable res = repository.performTableQuery(QueryLanguage.SERQL, query);

            if (printResults) {
                String[] columnNames = res.getColumnNames();
                for (int j = 0; j < columnNames.length; j++) {
                    System.out.print(columnNames[j] + "\t");
                }
                System.out.println("");

                int columns = res.getColumnCount();
                int rows = res.getRowCount();

                for (int j = 0; j < rows; j++) {
                    for (int k = 0; k < columns; k++) {
                        Value v = res.getValue(j, k);
                        System.out.print("" + v + "\t");
                    }
                    System.out.println("");
                }

                System.out.println("");
            }

            long queryEnd = System.currentTimeMillis();
            System.out.println("" + res.getRowCount() + " result(s) in " + (queryEnd - queryBegin) + "ms.\n");
        }

        System.out.println("--------------------------------------------\n");

        repository.shutDown();
        repository = null;
        System.gc();
    }

    private static String[] collectQueries(String queryFile) throws Exception {
        List queries = new ArrayList();
        BufferedReader inp = new BufferedReader(new FileReader(queryFile));
        String nextLine = null;

        while (true) {
            String line = nextLine;
            nextLine = null;
            if (line == null)
                line = inp.readLine();
            if (line == null)
                break;
            line = line.trim();
            if (line.length() == 0)
                continue;
            if (line.startsWith("#"))
                continue;
            if (line.startsWith("[") && line.endsWith("]")) {
                StringBuffer buff = new StringBuffer(line.substring(1, line.length() - 1));
                buff.append(": ");

                while (true) {
                    line = inp.readLine();
                    if (line == null)
                        break;
                    line = line.trim();
                    if (line.length() == 0)
                        continue;
                    if (line.startsWith("#"))
                        continue;
                    if (line.startsWith("[")) {
                        nextLine = line;
                        break;
                    }
                    buff.append(line);
                    buff.append("\n");
                }

                queries.add(buff.toString());
            }
        } // while (true)

        String[] result = new String[queries.size()];
        for (int i = 0; i < queries.size(); i++) {
            result[i] = (String) queries.get(i);
        }
        return result;
    }
}

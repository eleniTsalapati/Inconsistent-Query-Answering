/*
 OWLIM - a SAIL implementation with OWL inference for Sesame (www.openrdf.org)
  
 Copyright (c) 2004-2005, OntoText Lab. / SIRMA

 This library is free software; you can redistribute it and/or modify it under
 the terms of the GNU Lesser General Public License as published by the Free
 Software Foundation; either version 2.1 of the License, or (at your option)
 any later version.
 This library is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 details.
 You should have received a copy of the GNU Lesser General Public License along
 with this library; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package com.ontotext.trree.benchmark;

/**
 * UnionTreeBenchMark - runs the Union benchmark
 * 
 * @author Damyan
 *
 */
public class UnionTreeBenchMark {

    public static void main(String[] args) throws Exception {
//        loadTimeBenchamrk();
//        loadAndQueryTimeBenchmark();
        singleTest();
//        degeneratedTreeTest();
//        hasValueTest();
//        transitiveOverTest();
    }

    private static void loadTimeBenchamrk() throws Exception {
        for (int i = 2; i <= 8; i++) {
            for (int j = 2; j <= 5; j++) {
                runUnionTreeBenchmark(i, j, 5);
            }
        }
    }

    public static void runUnionTreeBenchmark(int height, int branches, int instances) throws Exception {
        UnionTree.main(new String[] { "" + height, "" + branches, "" + instances });
        java.io.File f = new java.io.File("./kb/kb.nt");
        f.delete();
        Benchmark.main(new String[] { "./bin/test/system.conf", UnionTree.generateFileName(height, branches), "./benchmark/union-tree-benchmark-query.serql" });
    }

    private static void loadAndQueryTimeBenchmark() throws Exception {
        runUnionTreeBenchmark(15, 2, 10, 3500);
        runUnionTreeBenchmark(15, 2, 5, 3500);
        runUnionTreeBenchmark(15, 3, 10, 3500);
        runUnionTreeBenchmark(15, 3, 5, 3500);
        runUnionTreeBenchmark(15, 5, 10, 3500);
        runUnionTreeBenchmark(15, 5, 5, 3500);
    }

    public static void runUnionTreeBenchmark(int height, int branches, int instances, int maxClasses) throws Exception {
        UnionTree.main(new String[] { "" + height, "" + branches, "" + instances, "" + maxClasses });
        java.io.File f = new java.io.File("./kb/kb.nt");
        f.delete();
        Benchmark.main(new String[] { "./bin/test/system.conf", UnionTree.generateFileName(height, branches), "./benchmark/union-tree-benchmark-query.serql" });
    }

    public static void singleTest() throws Exception {
        runUnionTreeBenchmark(5, 5, 10, 3500);
        runUnionTreeBenchmark(6, 5, 10, 3500);
        runUnionTreeBenchmark(7, 5, 10, 3500);
        runUnionTreeBenchmark(12, 2, 10, 3500);
        runUnionTreeBenchmark(13, 2, 10, 3500);
        runUnionTreeBenchmark(14, 2, 10, 3500);
    }

    public static void degeneratedTreeTest() throws Exception {
      java.io.File f = new java.io.File("./kb/lubm.nt");
      f.delete();
      Benchmark.main(new String[] { "./bin/test/system.conf", "./benchmark/degenerated-tree.nt", "./benchmark/union-tree-benchmark-query.serql" });
    }

    public static void hasValueTest() throws Exception {
      Benchmark.main(new String[] { "./bin/test/system.conf", "./benchmark/hasValue.nt", "./benchmark/hasValue.serql" });
    }

    public static void transitiveOverTest() throws Exception {
      Benchmark.main(new String[] { "./bin/test/system.conf", "./benchmark/transitiveOver.nt", "./benchmark/transitiveOver.serql" });
    }

}

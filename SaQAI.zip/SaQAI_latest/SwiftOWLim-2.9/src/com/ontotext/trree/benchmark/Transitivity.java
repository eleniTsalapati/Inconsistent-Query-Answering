/*
 OWLIM - a SAIL implementation with OWL inference for Sesame (www.openrdf.org)
  
 Copyright (c) 2004-2005, OntoText Lab. / SIRMA

 This library is free software; you can redistribute it and/or modify it under
 the terms of the GNU Lesser General Public License as published by the Free
 Software Foundation; either version 2.1 of the License, or (at your option)
 any later version.
 This library is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 details.
 You should have received a copy of the GNU Lesser General Public License along
 with this library; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

package com.ontotext.trree.benchmark;

import java.io.*;

/**
 * Transitivity - a transitivity benchmark generator 
 * creates a test data for the exquant benchmark
 * 
 * @author Damyan
 *
 */
public class Transitivity {

    public static final String FILE_NAME_BASE = "./benchmark/data/transitivity-benchmark-";
    public static final String FILE_EXTENSION = ".nt";
    public static final String NAME_SPACE = "http://www.test.org/transitivity-benchmark#";

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Transitivity Benchmark Generator");
            System.out.println("Usage: java Transitivity <chain-length>");
            System.out.println("  <chain-length> -- the number of instances inetrconnected via transitive property");
            return;
        }

        int chainLength = Integer.parseInt(args[0]);
        String filename = generateFileName(chainLength);

        String transProp = "<" + NAME_SPACE + "transitiveTestProperty> ";
        String instanceBase = "<" + NAME_SPACE + "instance";
        String type = "<http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ";
        String restrictionClass = "<http://www.w3.org/2002/07/owl#Restriction> ";
        String someValuesFrom = "<http://www.w3.org/2002/07/owl#someValuesFrom> ";
        String onProperty = "<http://www.w3.org/2002/07/owl#onProperty> ";
        String transPropClass = "<http://www.w3.org/2002/07/owl#TransitiveProperty> ";
        String bnode1 = "_:node1 ";
        String bnode2 = "_:node2 ";
        String dot = ".";
        String testClass = "<" + NAME_SPACE + "TestClass> ";
        String subClassOf = "<http://www.w3.org/2000/01/rdf-schema#subClassOf> ";
        String inverseProp = "<" + NAME_SPACE + "inverseProp> ";

/*
        PrintWriter out = new PrintWriter(new FileWriter(filename));
        out.println(transProp + type + transPropClass + dot);
        out.println(bnode1 + type + restrictionClass + dot);
        out.println(bnode1 + onProperty + transProp + dot);
        out.println(bnode1 + someValuesFrom + testClass + dot);
        out.println(inverseProp + "<http://www.w3.org/2002/07/owl#inverseOf> " + transProp + dot);

        for (int i = 1; i < chainLength; i++) {
            out.println(instanceBase + i + "> " + transProp + instanceBase + (i + 1) + "> .");
            out.println(instanceBase + (i + 1) + "> " + type + testClass + dot);
        }
*/

        PrintWriter out = new PrintWriter(new FileWriter(filename));
        out.println(transProp + type + transPropClass + dot);
        out.println(bnode1 + type + restrictionClass + dot);
        out.println(bnode1 + onProperty + transProp + dot);
        out.println(bnode1 + someValuesFrom + testClass + dot);

        for (int i = 1; i < chainLength; i++) {
          out.println(instanceBase + i + "> " + transProp + instanceBase + (i + 1) +
                      "> .");
      //            out.println(instanceBase + (i + 1) + "> " + type + testClass + dot);
          if (i == chainLength - 1)
            out.println(instanceBase + (i + 1) + "> " + type + testClass + dot);
        }
        out.close();
        System.out.println("File '" + filename + "' generated.");
    }

    public static String generateFileName(int chainLength) {
        return FILE_NAME_BASE + chainLength + FILE_EXTENSION;
    }
}

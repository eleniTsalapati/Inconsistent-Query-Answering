/*
 OWLIM - a SAIL implementation with OWL inference for Sesame (www.openrdf.org)
  
 Copyright (c) 2004-2005, OntoText Lab. / SIRMA

 This library is free software; you can redistribute it and/or modify it under
 the terms of the GNU Lesser General Public License as published by the Free
 Software Foundation; either version 2.1 of the License, or (at your option)
 any later version.
 This library is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 details.
 You should have received a copy of the GNU Lesser General Public License along
 with this library; if not, write to the Free Software Foundation, Inc.,
 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


package test.sesame;

import junit.framework.*;

import org.openrdf.sesame.Sesame;
import org.openrdf.sesame.repository.SesameService;
import org.openrdf.sesame.repository.SesameRepository;
import org.openrdf.sesame.repository.local.LocalRepository;
import org.openrdf.sesame.sail.RdfSchemaRepository;
import org.openrdf.sesame.sail.StatementIterator;
import org.openrdf.sesame.sailimpl.OWLIMSchemaRepository;
import org.openrdf.sesame.config.*;
import org.openrdf.sesame.admin.*;
import org.openrdf.sesame.constants.RDFFormat;
import org.openrdf.model.*;
import org.openrdf.model.impl.*;

import com.ontotext.trree.transitivity.Repository;

import java.io.*;

/**
 * JUnit tests for checking that various issues/features of OWLIM works as expected
 * 
 * @author Damyan
 *
 */
public class TestOWLMemSchemaRepository extends TestCase {
    class LocalAdminListener implements AdminListener {
        public void transactionStart() {        }
        public void transactionEnd() {        }
        public void status(String msg, int lineNo, int columnNo) {        }
        public void notification(
                String msg, int lineNo, int columnNo, Statement statement) {        }
        public void warning(
                String msg, int lineNo, int columnNo, Statement statement) {        }
        public void error(
                String msg, int lineNo, int columnNo, Statement statement) {        }
    }
  protected static RdfSchemaRepository _sail;
  protected static SesameService _service;
  protected static LocalRepository _rep;
  static {
	    try {
	    _service = Sesame.getService(new File("bin/test/system.conf"));
	    _service.login("admin","REPLACE_ME");
	    _rep = (LocalRepository)_service.getRepository("owlim");
	    }catch (Exception e) {
	        throw new RuntimeException("cannot init tests!", e);
	    }
  }
  public TestOWLMemSchemaRepository(String s) {
    super(s);
    try {
    _sail = (RdfSchemaRepository)_rep.getSail();
    }catch (Exception e) {
        throw new RuntimeException("cannot init tests!", e);
    }
  }

  public RdfSchemaRepository sail() {
      return _sail;
  }

  protected void setUp() {
      try {
    	  _sail.startTransaction();
    	  _sail.clearRepository();
    	  _sail.commitTransaction();
      }catch (Exception e) {
          throw new RuntimeException("cannot init tests!", e);
      }
  }

  protected void tearDown() {
      if (null !=_sail) {
          try {
              _sail.startTransaction();
              _sail.clearRepository();
              _sail.commitTransaction();
          } catch (org.openrdf.sesame.sail.SailUpdateException sue) {
              sue.printStackTrace();
          }
          //_sail.shutDown();
      }
  }
  private boolean has(String subj, String pred, String obj) {
      URI subject = subj == null ? null : new URIImpl(subj);
      URI predicate = pred == null ? null : new URIImpl(pred);
      URI object = obj == null ? null : new URIImpl(obj);
      return _sail.hasStatement(subject, predicate, object);
  }

  public void symmetricProperty1a() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test1a.owl"),"http://test.org#", RDFFormat.RDFXML, false, new LocalAdminListener());
          //(http://test.org#symmetricTestProp, http://www.w3.org/1999/02/22-rdf-syntax-ns#type, http://www.w3.org/2002/07/owl#SymmetricProperty)
          assertTrue(has("http://test.org#Mary", "http://test.org#symmetricTestProp", "http://test.org#John"));
      } catch (Exception e) {
          e.printStackTrace();
          fail(e.getMessage());
      }
  }

  public void symmetricProperty1b() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test1a.owl"),"http://test.org#", RDFFormat.RDFXML ,  false, new LocalAdminListener());
          {
              Resource subj = new URIImpl("http://test.org#symmetricTestProp");
              URI pred = new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type");
              URI obj = new URIImpl("http://www.w3.org/2002/07/owl#SymmetricProperty");
              try {
                  _sail.startTransaction();
                  _sail.removeStatements(subj, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
          }
          assertTrue(! has("http://test.org#Mary", "http://test.org#symmetricTestProp", "http://test.org#John"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }


  public void transitiveProperty1a() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test2a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          //(http://test.org#symmetricTestProp, http://www.w3.org/1999/02/22-rdf-syntax-ns#type, http://www.w3.org/2002/07/owl#SymmetricProperty)
          assertTrue(has("http://test.org#John", "http://test.org#transitiveTestProp", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void transitiveProperty1b() {

      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test2a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          {
              Resource subj = new URIImpl("http://test.org#Mary");
              URI pred = new URIImpl("http://test.org#transitiveTestProp");
              URI obj = new URIImpl("http://test.org#Hary");
              try {
                  _sail.startTransaction();
                  _sail.removeStatements(subj, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
          }
          assertTrue(!has("http://test.org#John", "http://test.org#transitiveTestProp", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void transitiveProperty1c() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test2a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          {
              Resource subj = new URIImpl("http://test.org#John");
              URI pred = new URIImpl("http://test.org#transitiveTestProp");
              URI obj = new URIImpl("http://test.org#Mary");
              try {
                  _sail.startTransaction();
                  _sail.removeStatements(null, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
          }
          assertTrue(!has("http://test.org#John", "http://test.org#transitiveTestProp", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void transitiveProperty1d() {

      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test2a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          {
              Resource subj = new URIImpl("http://test.org#John");
              URI pred = new URIImpl("http://test.org#transitiveTestProp");
              URI obj = new URIImpl("http://test.org#Hary");
              try {
                  _sail.startTransaction();
                  _sail.removeStatements(subj, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
          }
          assertTrue(has("http://test.org#John", "http://test.org#transitiveTestProp", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void transitiveProperty1�() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test2a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          {
              Resource subj = new URIImpl("http://test.org#transitiveTestProp");
              URI pred = new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type");
              URI obj = new URIImpl("http://www.w3.org/2002/07/owl#TransitiveProperty");
              try {
                  _sail.startTransaction();
                  _sail.removeStatements(subj, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
              assertTrue(!has("http://test.org#John", "http://test.org#transitiveTestProp", "http://test.org#Hary"));
              try {
                  _sail.startTransaction();
                  _sail.addStatement(subj, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
              assertTrue(has("http://test.org#John", "http://test.org#transitiveTestProp", "http://test.org#Hary"));
          }
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }


  public void transitiveAndSymmetricProperty1a2a() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test1a2a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          assertTrue(has("http://test.org#John", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#Hary"));
          assertTrue(has("http://test.org#John", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#Mary"));
          assertTrue(has("http://test.org#John", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#John"));
          assertTrue(has("http://test.org#Hary", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#John"));
          assertTrue(has("http://test.org#Hary", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#Mary"));
          assertTrue(has("http://test.org#Hary", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#Hary"));
          assertTrue(has("http://test.org#Mary", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#John"));
          assertTrue(has("http://test.org#Mary", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#Mary"));
          assertTrue(has("http://test.org#Mary", "http://test.org#transitiveAndSymmetricTestProp", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void inverseOfTransitiveProperty1a() {
      try {
          assertTrue(has("http://www.w3.org/2002/07/owl#inverseOf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://www.w3.org/2002/07/owl#SymmetricProperty"));
          // john -> Mary -> Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test3a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          assertTrue(has("http://www.w3.org/2002/07/owl#inverseOf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://www.w3.org/2002/07/owl#SymmetricProperty"));

          assertTrue(has("http://test.org#Hary", "http://test.org#inverseOfTransitive", "http://test.org#Mary"));
          assertTrue(has("http://test.org#Mary", "http://test.org#inverseOfTransitive", "http://test.org#John"));
          assertTrue(has("http://test.org#Hary", "http://test.org#inverseOfTransitive", "http://test.org#John"));
          assertTrue(!has("http://test.org#Hary", "http://test.org#inverseOfTransitive", "http://test.org#Hary"));
          assertTrue(!has("http://test.org#Mary", "http://test.org#inverseOfTransitive", "http://test.org#Mary"));
          assertTrue(!has("http://test.org#John", "http://test.org#inverseOfTransitive", "http://test.org#John"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void equalOfInverseProp10a() {
      try {
          assertTrue(has("http://www.w3.org/2002/07/owl#inverseOf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://www.w3.org/2002/07/owl#SymmetricProperty"));
          // john -> Mary -> Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test10a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          assertTrue(has("http://www.w3.org/2002/07/owl#inverseOf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://www.w3.org/2002/07/owl#SymmetricProperty"));

          assertTrue(has("http://test.org#Hary", "http://test.org#eqTestProp", "http://test.org#Mary"));
          assertTrue(has("http://test.org#Mary", "http://test.org#eqTestProp", "http://test.org#John"));
          assertTrue(has("http://test.org#Hary", "http://test.org#eqTestProp", "http://test.org#John"));
          assertTrue(!has("http://test.org#Hary", "http://test.org#eqTestProp", "http://test.org#Hary"));
          assertTrue(!has("http://test.org#Mary", "http://test.org#eqTestProp", "http://test.org#Mary"));
          assertTrue(!has("http://test.org#John", "http://test.org#eqTestProp", "http://test.org#John"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void equalOfInverseProp10bDomainRange() {
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test10b.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());

          assertTrue(has("http://test.org#Hary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#DomainNamed"));
          assertTrue(has("http://test.org#Mary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#DomainNamed"));
          assertTrue(!has("http://test.org#John", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#DomainNamed"));
          assertTrue(has("http://test.org#John", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#RangeNamed"));
          assertTrue(has("http://test.org#Mary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#RangeNamed"));
          assertTrue(!has("http://test.org#Hary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#RangeNamed"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void sameAs4Properties() {
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test12a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());

          assertTrue(has("http://test.org#Hary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#DomainNamed"));
          assertTrue(has("http://test.org#Mary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#DomainNamed"));
          assertTrue(!has("http://test.org#John", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#DomainNamed"));
          assertTrue(has("http://test.org#John", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#RangeNamed"));
          assertTrue(has("http://test.org#Mary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#RangeNamed"));
          assertTrue(!has("http://test.org#Hary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#RangeNamed"));
      } catch (Exception e) {
        e.printStackTrace();
          fail(e.getMessage());
      }
  }

  public void sameAs4Individuals() {
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test12b.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());

          assertTrue(has("http://test.org#MaryAlias", "http://test.org#inverseOfTransitive", "http://test.org#John"));
          assertTrue(has("http://test.org#MaryAlias", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Person"));
          assertTrue(!has("http://test.org#MaryAlias", "http://test.org#inverseOfTransitive", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void functionalPropertyForInstances() {
      File f = new File("../owl_test15b.owl");
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test15b.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());

          assertTrue(has("http://test.org#Mary", "http://test.org#hairColor", "http://test.org#Blonde"));
          assertTrue(has("http://test.org#Carmen", "http://test.org#livesIn", "http://test.org#Sofia"));
          {
              Resource subj = new URIImpl("http://test.org#hasMother");
              URI pred = new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type");
              URI obj = new URIImpl("http://www.w3.org/2002/07/owl#FunctionalProperty");
              try {
                  _sail.startTransaction();
                  _sail.removeStatements(subj, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
          }
          assertTrue(!has("http://test.org#Mary", "http://test.org#hairColor", "http://test.org#Blonde"));
          assertTrue(!has("http://test.org#Carmen", "http://test.org#livesIn", "http://test.org#Sofia"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void inverceOfInvFunc_is_functionalPropertyForInstances() {
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test15a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          StatementIterator iter = _sail.getStatements(null, new URIImpl("http://www.w3.org/2002/07/owl#sameAs"), null);
          while (iter.hasNext()) {
        	  Statement st = iter.next();
        	  System.out.println("["+st.getSubject()+"] ["+st.getPredicate()+"] ["+st.getObject()+"]");
          }
          assertTrue(has("http://test.org#Mary", "http://test.org#hairColor", "http://test.org#Blonde"));
          assertTrue(has("http://test.org#Carmen", "http://test.org#livesIn", "http://test.org#Sofia"));
          {
              Resource subj = new URIImpl("http://test.org#motherOf");
              URI pred = new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type");
              URI obj = new URIImpl("http://www.w3.org/2002/07/owl#InverseFunctionalProperty");
              try {
                  _sail.startTransaction();
                  _sail.removeStatements(subj, pred, obj);
              } catch (Exception re) {
                  re.printStackTrace();
              } finally {
                  _sail.commitTransaction();
              }
          }
          assertTrue(!has("http://test.org#Mary", "http://test.org#hairColor", "http://test.org#Blonde"));
          assertTrue(!has("http://test.org#Carmen", "http://test.org#livesIn", "http://test.org#Sofia"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void inverseFunctionalPropertyForInstances() {
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test16a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          assertTrue(has("http://test.org#Mary", "http://test.org#hasParent", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }


  public void inverseOfFunctional_is_invfincProperty() {
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test16b.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          assertTrue(has("http://test.org#Mary", "http://test.org#hasParent", "http://test.org#Hary"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void transitiveOverTest() {
      try {
          // John <- Mary <- Hary
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_testgos1a.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          assertTrue(!has("http://test.org#John", "http://test.org#livesIn", "http://test.org#Earth"));
          assertTrue(has("http://test.org#John", "http://test.org#livesIn", "http://test.org#Europe"));
          assertTrue(!has("http://test.org#John", "http://test.org#livesIn", "http://test.org#Japan"));
          assertTrue(!has("http://test.org#John", "http://test.org#livesIn", "http://test.org#Asia"));
          assertTrue(!has("http://test.org#Japan", "http://test.org#subRegionOf", "http://test.org#Earth"));
          assertTrue(has("http://test.org#Japan", "http://test.org#partOf", "http://test.org#Earth"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void unionOf() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test17.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
//          for (StatementIterator iter = ((org.openrdf.sesame.sail.RdfSource) _rep.getSail()).getStatements(null, null, null); iter.hasNext(); ) {
//            Statement st = iter.next();
//            System.out.println(st.getSubject() + " " + st.getPredicate() + " " + st.getObject());
//          }
          has("http://test.org#Harry", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", null);
          assertTrue(has("http://test.org#Peter", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Person"));
          assertTrue(has("http://test.org#Mary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Person"));
          assertTrue(has("http://test.org#Harry", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Person"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void intersectionOf() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test18.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          for (StatementIterator iter = _sail.getStatements(new URIImpl("http://test.org#Man"), new URIImpl("http://www.w3.org/2000/01/rdf-schema#subClassOf"), null); iter.hasNext(); ) {
	        Statement st = iter.next();
	        System.out.println(st.getSubject() + " " + st.getPredicate() + " " + st.getObject());
	        StatementIterator iterType;
	          for (iterType = _sail.getStatements(null, new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"), st.getObject()); iterType.hasNext(); ) {
	  	        Statement st2 = iterType.next();
	  	        System.out.println("\t"+st2.getSubject() + " " + st2.getPredicate() + " " + st2.getObject());
	  	      }
	          iterType.close();
	          System.out.println();
	      }
          assertTrue(has("http://test.org#Peter", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Person"));
          assertTrue(has("http://test.org#Peter", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Man"));
          assertTrue(has("http://test.org#Mary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Person"));
          assertTrue(has("http://test.org#Mary", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Female"));
          assertTrue(has("http://test.org#George", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Man"));
          assertTrue(has("http://test.org#Susan", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Woman"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void oneOf() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test19.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
	      
          StatementIterator iterType;
	          for (iterType = _sail.getStatements(new BNodeImpl("node10"), null, null); iterType.hasNext(); ) {
	  	        Statement st2 = iterType.next();
	  	        System.out.println("\t"+st2.getSubject() + " " + st2.getPredicate() + " " + st2.getObject());
	  	      }
	          iterType.close();
	          System.out.println();
	      
          assertTrue(has("http://test.org#member1", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Group"));
          assertTrue(has("http://test.org#member2", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Group"));
          assertTrue(has("http://test.org#member3", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Group"));
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void paralelInference() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test19.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
//          System.out.println("counterNumInvocation="+HashRepository.counterNumInvocation+"\ncounterNumAdds="+HashRepository.counterNumAdds);
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  public void safeTransactionSupport() {
      try {
          StatementIterator iter = null;
    	  URI subj = new URIImpl("http://test.org#member1");
    	  URI pred = new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type");
    	  URI obj = new URIImpl("http://test.org#Group");
    	  try {
	    	  _sail.startTransaction();
	          _sail.addStatement(subj, 
	        		  pred,
	        		  obj);
	          assertFalse(has("http://test.org#member1", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Group"));
	
	          iter = _sail.getStatements(subj, null, null);
	          assertFalse(iter.hasNext());
	          iter.close();
	          iter = _sail.getStatements(obj, null, null);
	          assertFalse(iter.hasNext());
	          iter.close();
	      } finally {
	          _sail.commitTransaction();
	      }

          assertTrue(has("http://test.org#member1", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Group"));
          iter = _sail.getStatements(subj, null, null);
          assertTrue(iter.hasNext());
          iter.close();
          iter = _sail.getStatements(obj, null, null);
          assertTrue(iter.hasNext());
          iter.close();
          
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  /**
   * check whether two concurent threads can open simultenously an trasaction
   *
   */
  public void safeTransactionSupport2() {
      try {
          StatementIterator iter = null;
    	  URI subj = new URIImpl("http://test.org#member1");
    	  URI pred = new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type");
    	  URI obj = new URIImpl("http://test.org#Group");
    	  try {
	    	  _sail.startTransaction();
	          _sail.addStatement(subj, 
	        		  pred,
	        		  obj);
	          assertFalse(has("http://test.org#member1", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Group"));
	
	          iter = _sail.getStatements(subj, null, null);
	          assertFalse(iter.hasNext());
	          iter.close();
	          iter = _sail.getStatements(obj, null, null);
	          assertFalse(iter.hasNext());
	          iter.close();
    	  } finally {
    		  _sail.commitTransaction();
    	  }

          assertTrue(has("http://test.org#member1", "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://test.org#Group"));
          iter = _sail.getStatements(subj, null, null);
          assertTrue(iter.hasNext());
          iter.close();
          iter = _sail.getStatements(obj, null, null);
          assertTrue(iter.hasNext());
          iter.close();
          
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }

  /**
   * whether the implicit-only works
   */
  
  public void explicitVSImplicit() {
      try {
          _rep.addData(ClassLoader.getSystemResourceAsStream("test/owl_test18.owl"),"http://test.org#",RDFFormat.RDFXML, false,  new LocalAdminListener());
          // an explicit from data
          assertTrue(_sail.hasExplicitStatement(new URIImpl("http://test.org#Person"),
        		  new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),new URIImpl("http://www.w3.org/2002/07/owl#Class")));
          // an explicit from imported files
          assertTrue(_sail.hasExplicitStatement(new URIImpl("http://www.w3.org/2002/07/owl#Thing"),
        		  new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),new URIImpl("http://www.w3.org/2002/07/owl#Class")));
          // an implicit from data
          assertFalse(_sail.hasExplicitStatement(new URIImpl("http://test.org#Man"),
        		  new URIImpl("http://www.w3.org/2000/01/rdf-schema#subClassOf"),new URIImpl("http://test.org#Person")));
          assertTrue(has("http://test.org#Man","http://www.w3.org/2000/01/rdf-schema#subClassOf","http://test.org#Person"));
          // an implicit from imported
          assertFalse(_sail.hasExplicitStatement(new URIImpl("http://www.w3.org/2002/07/owl#Thing"),
        		  new URIImpl("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),new URIImpl("http://www.w3.org/2000/01/rdf-schema#Class")));
          assertTrue(has("http://www.w3.org/2002/07/owl#Thing","http://www.w3.org/1999/02/22-rdf-syntax-ns#type","http://www.w3.org/2000/01/rdf-schema#Class"));
          
          
          // check wheter the normal operation of getExplicitstatements is preserved
          StatementIterator iter = _sail.getExplicitStatements(null,null,null);
          assertTrue(iter.hasNext());
          
          while (iter.hasNext()) {
        	  Statement st = iter.next();
        	  assertTrue(_sail.hasExplicitStatement(st.getSubject(), st.getPredicate(), st.getObject()));
          }
          iter.close();
          
          //check the fetch of implicit statements
          iter = _sail.getExplicitStatements(new URIImpl("http://www.ontotext.com/owlim#implicitOnly"), null, null);
          assertFalse(iter.hasNext());
          iter.close();
          
          iter = _sail.getExplicitStatements(null,null,null);
          assertTrue(iter.hasNext());
          while (iter.hasNext()) {
        	  Statement st = iter.next();
        	  assertFalse(_sail.hasExplicitStatement(st.getSubject(), st.getPredicate(), st.getObject()));
          }
          iter.close();
          /*
           * <Class rdf:ID="Thing">  <rdfs:label>Thing</rdfs:label>

           */
          iter = _sail.getExplicitStatements(
        		  new URIImpl("http://www.w3.org/2002/07/owl#Thing"), 
        		  new URIImpl("http://www.w3.org/2000/01/rdf-schema#label"), new LiteralImpl("Thing") );
          assertTrue(iter.hasNext());
          iter.close();
      } catch (Exception e) {
          fail(e.getMessage());
      }
  }
  
  public static Test suite() {
      TestSuite suite = new TestSuite("all tests");
/**/
      
      suite.addTest(new TestOWLMemSchemaRepository("symmetricProperty1a"));
      suite.addTest(new TestOWLMemSchemaRepository("symmetricProperty1b"));
      suite.addTest(new TestOWLMemSchemaRepository("transitiveProperty1a"));
      suite.addTest(new TestOWLMemSchemaRepository("transitiveProperty1b"));
      suite.addTest(new TestOWLMemSchemaRepository("transitiveProperty1c"));
      suite.addTest(new TestOWLMemSchemaRepository("transitiveProperty1d"));
      suite.addTest(new TestOWLMemSchemaRepository("transitiveProperty1�"));
      suite.addTest(new TestOWLMemSchemaRepository("transitiveAndSymmetricProperty1a2a"));
      suite.addTest(new TestOWLMemSchemaRepository("inverseOfTransitiveProperty1a"));
      suite.addTest(new TestOWLMemSchemaRepository("equalOfInverseProp10a"));
      suite.addTest(new TestOWLMemSchemaRepository("equalOfInverseProp10bDomainRange"));
      suite.addTest(new TestOWLMemSchemaRepository("sameAs4Properties"));
      suite.addTest(new TestOWLMemSchemaRepository("sameAs4Individuals"));
      suite.addTest(new TestOWLMemSchemaRepository("functionalPropertyForInstances"));
      suite.addTest(new TestOWLMemSchemaRepository("inverseFunctionalPropertyForInstances"));
      suite.addTest(new TestOWLMemSchemaRepository("transitiveOverTest"));
      suite.addTest(new TestOWLMemSchemaRepository("inverseOfFunctional_is_invfincProperty"));
      suite.addTest(new TestOWLMemSchemaRepository("inverceOfInvFunc_is_functionalPropertyForInstances"));
      suite.addTest(new TestOWLMemSchemaRepository("unionOf"));
      suite.addTest(new TestOWLMemSchemaRepository("intersectionOf"));
      
      suite.addTest(new TestOWLMemSchemaRepository("oneOf"));
      suite.addTest(new TestOWLMemSchemaRepository("paralelInference"));
/**/      
      suite.addTest(new TestOWLMemSchemaRepository("safeTransactionSupport"));
      suite.addTest(new TestOWLMemSchemaRepository("explicitVSImplicit"));
      
      return suite;
  }
}

package test;
import org.openrdf.sesame.server.rmi.RMICenter;
public class Test {
  public static void main(String[] opts) {
    String[] op = null;
    if (opts.length == 0) {
    	System.out.println("usage: java Test.class [start [path-to/system.conf [portNo]] | stop [portNo]]\n - the default configuration file is test/test/system.conf\n - the default portNo is 1098");
    	return;
    }
    if (0 == opts[0].compareToIgnoreCase("start")) {
        op = new String[]{"start", "bin/test/system.conf","1098"};
        if (opts.length > 1)
        	op[1] = opts[2];
        if (opts.length > 2)
        	op[1] = opts[3];
    } else {
        op = new String[]{"stop", "1098"};
        if (opts.length > 1)
        	op[1] = opts[2];
    }
    RMICenter.main(op);
  }
}
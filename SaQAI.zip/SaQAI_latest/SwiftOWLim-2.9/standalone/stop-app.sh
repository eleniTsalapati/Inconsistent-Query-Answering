EXT_LIB=
foo=$PWD
cd ..
source ./setvars.sh
cd ./test
$JAVA_HOME/bin/java -Xmx256m -Dremote.context=true -cp "$CP_TESTS:bin:$EXT_LIBS" test.Test stop ../standalone/system.conf $1
cd $foo

foo=$PWD
cd ..
source setvars.sh
cd $foo
MAXCHAIN=$1
if test -z "$MAXCHAIN"; then MAXCHAIN=1200; fi
STEPCHAIN=$2
if test -z "$STEPCHAIN"; then STEPCHAIN=300; fi
$JAVA_HOME/bin/java -Dmaxchain=$MAXCHAIN -Dstepchain=$STEPCHAIN -Dnum.threads.run=1 -Xmx700m -cp "$CP_TESTS" com.ontotext.trree.benchmark.TransitivityBenchmark

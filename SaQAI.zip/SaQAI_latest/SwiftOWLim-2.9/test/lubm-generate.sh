#!/bin/sh
foo=$PWD
cd ..
source setvars.sh
cd $foo
CP_TESTS=$PWD/../ext/lubm.jar
mkdir univer$1
cd univer$1
$JAVA_HOME/bin/java -cp "$CP_TESTS" edu.lehigh.swat.bench.uba.Generator -univ $1 -seed 0 -onto http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl
cd ..
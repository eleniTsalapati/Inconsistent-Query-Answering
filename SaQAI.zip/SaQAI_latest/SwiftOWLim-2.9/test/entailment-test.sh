APPROVED_DIR=/inst/owl
if ! test -d $APPROVED_DIR; then echo "Please, set the APPROVED_DIR variable to the location of the W3C testcases."; exit 1; fi
foo=$PWD
cd ..
source setvars.sh
cd $foo
$JAVA_HOME/bin/java -Dnum.threads.run=2 -Xmx256m -cp "$CP_TESTS" com.ontotext.bm.EntailmentsTest $APPROVED_DIR/ $1

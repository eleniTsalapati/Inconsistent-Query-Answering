foo=$PWD
cd ..
source setvars.sh
cd $foo
rm kb/kb.nt
$JAVA_HOME/bin/java -Xmx1600m -Dnum.threads.run=2 -Dnum.queries=1 -Dtest.delete=false -cp "$CP_TESTS:bin" com.ontotext.bm.SesameBenchmark 900 15000000

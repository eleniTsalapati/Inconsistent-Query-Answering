foo=$PWD
cd ..
source setvars.sh
cd $foo
rm ./kb/eLubm-dl-new-temp-triples.nt
rm ./kb/eLubm.nt
$JAVA_HOME/bin/java -Dnum.threads.run=2 -Ddump.query.result=false -Dtestset=eLubm-dl -Dfilemask=1-ub-dl-univ -Xmx512m -cp "$CP_TESTS" edu.lehigh.swat.bench.ubt.Test memory ./config.kb.dl.owlim ./config.query.dl.owlim $1 $2 $3

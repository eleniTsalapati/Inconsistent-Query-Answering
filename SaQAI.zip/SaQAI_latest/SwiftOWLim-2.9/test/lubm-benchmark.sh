foo=$PWD
cd ..
source setvars.sh
cd $foo
rm ./kb/lubm.nt
rm ./kb/lubm-new-temp-triples.nt
NUM=$1
if (test -z "$NUM" ); then NUM=2; fi
echo "Number of threads: "$NUM
$JAVA_HOME/bin/java -Xmx800m -Dnum.threads.run=$NUM -cp "$CP_TESTS" edu.lehigh.swat.bench.ubt.Test memory ./config.kb.example.owlim ./config.query.example.owlim $2 $3

foo=$PWD
cd ..
source setvars.sh
cd $foo
rm ./kb/eLubm-lite-new-temp-triples.nt
rm ./kb\elubm.nt
$JAVA_HOME/bin/java -Dnum.threads.run=2 -Dtestset=eLubm-lite -Dfilemask=1-ub-lite-univ -Xmx512m -cp "$CP_TESTS" edu.lehigh.swat.bench.ubt.Test memory ./config.kb.lite.owlim ./config.query.lite.owlim $1 $2 $3

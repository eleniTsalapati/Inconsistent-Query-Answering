foo=$PWD
cd ..
source setvars.sh
cd $foo
JUNIT_HOME=../ext
GUI=junit.swingui.TestRunner
#GUI=junit.textui.TestRunner
$JAVA_HOME/bin/java -Xmx256m -cp "$CP_TESTS:bin:$JUNIT_HOME/junit.jar" $GUI test.sesame.TestOWLMemSchemaRepository 

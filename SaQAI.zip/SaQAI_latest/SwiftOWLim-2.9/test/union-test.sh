foo=$PWD
cd ..
source setvars.sh
cd $foo
$JAVA_HOME/bin/java -Xmx700m -cp "$CP_TESTS" com.ontotext.trree.benchmark.UnionTreeBenchMark
